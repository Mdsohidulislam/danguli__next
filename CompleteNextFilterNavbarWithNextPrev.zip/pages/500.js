import React from 'react';

const ErrorPage = () => {
    return (
        <div>
            <h1>Sorry Page Not found</h1>
        </div>
    );
};

export default ErrorPage;