import axios from 'axios';
import { useRouter } from 'next/router';
import React, { useEffect, useState } from 'react';
import Footer from '../Components/Footer/Footer';
import FinalLoading from '../Components/Loading/FinalLoading';
import Navbar from '../Components/Navbar/Navbar';
import productsDatabase from '../database/products';
import SearchEngine from '../UTILS/SearchEngineUtils';
import DetailsProductViews from './SingleProductViews';

const HomeDetailsView = () => {
    const router = useRouter();
    const search = router.query.url + router.query.category;
    const [product, setProduct] = useState([]);
    const [showPage, setShowPage] = useState(false);
    let query = router.query;
    

    useEffect(()=>{ 
        // if(query.id){
        //     setShowPage(false)
        //     let product = SearchEngine.productFinder(query.id, productsDatabase.products);
        //         product.top__category = 'Computer & Accessories'
        //         if(product.infos.title){
        //             document.title = product.infos.title
        //         }
        //     setProduct(()=> product);
        //     setTimeout(() => {
        //         setShowPage(true);
        //     }, 300);
        // }

        if(query.url){
            setShowPage(()=> false);
            getCurrentPageProductData(query.url, query.top__category);
        }

    },[search])

    const getCurrentPageProductData  = (url, parent__father) => {
        axios.get('http://localhost:3009/getsSingleProductDetailsProduct',{headers:{url, parent__father}})
        .then(res => {   
            let newProduct = res.data.infos.newInfo;

            if(newProduct){
                newProduct.topCategory = 'Computer & Accessories'
                if(newProduct.infos.title){
                    document.title = newProduct.infos.title;
                    setProduct(newProduct);
                    setShowPage(true)
                }

            }
        }).catch(err => {
            console.log(err.message);
        })     
    }


    return (
        <div> 
            {
                showPage && <Navbar/>
            }
            {
                showPage && <DetailsProductViews product={product}/>
            }
            {
                !showPage && <FinalLoading/>
            }
            {
                showPage && <Footer/>
            }
        </div>
    );
};

export default HomeDetailsView;