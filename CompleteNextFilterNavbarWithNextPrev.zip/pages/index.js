import Head from 'next/head';
import React from 'react';
import FinalLoading from './Components/Loading/FinalLoading';
import Navbar from './Components/Navbar/Navbar';
import SideNavbar from './Components/SideNavbar/SideNavbar';
import { ChildProductsViews } from './Components/Views/ChildProductsViews/ChildProductViews';

const Home = () => {
  return (
    <div>
        <Head>
        <link rel="preconnect" href="https://fonts.googleapis.com"/>
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin/>
        <link href="https://fonts.googleapis.com/css2?family=PT+Sans:ital@1&display=swap" rel="stylesheet"/>
      </Head>  
      <Navbar/>  

    </div>
  );
};

export default Home;