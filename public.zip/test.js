let one = {
    "ID": 2150,
    "product__id": "58.04.115.311",
    "infos": {
        "user__guide": {
            "Recommended": false,
            "most__popular": false,
            "new__arrival": false,
            "top__review": false,
            "resent__sell": false,
            "you__link": false,
            "flash__sale": true,
            "hot__deal": true,
            "free__shipping": false,
            "coupon": false,
            "featured": false,
            "top__seller": false,
            "innovated__gadget": false,
            "bundle": {
                "active": false,
                "product__id": "",
                "discount": 0,
                "currentPrice": 0,
                "prevWhole": 0,
                "prevCurrent": 0
            }
        },
        "child": "Danguli PC",
        "parent": "Gaming Desktop PC",
        "parent__father": "Gaming",
        "brand": "Danguli",
        "product__id": "58.04.115.311",
        "images": [
            "/images/assests/5129_______58.04.115.311_______.png",
            "/images/assests/10750_______58.04.115.311_______.png",
            "https://www.ryanscomputers.com/storage/products/small/ryans-pc-v4000-intel-cdc-j4005-4gb-ram-with-185-11646649531.webp"
        ],
        "quantity": 10,
        "current__price": 24700,
        "previous__price": 26580,
        "title": "Ryans PC-V4000 Intel CDC J4005 4GB RAM with 18.5 Inch Innovtech Monitor",
        "details__url": "https://www.ryanscomputers.com/ryans-pc-v4000-intel-cdc-j4005-4gb-ram-with-18.5-inch-innovtech-monitor",
        "visible__url": "ryans-pc-v4000-intel-cdc-j4005-4gb-ram-with-18.5-inch-innovtech-monitor",
        "overviews": [
            "Model - Ryans PC-V4000",
            "Processor - Built in Intel Celeron Dual Core J4005",
            "Motherboard - Asus PRIME J4005I-C DDR4 Mini ITX",
            "RAM - G.Skill 4GB DDR4 2400MHz",
            "SSD - Hikvision C100 120GB 2.5 Inch SATAIII SSD"
        ]
    },
    "quantity": 10,
    "child": "Danguli PC",
    "parent": "Gaming Desktop PC",
    "parent__father": "Gaming",
    "visible__url": "ryans-pc-v4000-intel-cdc-j4005-4gb-ram-with-18.5-inch-innovtech-monitor",
    "brand": "Danguli",
    "user__guide": {
        "Recommended": false,
        "most__popular": false,
        "new__arrival": false,
        "top__review": false,
        "resent__sell": false,
        "you__link": false,
        "flash__sale": true,
        "hot__deal": true,
        "free__shipping": false,
        "coupon": false,
        "featured": false,
        "top__seller": false,
        "innovated__gadget": false,
        "bundle": {
            "active": false,
            "product__id": "",
            "discount": 0,
            "currentPrice": 0,
            "prevWhole": 0,
            "prevCurrent": 0
        }
    }
}