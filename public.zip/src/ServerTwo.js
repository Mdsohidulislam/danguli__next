// import axios from 'axios';
// import React, { useContext } from 'react';
// import { danguliContext } from './App';
// import { errId } from './data/first__1000';
// import { momentTimeMaker, stringMacker } from './utils';
// const ServerTwo = () => {
    
//     const { otherProducts} = useContext(danguliContext);
//     let errID = errId;
//     let count = 3232; 
//     const faildProduct  = [];

//     const handleStartSubmitTwo = () => { 

//         handleGetData(otherProducts[count])
//         document.getElementById('server__insert__result__two').innerHTML = count;
//         count++;
//     }
    
//     const handleGetData = (result) =>  { 
//             axios.get(result.details__url)
//             .then(res => { 
//                 if(res.data){  
//                     let productData = res.data; 
//                     let startCutStr = 'Overview</p>'
//                     let startCutStrLen = 'Overview</p>'.length;
//                     let endCutStr = '<div class="row-detail-action">'  
            
//                     let overviewData = productData.slice(productData.indexOf(startCutStr)+startCutStrLen, productData.indexOf(endCutStr));  
                    
                    
//                     let showOf = document.getElementById('server__result__two');
//                     showOf.innerHTML = res.data;
//                     showOf.style.display = 'none';
                    
//                     let images = document.querySelectorAll('#productGallery > .elevatezoom-gallery');
//                     let zoomImages = [];
//                     images.forEach(info =>  {
//                         zoomImages.push(info.dataset.zoomImage);
//                     })


//                     let headerMother  = document.querySelectorAll('.specs-wrapper > .row > .col-sm-12');
//                     let totalSpecifications = []
//                     headerMother.forEach(info =>  {
//                         let newInfo = {}
//                         let infos = [];
                    
//                         let title = info.querySelector('.group');
//                         if(title){
//                             newInfo.title = title.innerText
//                         let tableRows = info.querySelectorAll('.specs-item-wrapper > .row');
//                             tableRows.forEach(info => {
//                                 let data = {};
//                                 let headText = info.querySelector('.attribute_set').innerHTML;
//                                 let text = info.querySelector('.col-md-10').innerHTML;
//                                 data.title = headText;
//                                 data.info = text; 
//                                 infos.push(data);
//                             })  
//                         }else{
                    
//                             newInfo.title = 'General'; 
                        
//                             let tableRows = info.querySelectorAll('.specs-item-wrapper > .row');
//                                 tableRows.forEach(info => {
//                                     let data = {};
//                                     let headText = info.querySelector('.attribute_set').innerHTML;
//                                     let text = info.querySelector('.col-md-10').innerHTML;
//                                     data.title = headText;
//                                     data.info = text; 
//                                     infos.push(data);
//                                 })
                                
//                         }
                            
//                             newInfo.infos = infos;
//                         totalSpecifications.push(newInfo);
                    
//                     })

//                     let data = document.getElementById('description');
//                     let newData = data.innerHTML 
                    
//                     let productDetails = {
//                         images: zoomImages,
//                         specification: totalSpecifications,
//                         overview: overviewData,
//                         details: newData, 
//                         product: result
//                     } 
//                     handlePostData(productDetails) 
//                 }
//             }).catch(err => { 
//                 console.log(err.message);
//                 faildProduct.push(result.product__id);
//                 console.log(faildProduct);
//                 handleStartSubmitTwo();
//             }) 
//     }

//     const handlePostData = (data, ) =>{
//         let {images, specification, overview, details, product} = data;
//             product.images = images;
//             product.overview = overview;

//             handlePostProduct(product, specification, details);
//     }

//     const handlePostProduct = (postItem, specification, details) => {
//         postItem.stock= true;
//         postItem.quantity = 10;
//         let postInfo = {}; 
//         postInfo.product__id = postItem
//         .product__id;
//         postInfo.category = postItem.category;
//         postInfo.collection = postItem.collection;
//         postInfo.post__time = momentTimeMaker(); 
//         postInfo.infos = stringMacker(JSON.stringify(postItem));
        

//         axios.post('http://localhost:3009/productUpload', postInfo)
//         .then(res => {
//             if(res.data.status__code === 200){
//                 handlePostSpecification(postItem
//                     .product__id, specification, details)
//             }
//         }).catch(err => {
//             console.log(err.message);
//         })
//     }

//     const handlePostSpecification = (ID, specification, details) => {
//         let postInfo = {};  
//         postInfo.product__id = ID;
//         postInfo.post__time = momentTimeMaker();
//         postInfo.specifications = stringMacker(JSON.stringify(specification));

//         axios.post('http://localhost:3009/specificationsUpload', postInfo)
//         .then(res => {
//             if(res.data.status__code === 200){
//                 handlePostDetails(ID, details)
//             }
//         }).catch(err => {
//             console.log(err.message);
//         })
//     }

//     const handlePostDetails = (id, details) => {
//         let postInfo = {};
//         postInfo.product__id = id;
//         postInfo.post__time = momentTimeMaker();
//         postInfo.details = stringMacker(JSON.stringify(details));

//         axios.post('http://localhost:3009/detailsUpload', postInfo)
//         .then(res => {
//             if(res.data.status__code === 200){ 
//                 handleStartSubmitTwo();
//             }
//         }).catch(err => {
//             console.log(err.message);
//         })
//     }

//     return (
//         <div className='server__upload__container'>
//             <div id='server__result__two'/>
//             <h1>Hello world</h1>
//             <h1><span id='server__insert__result__two'></span> products out of  {otherProducts.length}</h1>
//             <button onClick={handleStartSubmitTwo}>Start Upload</button>
//         </div>
//     );
// };

// export default ServerTwo;