import Slider from 'react-slick';
import CartEight from '../Carts/CartEight/CartEight';
const SliderSlider = () => {
  
 

let nums = [
    0,
    1,
    2,
    3,
    4,
    5,
    6,
    7,
    8,
    9,
    10,
    11,
    12,
    13,
    14,
    15,
    16,
    17,
    18,
    19
]

    var settings = {
        dots: false,
        infinite: nums.length > 6, 
        slidesToShow: 6,
        slidesToScroll: 3,
        initialSlide: 0, 
        autoplay: true,
        autoplaySpeed: 5000,
        pauseOnHover: true,
        responsive: [
          {
            breakpoint: 1100,
            settings: {
                dots: false, 
                infinite:  nums.length > 5,
              slidesToShow: 5,
              slidesToScroll: 2, 
            }
          },
          {
            breakpoint: 900,
            settings: {
                infinite:  nums.length > 4,
              slidesToShow: 4,
              slidesToScroll: 2,
              initialSlide: 2,
              dots: false, 
            }
          },
          {
            breakpoint: 700,
            settings: {
                dots: false, 
                infinite:  nums.length > 3,
              slidesToShow: 3,
              slidesToScroll: 1
            }
          },
          {
            breakpoint: 500,
            settings: {
                dots: false, 
                infinite:  nums.length > 2,
              slidesToShow: 2,
              slidesToScroll: 1
            }
          },
          {
            breakpoint: 400,
            settings: {
                dots: false, 
                infinite:  nums.length > 2,
              slidesToShow: 2,
              slidesToScroll: 1
            }
          },
          {
            breakpoint: 300,
            settings: {
                dots: false, 
                infinite:  nums.length > 1,
              slidesToShow: 1,
              slidesToScroll: 1
            }
          }
        ]
      }; 
    return (
        <div className='slider__slider__container'>
            <Slider {...settings}>
                {
                    nums.map((info,index)  => {
                        return  <CartEight key={index}/>
                        
                    })
                }
 
            </Slider>
        </div>
    );
};

export default SliderSlider;