import React, { useContext } from 'react';
import { danguliContext } from '../../DanguliContext';
import CartOne from '../CartOne/CartOne';
    
const HomePage = () => {   
    const {products,  setProducts,wishlist, setWishlist,cart, setCart,compareList, setCompareList,wishlistId, setWishlistId,cartId, setCartId,compareListId, setCompareListId} = useContext( danguliContext);




    return (
        <div className='home__page__container'>  
        {products.length?  
            <div className='container'>
                {
                    products.slice(0,32).map((info, index)=>{
                        return <CartOne key={index} infos={info}/>
                    })
                }
            </div>
            :""}
        </div>
    );
};

export default HomePage;