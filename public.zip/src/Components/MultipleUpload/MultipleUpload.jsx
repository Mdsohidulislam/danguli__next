import React from 'react';

const MultipleUpload = () => {

    const handleChange = (e) => {
        let regex1 = /'/g
        let regex2  = /"/g
        let str = e.target.value; 
        let result = str.replace(regex1, '_____');
            result = result.replace(regex2, '=====');

            console.log(result);
    }

    return (
        <div> 
            <input type='text'  onChange={handleChange}/>
        </div>
    );
};

export default MultipleUpload;