import { faAnglesRight } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import React from 'react';
import { Link } from 'react-router-dom';
import CartNn from '../Carts/CartNn/CartNn';
import DemoFilterNavbar from '../FilterNavbar/DemoFilterNavbar';
import ListViewForProductsHeader from '../ProductSearchBar/ListView';
import ProductShowForProductsHeader from '../ProductSearchBar/ProductShow';
import ProductsSearchForProductsHeader from '../ProductSearchBar/ProductsSearch';
import SearchBarForProductsHeader from '../ProductSearchBar/SearchBar';

const ParentProduct = () => {
    return (
        <div className='view__all__or__category___product__container'>

            <div className='category__or__product__link__container'>
                <Link to='/home' className='body__header__middle__Link'>Home</Link>
                <FontAwesomeIcon className='body__header__middle__arrow' icon={faAnglesRight}/> 
                <Link to='/home' className='body__header__middle__Link'>home</Link>
                <FontAwesomeIcon className='body__header__middle__arrow' icon={faAnglesRight}/> 
                <Link to='/home' className='body__header__middle__Link'>home</Link>
                <FontAwesomeIcon className='body__header__middle__arrow' icon={faAnglesRight}/> 
                <Link to='/home' className='body__header__middle__Link'>home</Link>
            </div>
        
            <div className='body__container'>
                <div className='side__filter__navbar__container'> 
                    <DemoFilterNavbar/>
                </div>
                <div className='products__search__and__sort__container'>
                <div className='products__header__navbar'>
                    <div>
                        <ProductShowForProductsHeader/>
                        <SearchBarForProductsHeader/>
                        <ListViewForProductsHeader/>
                    </div>
                    <ProductsSearchForProductsHeader/>
                </div>
                    <div className='products__body__container'>
                        <CartNn/>  
                        <CartNn/>  
                        <CartNn/>  
                        <CartNn/>  
                        <CartNn/>  
                        <CartNn/>  
                        <CartNn/>  
                        <CartNn/>  
                        <CartNn/>  
                        <CartNn/>  
                        <CartNn/>  
                        <CartNn/>  
                        <CartNn/>  
                        <CartNn/>  
                        <CartNn/>  
                        <CartNn/>  
                        <CartNn/>  
                        <CartNn/>  
                        <CartNn/>  
                        <CartNn/>  
                        <CartNn/>  
                        <CartNn/>  
                        <CartNn/>  
                        <CartNn/>  
                        <CartNn/>  
                        <CartNn/>  
                        <CartNn/>  
                        <CartNn/>  
                        <CartNn/>  
                        <CartNn/>  
                    </div>
                </div>
            </div>
        </div>
    );
};

export default ParentProduct;