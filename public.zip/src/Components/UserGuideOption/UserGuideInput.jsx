import axios from 'axios';
import React, { useState } from 'react';
import { utilsHelper } from '../../UTILS/utils';

const UserGuideInput = ({infos}) => {

    const [currentValue, setCurrentValue] = useState({});
    let {name, info, id, product__id, surname, grand}  = infos
    const [valueFalse, setValueFalse] = useState(false);
    

    const handleCancel = () => {
        document.getElementById('user__guide__input__container').classList.toggle('active');
        document.querySelector('body').classList.toggle('active');
    }

    const handleSelectInputChange  = (e) => {
        let newInfo = {...currentValue};
            newInfo[e.target.name] = e.target.value;
            setCurrentValue(newInfo);
    }

    const handleSelectOptionChange = (e) => {
        if(e.target.value === 'true'){
            setValueFalse(true)
        }else {
            setValueFalse(false);
        }
    }
    
    const handleOptionUpdateSubmit = (e) => {
        e.preventDefault();

        if(info.bundle.active){ 
            if(!valueFalse){ 

                let bundleInfo = {
                    active: false, 
                    product__id: '',
                    discount:  0,
                    currentPrice: 0,
                    prevWhole:  0,
                    prevCurrent:  0
                }

                let postInfo = {...info};
                    postInfo.bundle = bundleInfo
                    postInfo = utilsHelper.stringOperations.stringMaker(JSON.stringify(postInfo));
                axios.put('http://localhost:3009/updateProductUserGuideInput', {postInfo,  product__id })
                .then(res  =>  {
                    if(res.data.status__code === 200){
                        document.getElementById('user__guide__input__container').classList.toggle('active');
                        document.querySelector('body').classList.toggle('active'); 
                        window.location.reload();
                    }
                }).catch(err =>  {
                    console.log(err.message);
                })

            }else{
                document.getElementById('user__guide__input__container').classList.toggle('active');
                document.querySelector('body').classList.toggle('active'); 
            }
        }else {
            
                let targetItem = currentValue.path.split('=====');
                let strProducts    = [];
                
                axios.get('http://localhost:3009/getProductByGrandAndId', {headers:{product__id: targetItem[1], grand: targetItem[0]}})
                .then(response  => {
                    let targetData = response.data.result[0];
                    strProducts.push(targetData);
                    if(response.data.status__code === 200){
                        axios.get('http://localhost:3009/getProductByGrandAndId', {headers:{product__id, grand}})
                        .then(res  => {
                            let currentData = res.data.result[0];
                            strProducts.push(currentData);
                            let products = []
                            let totalWhole = 0;
                            let totalCurrent = 0;
                            
                            strProducts.forEach((info, index) => {
                                let newInfos = info.infos;
                                    newInfos = JSON.parse(utilsHelper.stringOperations.stringConverter(newInfos));
                                    totalWhole += newInfos.whole__price;
                                    totalCurrent += newInfos.current__price;
                                    info.infos = newInfos;
                                    products.push(info);
                            })
                            let now = totalCurrent - totalWhole;
                            

                            let result = (now / 100) * (100 - Number(currentValue.discount));
                            
                            let currentPrice = result + totalWhole;
                            
                            let bundleInfo = {
                                active: true, 
                                product__id: targetItem[1],
                                discount: Number(currentValue.discount),
                                currentPrice,
                                prevWhole: totalWhole,
                                prevCurrent: totalCurrent
                            }

                            let postInfo = {...info}
                                postInfo.bundle = bundleInfo;
                                postInfo = utilsHelper.stringOperations.stringMaker(JSON.stringify(postInfo));
                            axios.put('http://localhost:3009/updateProductUserGuideInput', {postInfo,  product__id })
                            .then(res  =>  {
                                if(res.data.status__code === 200){
                                    document.getElementById('user__guide__input__container').classList.toggle('active');
                                    document.querySelector('body').classList.toggle('active'); 
                                    window.location.reload();
                                }
                            }).catch(err =>  {
                                console.log(err.message);
                            })

                            
                        }).catch((err) => {
                            console.log(err.message);
                        })
                    }
                    
                }).catch((err) => {
                    console.log(err.message);
                }) 
    }
    }

    

    return (
        <div className='user__guide__input' id ='user__guide__input__container'>
                <div className='action__area'>
                    <p>Update {surname}</p>
                    <form onSubmit={handleOptionUpdateSubmit}>
                    {info.bundle.active ? 
                    <select className='select'  onChange={handleSelectOptionChange}>
                        <option value='true'>DEFAULT</option>
                        <option value='true'>ACTIVE BUNDLE</option>
                        <option value='false'>BROKE BUNDLE</option>
                    </select>
                    :
   
                <div>
                    <input className='select' name='path' type='text'  placeholder='Enter product path' onChange={handleSelectInputChange} required></input>
                    <input className='select' name='discount' type='number' placeholder='Enter products discount' onChange={handleSelectInputChange} required></input>
                </div>
                }
                    <div className='button__container'>
                        <button className='btn cancel' onClick={handleCancel}>Cancel</button>
                        <button className='btn submit' type='submit'>Submit</button>
                    </div>
                    </form>
                </div>
        </div>
    );
};

export default UserGuideInput;