import React, { useState } from 'react';

const UserGuideOption = ({infos}) => {

    const [currentValue, setCurrentValue] = useState("");
    let {name, info, id, product__id, surname}  = infos

    const handleCancel = () => {
        document.getElementById('user__guide__option__container').classList.toggle('active');
        document.querySelector('body').classList.toggle('active');
    }

    const handleSelectInputChange  = (e) => {
        let value = e.target.value;
        if(value === 'true'){
            setCurrentValue(true);
        }else{
            setCurrentValue(false);
        }

    }
    

    const handleOptionUpdateSubmit = () => {
        let newInfo = {...info};
            newInfo[name] = currentValue; 
            console.log(newInfo);
            // let postInfo = utilsHelper.stringOperations.stringMaker(JSON.stringify(newInfo))
            // axios.put('http://localhost:3009/updateProductUserGuideOption', {postInfo,  product__id })
            // .then(res  =>  {
            //     if(res.data.status__code === 200){
            //         document.getElementById('user__guide__option__container').classList.toggle('active');
            //         document.querySelector('body').classList.toggle('active'); 
            //     }
            // }).catch(err =>  {
            //     console.log(err.message);
            // })
    }
    
    // updateProductUserGuideOption
// let {postInfo,  product__id } = req.body; 

// updateProductUserGuideInput
// let {postInfo,  product__id, currentValue } = req.body; 

    return (
        <div className='user__guide__option' id ='user__guide__option__container'>
                <div className='action__area'>
                    <p>Update {surname}</p>
                    <select className='select' onChange={handleSelectInputChange}>
                        <option value='default'>DEFAULT</option>
                        <option value='true'>TRUE</option>
                        <option value='false'>FALSE</option>
                    </select>
                    <div className='button__container'>
                        <button className='btn cancel' onClick={handleCancel}>Cancel</button>
                        <button className='btn submit' onClick={handleOptionUpdateSubmit}>Submit</button>
                    </div>
                </div>
        </div>
    );
};  

export default UserGuideOption;