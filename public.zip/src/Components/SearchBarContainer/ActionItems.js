import { faBars, faCartShopping, faHeart, faUser, faXmark } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { useContext, useState } from 'react';
import { Link, useHistory } from 'react-router-dom';
import { danguliContext } from '../../DanguliContext';
import active__utils from '../../UTILS/Active__utils';

 
const ActionItems = () => {
    let { wishlist,  totalCarts,  compareList, totalHearts} =  useContext(danguliContext);
    const [openNav, setOpenNav] = useState(false);


    const handleOpenSideNav = () => {
        document.getElementById('my__big__navbar__container').classList.toggle('open');
        setOpenNav(!openNav)
    }

    const handleSmallCart = () => { 
        
        active__utils.active__cart();
    }

    return (
        <div>
                                <div className='icons__div search__bar__element'>
                    <div className='logo__item'>
                    <div className='quantity'>{totalCarts.quantity}</div>

                        <FontAwesomeIcon onClick={handleSmallCart} className='actions__icon' icon={faCartShopping}/>
                    </div>
                    <div className='logo__item'>
                    <div className='quantity'>{ totalHearts.quantity}</div>   
                        <Link to='/wishlist'>
                            <FontAwesomeIcon className='actions__icon' icon={faHeart}/>
                        </Link>
                    </div> 
                    <div className='logo__item'> 
                        <FontAwesomeIcon className='actions__icon' icon={faUser}/>
                    </div>
                    <div className='logo__item open__menu__bar' onClick={handleOpenSideNav}> 
                    {
                        !openNav? <FontAwesomeIcon className='actions__icon' icon={faBars}/>  : <FontAwesomeIcon className='actions__icon' icon={faXmark}/>
                    }
                        
                        
                    </div>
                </div>
        </div>
    );
};

const CompanyLogo = () => {
    
    const history = useHistory();
    const handleGoHome = () => {
        history.push('/')
    }

    return (
        <div className='logo__div search__bar__element'>
            <img src='/logo.png' className='img__logo' alt='store logo' onClick={handleGoHome}></img>
        </div>
    )
}

export { CompanyLogo, ActionItems };

