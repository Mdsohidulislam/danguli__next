import React, { useContext } from 'react';
import { danguliContext } from '../../DanguliContext';
import Search from '../Search/Search';
import { ActionItems, CompanyLogo } from './ActionItems';
 
// import { faCaretDown, faHome } from '@fortawesome/free-solid-svg-icons';
// import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';

const SearchBarContainer = () => {

    let { wishlist,  cart,  compareList} =  useContext(danguliContext)

    

    return (
 
        <div className='search__bar__main__container'>
                <CompanyLogo/>
                <div className='search__div search__bar__element'>
                    <Search/>
                </div>
                <ActionItems/>
        </div>
 

    );
};

export default SearchBarContainer;