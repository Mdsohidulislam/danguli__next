import React, { useEffect } from 'react';
import { Link } from 'react-router-dom';
import Slider from 'react-slick';
import CartEight from '../Carts/CartEight/CartEight';
const HomeRows = ({infos}) => {
  
  let {title, small, small__text, info, all__url} = infos;
  useEffect(()=>{
    document.title = `Danguli Computers | Best Computer Shop in Bangladesh with Best Price`
  },[])
    var settings = {
        dots: false,
        infinite: true,
        speed: 500,
        slidesToShow: 6,
        slidesToScroll: 2,
        initialSlide: 0,
        responsive: [
          {
            breakpoint: 1100,
            settings: {
                dots: false,
                infinite: true,
              slidesToShow: 5,
              slidesToScroll: 2, 
            }
          },
          {
            breakpoint: 900,
            settings: {
              slidesToShow: 4,
              slidesToScroll: 2,
              initialSlide: 2,
              dots: false,
              infinite: true,
            }
          },
          {
            breakpoint: 700,
            settings: {
                dots: false,
                infinite: true,
              slidesToShow: 3,
              slidesToScroll: 1
            }
          },
          {
            breakpoint: 500,
            settings: {
                dots: false,
                infinite: true,
              slidesToShow: 2,
              slidesToScroll: 1
            }
          },
          {
            breakpoint: 400,
            settings: {
                dots: false,
                infinite: true,
              slidesToShow: 2,
              slidesToScroll: 1
            }
          },
          {
            breakpoint: 300,
            settings: {
                dots: false,
                infinite: true,
              slidesToShow: 2,
              slidesToScroll: 1
            }
          },
          {
            breakpoint: 50,
            settings: {
                dots: false,
                infinite: true,
              slidesToShow: 1,
              slidesToScroll: 1
            }
          }
        ]
      };

    return (
        <div className='home__row__container'>
            <div className='container'>
                <div className='row__head'>
                    <div className='home__row__header'>
                            <h3 className='bg-success'> {title}</h3>
                            {small? <small>{small__text}</small>  :""}
                    </div>
                    <Link to={all__url} className='button'>VIEW ALL</Link>
                </div>
                <div className='row__body'>
                    <Slider {...settings}  className='my__home__row__slider'>
                    {
                      info.map((info, index) => {
                        return   <CartEight key={index} infos={info}/>   
                      })
                    } 

                    </Slider>
                </div>
            </div>
        </div>
    );
};

export default HomeRows;

// Deals of the Day countdown timers


// import React from 'react';
// import CartChowddo from '../CartChowddo/CartChowddo';
// import CartEleven from '../CartEleven/CartEleven';
// import CartFive from '../CartFive/CartFive';
// import CartFour from '../CartFour/CartFour';
// import CartNine from '../CartNine/CartNine';
// // import CartOne from '../CartOne/CartOne';
// import CartPonero from '../CartPonero/CartPonero';
// import CartSeven from '../CartSeven/CartSeven';
// import CartSix from '../CartSix/CartSix';
// import CartTen from '../CartTen/CartTen';
// import CartThero from '../CartThero/CartThero';
// import CartThree from '../CartThree/CartThree';
// import CartTwo from '../CartTwo/CartTwo';
// import CartTwoelve from '../CartTwoelve/CartTwoelve';

// const HomeRows = () => {
//     return (
//         <div>  
//            {/** */}
//             <CartTwo/>
//             <CartThree/>
//             <CartFour/>
//             <CartFive/>
//             <CartSix/>
//             <CartSeven/>
//             <CartNine/>
//             <CartTen/>
//             <CartEleven/>
//             <CartTwoelve/>
//             <CartThero/>
//             <CartChowddo/>
//             <CartPonero/>
            
//         </div>
//     );
// };

// export default HomeRows;
 