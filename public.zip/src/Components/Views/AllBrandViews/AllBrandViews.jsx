import axios from "axios";
import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Loading } from "../../Loading/Loading";

const AllBrandViews = () => {
    const [brands, setBrands] = useState([]);
    const handleGetAllBrand = () => {
        axios.get('http://localhost:3009/getAllCollection',{headers:{collection:'details__product'}}).then(res => { 
            let brandCollection = [];
            let brandIdCollection = []; 
            let allProducts = res.data.result;

            allProducts.forEach(info => { 
                if(brandCollection.indexOf(info.brand) === -1){
                    brandCollection.push(info.brand);
                    brandIdCollection.push([info.product__id]);
                }else{
                    let brandIndex = brandCollection.indexOf(info.brand);
                        brandIdCollection[brandIndex].push(info.product__id)
                }
            })
            let brandDataset = [];
            brandCollection.forEach((info, index) => {
                brandDataset.push([info, brandIdCollection[index]])
            })  
            setBrands(brandDataset)
        }).catch(err => {
            console.log(err.message);
        })
    }
    useEffect(()=>{
        handleGetAllBrand();
    },[])
    return (
        <div>  
            {brands.length? 
            <div>
                {
                    brands.map((info, index) => <Link to={`/allBrands/${info[0]}`} key={index} className="brand__views__button__with__brand__product__quantity">{info[0]} ({info[1].length})</Link>  )
                }
                
            </div>: <Loading/>}
        </div>
    );
};

export default AllBrandViews;