import { useEffect, useState } from 'react';
import { useLocation } from 'react-router-dom';
import { serverHelper } from '../../../UTILS/ServerUtils';
import Footer from '../../Footer/Footer';
import { Loading } from '../../Loading/Loading';
import OfferPopUp from '../../OfferPopUp/OfferPopUp';
import HomeView from '../../ProductTopHeader/HomeView';
import TopNavbar from '../../TopNavbar/TopNavbar';
import TopSmallNavbar from '../../TopNavbar/TopSmallNavbar';
import ParentTopLinks from '../TopLinks/ParentTopLinks';

const ParentProductsViews = () => {
    const [filteredSpecifications, setFilteredSpecifications] = useState([]);
    const [brandData, setBrandData ] = useState([]);
    const [currentPath, setCurrentPath] = useState([]); 
    const [currentPageAllProducts, setCurrentPageAllProducts] = useState([]);
    const [viewProducts, setViewProducts ] =  useState([]);
    const [showNavbar, setShowNavbar] = useState(false)
    const [showPage, setShowPage] = useState(false);


    const [showCount, setShowCount] = useState(40);
    const [viewCount, setViewCount] = useState(40);
    const [offerProduct, setOfferProduct] = useState({})
    
    
    const {search} = useLocation();
    let queryData = search.split('&&');
    let father = queryData[0].split('=')[1];
    let parent = queryData[1].split('=')[1]; 
        father = father.replace(/%20/g, " ");
        parent = parent.replace(/%20/g, " "); 



    useEffect(()=>{
        setFilteredSpecifications([]);
        setBrandData([]);
        setCurrentPath([]);
        setCurrentPageAllProducts([]);
        setViewProducts([]);
        setShowPage(false); 
        handleGetCurrentPageAllProduct(); 
        setCurrentPath(search);
        document.title = `${father} | ${parent}`;
    },[])


    const handleGetCurrentPageAllProduct = () => {
        setShowCount(40);
        setViewCount(40);
        serverHelper.getAllCurrentPageParentDataProduct(father, parent)
        .then(res => {
            if(res.status__code === 200){
                let {products,  filterNavbar} = res;      
                console.log(res);
                setFilteredSpecifications(filterNavbar);   
                setCurrentPageAllProducts(products);  
                setTimeout(()=>{
                    setShowPage(true);
                    setShowNavbar(true);
                },50)
            }
        }).catch(err => {
            console.log(err);
        })
    }  
    
    
    const handleUrlValidator = () => {
        if(search !== currentPath){
            
            setFilteredSpecifications([]);
            setBrandData([]);
            setCurrentPath([]);
            setCurrentPageAllProducts([]);
            setViewProducts([]);

            setCurrentPath(search)
            setTimeout(()=>{
                setShowPage(false)
                handleGetCurrentPageAllProduct(); 
                document.title = `${father} | ${parent}`;
            },80)
        }
    }

    handleUrlValidator(); 

    
    return (
            <div>
                                                <OfferPopUp infos={{offerProduct}}/>
                {showPage && showNavbar? 
                <div style={{overflow:"hidden"}}>

                    <TopNavbar/>
                    <TopSmallNavbar/>

                    <div className='view__all__or__category___product__container'> 
                    
                    <ParentTopLinks infos={{father, parent}}/>
                
                    <HomeView infos={{currentPageAllProducts, setViewProducts, showCount, setShowCount, viewCount, filterNavbarData:filteredSpecifications ,  setViewCount, setCurrentPageAllProducts, viewProducts, offerProduct, setOfferProduct}}/>
                    </div>
                    <Footer/>
                </div>
                :  <Loading/>}
            </div> 
    );
};

export { ParentProductsViews };

// import { faAnglesRight } from '@fortawesome/free-solid-svg-icons';
// import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
// import React, { useEffect, useState } from 'react';
// import { Link, useLocation } from 'react-router-dom';
// import CartElevenDemoNextNoButton from '../../../CartEleven/CartElevenNextNoButton';
// import SearchEngine from '../../../UTILS/SearchEngineUtils';
// import { serverHelper } from '../../../UTILS/ServerUtils';
// import FilterNavbar from '../../FilterNavbar/FilterNavbar';
// import ListViewForProductsHeader from '../../ProductSearchBar/ListView';
// import NextPrev from '../../ProductSearchBar/NextPrev';
// import ProductShowForProductsHeader from '../../ProductSearchBar/ProductShow';
// import ProductsSearchForProductsHeader from '../../ProductSearchBar/ProductsSearch';
// import SearchBarForProductsHeader from '../../ProductSearchBar/SearchBar';
// import TopNavbar from '../../TopNavbar/TopNavbar';
// import TopSmallNavbar from '../../TopNavbar/TopSmallNavbar';

// const ParentProductsViews = () => {
//     const [filteredSpecifications, setFilteredSpecifications] = useState([]);
//     const [brandData, setBrandData ] = useState([]);
//     const [currentPath, setCurrentPath] = useState([]); 
//     const [currentPageAllProducts, setCurrentPageAllProducts] = useState([]);
//     const [viewProducts, setViewProducts ] =  useState([]);
//     const [showNavbar, setShowNavbar] = useState(false)
//     const [showPage, setShowPage] = useState(false);


//     const [showCount, setShowCount] = useState(40);
//     const [viewCount, setViewCount] = useState(40);
    
    
//     const {search} = useLocation();
//     let queryData = search.split('&&');
//     let father = queryData[0].split('=')[1];
//     let parent = queryData[1].split('=')[1]; 
//         father = father.replace(/%20/g, " ");
//         parent = parent.replace(/%20/g, " "); 



//     useEffect(()=>{
//         setFilteredSpecifications([]);
//         setBrandData([]);
//         setCurrentPath([]);
//         setCurrentPageAllProducts([]);
//         setViewProducts([]);
//         setShowPage(false); 
//         handleGetCurrentPageAllProduct();
//         handleGetCurrentPageAllSpecificationsAndFilterNavbar();
//         setCurrentPath(search);
//         document.title = `${father} | ${parent}`;
//     },[])


//     const handleGetCurrentPageAllProduct = () => {
//         setShowCount(40);
//         setViewCount(40);
//         serverHelper.getAllCurrentPageParentDataProduct(father, parent)
//         .then(res => {
//             if(res.status__code === 200){
//                 let {products} = res; 
//                 let {collections, filteredBrandProductQuantity} = products; 
                
//                 setCurrentPageAllProducts(collections); 
//                 setBrandData(filteredBrandProductQuantity); 
//                 setTimeout(()=>{
//                     setShowPage(true);
//                 },50)
//             }
//         }).catch(err => {
//             console.log(err);
//         })
//     }
    
//     const handleGetCurrentPageAllSpecificationsAndFilterNavbar = () => {
//         serverHelper.getAllCurrentPageParentDataSpecificationsAndFilterNavbar(father, parent)
//         .then(res => {
//             if(res.status__code === 200){
//                 let {specifications, filterNavbar} = res;   
//                 let result = SearchEngine.handleFilterProductsSpecifications(specifications, filterNavbar);
//                 setFilteredSpecifications(result); 
//                 setTimeout(()=>{ 
//                     setShowNavbar(true);
//                 },50)
//             }
//         }).catch(err => {
//             console.log(err);
//         })
//     }
    
//     const handleUrlValidator = () => {
//         if(search !== currentPath){
            
//             setFilteredSpecifications([]);
//             setBrandData([]);
//             setCurrentPath([]);
//             setCurrentPageAllProducts([]);
//             setViewProducts([]);

//             setCurrentPath(search)
//             setTimeout(()=>{
//                 setShowPage(false)
//                 handleGetCurrentPageAllProduct();
//                 handleGetCurrentPageAllSpecificationsAndFilterNavbar();
//                 document.title = `${father} | ${parent}`;
//             },80)
//         }
//     }

//     handleUrlValidator(); 

    
//     return (
//             <div>
//                 {showPage && showNavbar? 
//                 <div style={{overflow:"hidden"}}>

//                     <TopNavbar/>
//                     <TopSmallNavbar/>

//                     <div className='view__all__or__category___product__container'> 
                    
//                     <div className='category__or__product__link__container'>
//                         <Link to='/' className='body__header__middle__Link'>Home</Link>
//                         <FontAwesomeIcon className='body__header__middle__arrow' icon={faAnglesRight}/> 
//                         <Link to={`/allProducts?father=${father}`} className='body__header__middle__Link'>{father}</Link>
//                         <FontAwesomeIcon className='body__header__middle__arrow' icon={faAnglesRight}/> 
//                         <Link to={`/parentProducts?parentFather=${father}&&parent=${parent}`} className='body__header__middle__Link'>{parent}</Link> 
//                     </div>
                
//                     <div className='body__container'> 
//                         <div className='side__filter__navbar__container'> 
//                             <FilterNavbar infos={{filterNavbarData: filteredSpecifications, currentPageAllProducts,   setViewProducts }}/>
//                         </div> 
//                         <div className='products__search__and__sort__container'>
//                         <div className='products__header__navbar'>
//                             <div>
//                                 <ProductShowForProductsHeader infos={{currentPageAllProducts, setViewProducts,  setShowCount , viewCount, setViewCount}}/>
//                                 <SearchBarForProductsHeader infos={{currentPageAllProducts, setCurrentPageAllProducts, setViewProducts }}/>
//                                 <ListViewForProductsHeader/>
//                             </div>
//                             <ProductsSearchForProductsHeader infos={{currentPageAllProducts,  setViewProducts}}/>
//                         </div>
//                         {viewProducts.length? 
//                         <div className='products__body__container'>
//                             {
//                                 viewProducts.map((info, index) =>    <CartElevenDemoNextNoButton infos={info} count={index}  key={index}/>)
//                             }
                            
//                         </div> : ""}
//                         <NextPrev infos={{currentPageAllProducts, setViewProducts, showCount, setShowCount, viewCount, setViewCount}}/>
//                         </div>
//                     </div>
//                     </div>
//                 </div>
//                 : <h1>Loading......</h1>}
//             </div> 
//     );
// };

// export { ParentProductsViews }; 