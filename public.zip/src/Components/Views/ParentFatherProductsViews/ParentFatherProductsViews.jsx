import { useEffect, useState } from 'react';
import { useLocation } from 'react-router-dom';
import { serverHelper } from '../../../UTILS/ServerUtils';
import Footer from '../../Footer/Footer';
import { Loading } from '../../Loading/Loading';
import OfferPopUp from '../../OfferPopUp/OfferPopUp';
import HomeView from '../../ProductTopHeader/HomeView';
import TopNavbar from '../../TopNavbar/TopNavbar';
import TopSmallNavbar from '../../TopNavbar/TopSmallNavbar';
import FatherTopLinks from '../TopLinks/FatherTopLinks';

const ParentFatherProductsViews = () => {
    const [filteredSpecifications, setFilteredSpecifications] = useState([]);
    const [brandData, setBrandData ] = useState([]);
    const [currentPath, setCurrentPath] = useState([]); 
    const [currentPageAllProducts, setCurrentPageAllProducts] = useState([]);
    const [ viewProducts, setViewProducts ] =  useState([]);
    const [showPage, setShowPage] = useState(false);
    const [showNavbar, setShowNavbar] = useState(false)
    const [offerProduct, setOfferProduct] = useState({})


    const [showCount, setShowCount] = useState(32);
    const [viewCount, setViewCount] = useState(32);
    
    
const {search} = useLocation(); 
let father = search.split('=')[1];
    father = father.replace(/%20/g, ' ');

        

    useEffect(()=>{
        setFilteredSpecifications([])
        setBrandData([])
        setCurrentPath([])
        setCurrentPageAllProducts([])
        setViewProducts([])
        handleGetCurrentPageAllProduct(); 
        setShowPage(false); 
        setCurrentPath(search);
        document.title = `${father}`;
    },[])

    

    
    const handleGetCurrentPageAllProduct = () => {
        setShowCount(40);
        setViewCount(40);
        serverHelper.getAllCurrentPageParentFatherDataProduct(father)
        .then(res => {
            if(res.status__code === 200){
                let {products,  filterNavbar} = res;     
                console.log({products,  filterNavbar});
                setFilteredSpecifications(filterNavbar);   
                setCurrentPageAllProducts(products);  
                setTimeout(()=>{
                    setShowPage(true);
                    setShowNavbar(true);
                },50)
            }
        }).catch(err => {
            console.log(err);
        })
    }  
    
    const handleUrlValidator = () => {
        if(search !== currentPath){
            setFilteredSpecifications([])
            setBrandData([])
            setCurrentPath([])
            setCurrentPageAllProducts([])
            setViewProducts([])
            setCurrentPath(search)
            document.title = `${father}`;
            setTimeout(()=>{
                setShowPage(false);
                handleGetCurrentPageAllProduct(); 
            },100)
        }
    }

    handleUrlValidator(); 

    
    return (
            <div>
                                <OfferPopUp infos={{offerProduct}}/>
                {showPage && showNavbar? 
                <div style={{overflow:"hidden"}}>

                    <TopNavbar/>
                    <TopSmallNavbar/>

                    <div className='view__all__or__category___product__container'> 
                    
                    <FatherTopLinks infos={{father}}/>
                
                    <HomeView infos={{currentPageAllProducts, setViewProducts, showCount, setShowCount, viewCount, filterNavbarData:filteredSpecifications ,  setViewCount, setCurrentPageAllProducts, viewProducts, offerProduct, setOfferProduct}}/>
                    </div>
                    <Footer/>
                </div>
                :  <Loading/>}
            </div> 
    );
};

export { ParentFatherProductsViews };
    
 
// ParentFatherProductsViews
// <div className='category__or__product__link__container'>
// const {search} = useLocation(); 
// let father = search.split('=')[1];
//     <Link to='/' className='body__header__middle__Link'>Home</Link>
//     <FontAwesomeIcon className='body__header__middle__arrow' icon={faAnglesRight}/> 
//     <Link to={`/allProducts?father=${father}`} className='body__header__middle__Link'>{father}</Link> 
// </div>