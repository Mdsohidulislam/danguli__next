import { useEffect, useState } from 'react';
import { useLocation } from 'react-router-dom';
import { serverHelper } from '../../../UTILS/ServerUtils';
import Footer from '../../Footer/Footer';
import { Loading } from '../../Loading/Loading';
import OfferPopUp from '../../OfferPopUp/OfferPopUp';
import HomeView from '../../ProductTopHeader/HomeView';
import TopNavbar from '../../TopNavbar/TopNavbar';
import TopSmallNavbar from '../../TopNavbar/TopSmallNavbar';
import ChildTopLinks from '../TopLinks/ChildTopLinks';

const ChildProductsViews = () => {
    const [filteredSpecifications, setFilteredSpecifications] = useState([]); 
    const [currentPath, setCurrentPath] = useState([]); 
    const [ viewProducts, setViewProducts ] =  useState([]);
    const [currentPageAllProducts, setCurrentPageAllProducts] = useState([]); 
    const [offerProduct, setOfferProduct] = useState({})

    const [showPage, setShowPage] = useState(false);
    const [showNavbar, setShowNavbar] = useState(false);

    const [showCount, setShowCount] = useState(40);
    const [viewCount, setViewCount] = useState(40);
    
    
    const {search} = useLocation();
    let queryData = search.split('&&');
    let father = queryData[0].split('=')[1];
    let parent = queryData[1].split('=')[1];
    let child = queryData[2].split('=')[1];
        father = father.replace(/%20/g, " ");
        parent = parent.replace(/%20/g, " ");
        child = child.replace(/%20/g, " ");
            

    useEffect(()=>{
 
setCurrentPath([])
setViewProducts([])
setCurrentPageAllProducts([])

        setShowNavbar(false)
        setShowPage(false);
        handleGetCurrentPageAllProduct(); 
        setCurrentPath(search);
        document.title = `${father} | ${parent} | ${child} `;
    },[])
 
    const handleGetCurrentPageAllProduct = () => {
        setShowCount(40);
        setViewCount(40);
        serverHelper.getAllCurrentPageChildDataProduct(father, parent, child)
        .then(res => {
            if(res.status__code === 200){
                let {products,  filterNavbar} = res;      
                setFilteredSpecifications(filterNavbar);   
                setCurrentPageAllProducts(products);  
                setTimeout(()=>{
                    setShowPage(true);
                    setShowNavbar(true);
                },50)
            }
        }).catch(err => {
            console.log(err);
        })
    }  

    
    
    
    const handleUrlValidator = () => {
        if(search !== currentPath){ 
    setCurrentPath([])
    setViewProducts([])
    setCurrentPageAllProducts([])
            setCurrentPath(search)
            document.title = `${father} | ${parent} | ${child} `;
            setTimeout(()=>{
                setShowPage(false)
                handleGetCurrentPageAllProduct();  
            },80)
        }
    }

    handleUrlValidator(); 
        
    
    return (
            <div>
                <OfferPopUp infos={{offerProduct}}/> 
                {showPage && showNavbar? 
                <div style={{overflow:"hidden"}}>
                    <TopNavbar/>
                    <TopSmallNavbar/>

                    <div className='view__all__or__category___product__container'> 
                        <ChildTopLinks infos={{parent, father, child}}/>
                        <HomeView infos={{currentPageAllProducts, setViewProducts, showCount, setShowCount, viewCount, filterNavbarData:filteredSpecifications ,  setViewCount, setCurrentPageAllProducts, viewProducts, offerProduct, setOfferProduct}}/>
                    </div>
                    <Footer/>
                </div>
                :  <Loading/>}
            </div> 
    );
};

export { ChildProductsViews };
