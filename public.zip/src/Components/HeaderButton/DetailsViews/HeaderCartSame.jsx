import { Link } from 'react-router-dom';
import { utilsHelper } from '../../../UTILS/utils';

const HeaderCartSame = ({infos}) => {
    let serverPort = 'http://localhost:3009'
    let newImages = infos.infos.images.length ? infos.infos.images : [];
    let newImageCollection = [];
    for(let i = 0; i < newImages.length; i ++){
        if(newImages[i].indexOf('ryanscomputers') === -1){
            newImageCollection.push(serverPort+newImages[i])
        }
    } 
    return (
        <div className='header__cart__cover__header__cart'>
            <div className='header__cart__container'> 
                <div className='image__container'>
                {newImageCollection.length ? 
                    <Link to={`/${infos.visible__url}_-_${infos.parent__father}`}>
                        <img src={newImageCollection[0]} alt="" /> 
                    </Link> :  
                    <Link to={`/${infos.visible__url}_-_${infos.parent__father}`}>
                        <img src='/sorry__image.jpg' alt="" />
                    </Link> 
                }
                </div>
                <div className='info__container'>
                    <Link className='buy__now__link' to={`/${infos.visible__url}_-_${infos.parent__father}`}>
                    <p className='title'>{utilsHelper.stringOperations.stringCutter(infos.infos.title)}</p> </Link>
                    <p className='price'> {infos.infos.current__price} tk</p>
                </div>
            </div>
        </div>
    );
};

export default HeaderCartSame;