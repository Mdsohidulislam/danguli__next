
const QuickView = () => {
    return (
        <div className='quick__view__main'>
            <h1>Hello World Hello Quick View</h1>
        </div>
    );
};

export default QuickView;