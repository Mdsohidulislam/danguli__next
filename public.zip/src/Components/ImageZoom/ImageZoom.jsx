
import React from 'react';
import Magnifier from "react-magnifier";

const ImageZoom = ({imgSrc}) => {

    // let productsTitle = [
    //     {
    //         "title": "Recommended For You",
    //         "child": false,
    //         "child__text": "Laptop Accessories",
    //         "link": "/"
    //     },{
    //         "title": "TODAY HOT DEALS",
    //         "child": false,
    //         "child__text": "Laptop Accessories",
    //         "link": "/"
    //     },
    //     'FEATURED PRODUCTS',
    //     'INNOVATIVE GADGETS',
    //     'OUR PARTNERS',
    //     'FlashSale',
    //     'Mall',
    //     'Collections',
    //     'Categories',
    //     'Most Popular',
    //     'Just For You',
    //     'Latest arrivals and trends release. New possibilities. Better access',
    //     ' New Arrivals',
    //     'Top-ranked Products',
    //     'Customized products',
    //     'CONSUMER ELECTRONICS',
    //     'APPAREL',
    //     'VEHICLE PARTS & ACCESSORIES'
    // ]
    
    return (
        <div>
            <Magnifier zoomFactor={1} mgShowOverflow={false} mgBorderWidth={0} mgShape={'square'} mgHeight={200} mgWidth={200} src={imgSrc.link ? imgSrc.src : `http://localhost:3009`+imgSrc.src} className='image__zoom__container'/>
        </div>
    );
};

export default ImageZoom;
