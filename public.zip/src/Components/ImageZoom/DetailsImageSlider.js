import React, { useContext } from "react";
import Slider from "react-slick";
import { productDetailsContext } from "../ProductDetails/ProductDetails";

const  SimpleSlider =  () => {
    
    const {productItem, setImgSrc} = useContext(productDetailsContext);
    

    const settings = {
      dots: false,
      infinite: true,
      speed: 500,
      slidesToShow: 4,
      slidesToScroll: 1,
    };
    return (
      <div className="my__small__image__slider">
      {productItem.infos.images.length? 
        <Slider {...settings} className='my__slider__engine'>

            {
                productItem.infos.images.map((info, index) => {
                    return             <div key={index} className="image__item" onClick={()=> setImgSrc({src: info, link: false})}>
                    <img src={`http://localhost:3009`+info} alt='hello js'/>
                </div> 
                })
            }
        </Slider>
        :""}
      </div>
    ); 
}


export default SimpleSlider;