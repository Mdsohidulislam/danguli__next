import axios from 'axios';
import commaNumber from 'comma-number';
import { useEffect, useState } from 'react';
import { SideBySideMagnifier } from 'react-image-magnifiers';
import { useParams } from 'react-router-dom';
import { utilsHelper } from '../../UTILS/utils';
import Footer from '../Footer/Footer';
import HelpFooter from '../FooterBanner/HelpFooter';
import ChildImagesArray from '../HeaderButton/ChildImagesArray';
import DetailsBuyButtonGroup from '../HeaderButton/DetailsBuyButtonGroup';
import MultiHeaderButton from '../HeaderButton/MultipleHeaderButton';
import SingleHeaderButton from '../HeaderButton/SingleHeaderButton';
import { Loading, LoadingSmall } from '../Loading/Loading';
import QAndA from '../ProductDetails/Asisst/QAndA';
import QuestonForm from '../ProductDetails/Asisst/QuestonForm';
import Review from '../ProductDetails/Asisst/Review';
import ReviewForm from '../ProductDetails/Asisst/ReviewForm';
import Specification from '../ProductDetails/Asisst/Specification';
import CartBox from '../SideBar/CartBox';
import TopNavbar from '../TopNavbar/TopNavbar';
import TopSmallNavbar from '../TopNavbar/TopSmallNavbar';

const ImageMagnifier = () => {
    let serverPort = 'http://localhost:3009'
    const [imgSrc, setImgSrc] = useState('');
    const [detailsShow, setDetailsShow] = useState(1);
    const [prevQAA, setPrevQAA] = useState([0,1,2,3,4,5,6,7,8,9,10]); 
    const [productItem, setProductItem] = useState({});
    const [productDetails, setProductDetails] = useState({});
    const [productOverviews, setProductOverviews] =useState({}); 
    const [productSpecification, setProductSepcifications] = useState({}); 
    const [allImages, setAllImages] = useState([]);
    const [sameBrandProducts, setSameBrandProducts] = useState([]);
    const [similarProducts, setSimilarProducts] = useState([]);
    const [browsingHistory, setBrowsingHistory] = useState([]);
    const [peopleAlsoBought, setPeopleAlsoBought] = useState([]);
    const [currentPath, setCurrentPath] = useState('');
    
    let param = useParams(); 
    useEffect(()=>{
        setImgSrc('')
        setDetailsShow(1)
        setPrevQAA([0,1,2,3,4,5,6,7,8,9,10])
        setProductItem({})
        setProductDetails({})
        setProductOverviews({})
        setProductSepcifications({})
        setAllImages([])
        setSameBrandProducts([])
        setSimilarProducts([])
        setBrowsingHistory([])
        setPeopleAlsoBought([])
        setCurrentPath('')
        let url = param.urls.split('_-_')[0]; 
        let parent__father = param.urls.split('_-_')[1]; 
        
        getCurrentPageProductData(url, parent__father)
        setCurrentPath(param.urls)
    },[]);
    const getCurrentPageProductData  = (url, parent__father) => {
        axios.get('http://localhost:3009/getsSingleProductDetailsProduct',{headers:{url, parent__father}})
        .then(res => {   
            let {newInfo} = res.data.infos;  
            let currentProduct = {...newInfo};
            handleGetMoreProducts(currentProduct)
            let currentProductDetails = {...newInfo};
                currentProductDetails.infos = currentProduct.infos.details
                
            let currentProductSpecifications = {...newInfo};
            currentProductSpecifications.infos = currentProduct.infos.specifications
            delete currentProduct.infos.details;
            delete currentProduct.infos.specifications; 

            let newImages = newInfo.infos.images.length ? newInfo.infos.images : [];
            let newImageCollection = [];
            for(let i = 0; i < newImages.length; i ++){
                if(newImages[i].indexOf('ryanscomputers') === -1){
                    newImageCollection.push(serverPort+newImages[i])
                }
            }    
            newImageCollection = newImageCollection.length ? newImageCollection : ['/sorry__image.jpg','/sorry__image.jpg','/sorry__image.jpg']
            setProductItem(currentProduct);
            setProductDetails(currentProductDetails);
            setProductSepcifications(currentProductSpecifications)
            setImgSrc(newImageCollection[0]);  
            setAllImages(newImageCollection);
            document.title = newInfo.infos.title
        }).catch(err => {
            console.log(err.message);
        })     
    }
    
    const handleGetMoreProducts = (infos) => {
        

        axios.get('http://localhost:3009/getSingleBrowsingProduct',{headers:{user__key: localStorage.getItem('user__key'), database: 'browsing__history'}}).then(res => {  
            if(res.data.status__code === 200){
                let {products} = res.data;      
                let storedProductIdes = []; 
                let suffleArray = products.sort(()=> Math.random() - 0.5) 
                
                suffleArray.forEach((info) => {
                    if(storedProductIdes.indexOf(info.product__id) === -1){
                        storedProductIdes.push(info.product__id);
                        
                    }
                })  
                
                if(storedProductIdes.indexOf(infos.product__id) === -1){
                    infos.post__time = utilsHelper.timeManagements.momentTimeMaker(); 
                    infos.user__key = localStorage.getItem('user__key');
                    axios.post('http://localhost:3009/postSingleBrowsingProduct',{infos, database: 'browsing__history'}).then(res => {
                        if(res.data.status__code === 200){ 
                            let newBrowsingHistory = [...suffleArray];
                                newBrowsingHistory.push({...infos, user__key: localStorage.getItem('user__key')})
                                setBrowsingHistory(newBrowsingHistory); 
                        }
                    }).catch(err  => {
                        console.log(err.message);
                    }) 
                }else{
                    setBrowsingHistory(suffleArray.slice(0,30))   
                }
            }
        }).catch(err => {
            console.log(err);
        })
    
        let {child, brand, parent, parent__father} = infos; 
        axios.get('http://localhost:3009/getSingleCategory',{headers:{category: parent}}).then(res => { 
            if(res.data.status__code === 200){
                let {products} = res.data;      
                let suffleArray = products.sort(()=> Math.random() - 0.5) 
                setSimilarProducts(suffleArray.slice(0,30))  
            }
        }).catch(err => {
            console.log(err);
        })

        axios.get('http://localhost:3009/getSingleBrand',{headers:{brand}}).then(res => { 
            if(res.data.status__code === 200){ 
                
                let {products} = res.data;      
                let suffleArray = products.sort(()=> Math.random() - 0.5) 
                setSameBrandProducts(suffleArray.slice(0,30))  
            }
        }).catch(err => {
            console.log(err);
        })

        axios.get('http://localhost:3009/getSingleOfferCategoryData',{headers:{table: 'pre__order'}})
        .then(res =>{
          if(res.data.status__code === 200){
            let suffleArray = res.data.product.sort(()=> Math.random() - 0.5)
            setPeopleAlsoBought(suffleArray.slice(0,30));
          }
        }).catch(err => {
          console.log(err.message);
        })
    }  

    const handleUrlValidator = () => {
        if(param.urls !== currentPath){
            setImgSrc('')
            setDetailsShow(1)
            setPrevQAA([0,1,2,3,4,5,6,7,8,9,10])
            setProductItem({})
            setProductDetails({})
            setProductOverviews({})
            setProductSepcifications({})
            setAllImages([])
            setSameBrandProducts([])
            setSimilarProducts([])
            setBrowsingHistory([])
            setPeopleAlsoBought([])
            setCurrentPath('')
            let url = param.urls.split('_-_')[0];
            let index = param.urls.split('_-_')[1]; 
            let parent__father = param.urls.split('_-_')[2]; 
            
            getCurrentPageProductData(url, parent__father)
            setCurrentPath(param.urls)
        }
    } 
    handleUrlValidator(); 
    return (
        <div>    
                    {productItem.product__id? 
                    <div>
                        <TopSmallNavbar/>
                        <TopNavbar/>
                        <CartBox/>    
                        <div className='detail__page__two__row__container'>
                            <div className='detail__page__left__row__container'> 
                                <div className='new__product__details__container'>
                                    <div className="top__view__container__image__and__info">
                                        {productItem.product__id ? 
                                        <div className='image__container'>
                                        <SideBySideMagnifier imageSrc={imgSrc} alwaysInPlace={true} fillAvailableSpace={true}/>
                                         
                                        {allImages.length ? <ChildImagesArray infos={{ allImages, setImgSrc}}/> : ""}
                                        </div> :""}
                                        {productItem.product__id ?
                                        <div className='info__container'>
                                            <div className='product__title'>{productItem.infos.title}</div>
                                            <div className='title__style overviews'><p className='head'>Product Key</p>  <p className='head__value'>{productItem.product__id}</p></div>
                                            <div className='title__style current__price'><p className='head'>Current Price</p>  <p className='head__value'>{commaNumber(productItem.infos.current__price)} tk</p></div>
                                            <div className='title__style previous__price'><p className='head'>Previous Price</p>  <p className='head__value'>{commaNumber(productItem.infos.previous__price)} tk</p></div>
                                            <div className='quick__overview'>
                            <h3 style={{marginTop:'30px'}}>Quick Overview</h3>
                            {
                                productItem.infos.overviews.map((info, index) => {
                                    return <p className='quick__overview__child__item' key={index}>{info}</p>
                                })
                            }
                        </div>
                        <DetailsBuyButtonGroup/>

                                        </div>  :""}
                                    </div>
                            
                                    <div className='product__details__banner'> 
                                            {/* <img src='details__banner.webp' alt='hello world'/> */}
                                            {sameBrandProducts.length && similarProducts.length ? <SingleHeaderButton infos={{sameBrandProducts, similarProducts}}/> : <LoadingSmall/> }
                                            
                                    </div>
                                    <div className='button__container'>
                                        <button onClick={()=>setDetailsShow(1)} className={detailsShow === 1 ? "active" : ''}>SPECIFICATION</button>
                                        <button onClick={()=>setDetailsShow(2)}  className={detailsShow === 2 ? "active" : ''}>DETAILS</button>
                                        <button onClick={()=>setDetailsShow(3)}  className={detailsShow === 3 ? "active" : ''}>REVIEW</button>
                                        <button onClick={()=>setDetailsShow(4)}  className={detailsShow === 4 ? "active" : ''}>QUESTION &  ANSWER</button>
                                    </div>

                                    {detailsShow === 1 && productSpecification.product__id ? 
                                    <div className='details__items__container'>
                                        {
                                                productSpecification.infos.map((info, index) => {
                                                return <Specification info={info} key={index}/>
                                            })
                                        }
                                    </div>  :  ""}

                                    {detailsShow === 2 && productDetails.product__id ?
                                    <div className='details__description__container'>
                                        {
                                            productDetails.infos.map((info, index) => {
                                                return <info.tag key={index}>{info.text}</info.tag>
                                            })
                                        }
                                    </div>
                                    : ""}
                                    {detailsShow === 3 ?
                                    <div className='product__review__items__container' id='product__review'> 
                                        <Review/>
                                        <Review/>
                                        <Review/>
                                        <Review/>
                                        <Review/>
                                        <Review/>
                                        <Review/> 
                                        <ReviewForm/>
                                    </div>   :""}
                                    {detailsShow === 4  ?
                                        <div className='question__and__ans__container'>
                                                {prevQAA.length? 
                                                <div>
                                                    {
                                                        prevQAA.map((info, index) =>{
                                                            return <QAndA key={index} info={info}/>
                                                        })
                                                    }
                                                    
                                                </div> :""}
                                                <QuestonForm productId={'111.111.11.33.55'}/> 
                                        </div> 
                                            :""}

                                </div> 
                                <div className='detail__page__right__row__container'>
                                    {/* <HeaderTitleOne/>
                                <SliderSliderVertical/> */}
                            </div>
                            </div>
                        </div> 
                        {
                            peopleAlsoBought.length && browsingHistory.length ? <MultiHeaderButton infos={{peopleAlsoBought, browsingHistory}}/> : <LoadingSmall/>
                        }
                        
                        <HelpFooter/>
                        <Footer/>
                    </div>

                : <Loading/>}
        </div>
        
    );
};

export default ImageMagnifier;