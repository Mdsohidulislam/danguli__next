import { faAnglesRight } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import axios from 'axios';
import React, { useContext, useState } from 'react';
import { Link } from 'react-router-dom';
import { danguliContext } from '../../DanguliContext';
import { serverHelper } from '../../UTILS/ServerUtils';

const MultipleImageUpload = () => {

  const {links} = useContext(danguliContext);

  // overviews state start
  const [showOverviews, setShowOverviews] = useState(false);
  const [overviewsArray, setOverviewsArray] = useState([]);
  const [overviewsInfo, setOverviewsInfo] = useState({});
  // overviews state end
  // product similar info start
  const [productInfo, setProductInfo] = useState({});
  const [collection, setCollection] = useState({name: '', complete: false, infos: []});
  const [category, setCategory] = useState({name: '', complete: false, infos: []});
  const [type, setType] = useState({name: '', complete: false, infos: {}}); 
  const [files, setFiles] = useState([]);
  // product similar info end
  // specification related state start

  const [specificationInfo, setSpecificationInfo] = useState({});
  const [addNewSpecification, setAddNewSpecification] = useState({parent: 'empty'});
  const [addNewTable, setAddNewTable] = useState({});
  const [addActiveRow, setAddActiveRow] = useState(false);
  const [addActiveTable, setAddActiveTable] = useState(false);

  // specification related state end

  // function object module scaffolding  start
  const functionsHelper = {}
  // function object module scaffolding  end
  functionsHelper.handleProductUploadSubmit = e => {
    e.preventDefault();

    console.log('Hello world');
  }

  functionsHelper.handleChange = ({target: {name, value}}) => {
      let newInfo = {...productInfo};
      newInfo[name] = value;
      setProductInfo(newInfo);
  }

  functionsHelper.handleChangeFile = ({target: {files}}) => {

    let output = document.getElementById('image__preview__container');
      output.innerHTML = '';
    for(let i = 0; i  < files.length; i++){
        let file = files[i];

      let div = document.createElement('div');
          
        div.innerHTML = `<img alt='uploaded images' src="${URL.createObjectURL(file)}"></img>`;

        output.insertBefore(div , null);
    }
    setFiles(files);
  }

  functionsHelper.handleClickOverviewsInsertButton = (e) => {

    e.preventDefault();

      let number = Number(prompt('Enter total overview length'));

      let arrayLength = [];
      for(let i = 1;  i < number+1 ; i++){
        arrayLength.push(i);
      }
    setOverviewsArray(arrayLength);
    setShowOverviews(true);
  }

  functionsHelper.handleSubmitOverviewsInsertButton =  (e) => {
    e.preventDefault(); 
    
    let currentInfo = {...overviewsInfo};

    for(const key in currentInfo){
      let value = currentInfo[key];
      console.log(`${key} === ${value}`);
    }
    
  }

  functionsHelper.handleChangeOverviews =  ({target: {name, value}}) => {

      let newInfo = {...overviewsInfo};
          newInfo[name] = value;
          setOverviewsInfo(newInfo);
  }
  
  functionsHelper.handleChangeCollections = ({target: {name, value}}) => {
    setCollection({name: '', complete: false, infos: []});
    setCategory({name: '', complete: false, infos: []}); 
    setType({name: "", complete: false, infos: []});
    
    if(value !== 'default' && value !== 'add__a__collection'){

      
      let collectionIndex = value.split('=====')[1]; 
      let currentCategory = links[Number(collectionIndex)];
      let newInfo = {name: value.split('=====')[0], complete: true, infos:currentCategory.links};
      setCollection(newInfo); 
    }

    if(value === 'add__a__collection'){
      let cName = prompt('Enter collection name');
      setCollection({name: cName, complete: true, infos: []})
    }
  } 

  
  functionsHelper.handleChangeCategory = ({target: {name, value}}) => {
    setCategory({name: "", complete: false, infos: []}); 
    setType({name: "", complete: false, infos: []});

    if(value !== 'default' && value !== 'add__a__category'){
      let data = collection.infos[Number(value.split('=====')[1])]
      setCategory({name: value.split('=====')[0], complete: true, infos: data.links})
    }

    if(value === 'add__a__category'){
      let cName = prompt('Enter category name');
      setCategory({name: cName, complete: true, infos: []})
    }

  }

  functionsHelper.handleChangeType = ({target: {name, value}}) =>  {
    
    setType({name: "", complete: false, infos: []});
    
    if(value !== 'default' && value !== 'add__a__type'){ 
      let child = value.split('=====')[0]; 
    axios.get('http://localhost:3009/getAllChildForPostProduct', {headers: {grandfather: collection.name, parent: category.name, child}})
    .then(res  =>  { 
      
      let {specifications}  = res.data;
      
      let result = serverHelper.serverHelperUtils.specificationsDataConverter(specifications);
      let items = {};
      let max = 0;

      result.forEach((info, index) => {
        let itemLength = info.info.length;
        if(max < itemLength){
          max = itemLength;
          items = info;
        }
      }) 
      setType({name: child, infos: items, complete: true});
      
      
    }).catch(err => {
      console.log(err.message);
    })

    }
    
    if(value === 'add__a__type'){
      let cName = prompt('Enter type name');
       setType({name: cName, complete: true, infos: []})
    }

    // setType({name: value.split('=====')[0], complete: true, infos: []})
  }

  // functionsHelper.handleProductIntroSubmit = (e) => {
  //     e.preventDefault(); 
  //     let formData = new FormData();
  //     let pathLinks  = [];
  //     _.forEach(files, (info, index) => {  
  //       let randomUid = uid(20);
  //       let random = Math.ceil(Math.random() * 999999);
  //       let fileExtension = info.name.split('.');
  //           fileExtension = fileExtension[fileExtension.length -1]; 
  //       let links = `./testUpload/${randomUid}__${productInfo.product__id}__${random}.${fileExtension}`;
  //       pathLinks.push(links);
  //       formData.append('images', info);
  //       formData.append('links', links)
  //     })   
  //     console.log(pathLinks);

  //     axios.post('http://localhost:3009/multipleImageUpload', formData, {headers: {'Content-Type':'multipart/form-data'}})
  //     .then(res => { 
  //       formData.delete('images');
  //       formData.delete('links');
  //       console.log(res);
  //     }).catch(err => {
  //       console.log(err.message);
  //     })
  // }

  functionsHelper.handleProductIntroSubmit = (e) => {
    e.preventDefault(); 
    console.log(productInfo);
}
 
  functionsHelper.handleSpecificationInputValueChange = ({target: {name, value}}) => {
    let newInfo = {...specificationInfo};
      newInfo[name] = value;
      setSpecificationInfo(newInfo);
  } 
  functionsHelper.handleProductSpecificationsSubmit = (e) => {
      e.preventDefault(); 
      let collections = [];
      let data = []
      for(var single in specificationInfo){   
        let header = single.split('_-----_')[0];
              header = header.replace(/_----_/g, ' '); 
          if(collections.indexOf(header) === -1){
              collections.push(header);
              data.push({title: header, infos: [{title: single.split('_-----_')[1].split('_------_')[0].replace(/_--------_/g, ' '), info: specificationInfo[single]}]});
          }else{
            let index = collections.indexOf(header);
            data[index].infos.push({title: single.split('_-----_')[1].split('_------_')[0].replace(/_--------_/g, ' '), info: specificationInfo[single]});
          }
      } 
      console.log(data);
      console.log(collections);
  }

  // let str = 'Audio_----_&_----_Camera_-----_Microphone._------_9_-------_1'
  // console.log(str.split('_-----_')[1].split('_------_')[0]);
  
  
  const handleAddOneMoreTableSubmit = (title, index) => {
    
    if(title === addNewTable.parent){ 
      let newInfo = {...type}
      let data = newInfo.infos.info; 
      let firstData = data.slice(0, index+1);
      let lastData = data.slice(index+1, data.length -1);
      lastData.unshift({title: addNewTable.value, infos: []})
      newInfo.infos.info =  [...firstData, ...lastData] ;
      setType(newInfo) 

      let inputs =  document.querySelectorAll('.addNewValueSpecifications');
      inputs.forEach((info) => {
        info.value = '';
      })
      setAddActiveRow(false);
      setAddActiveTable(false);
    }else{
      setAddActiveTable(false);
    }
  }

  const handleAddOneMoreSubmit =  (title,  index) => {

    if(title === addNewSpecification.parent){
      let newInfo = {...type}
      let data = newInfo.infos.info; 
      data[index].infos.push({title: addNewSpecification.value, info: ''})
      setType(newInfo);

      
      let inputs =  document.querySelectorAll('.addNewValueSpecifications');
      inputs.forEach((info) => {
        info.value = '';
      })
      setAddActiveRow(false);
      setAddActiveTable(false);
    }else {
      setAddActiveRow(false);
    }
} 

const handleActiveRow = () => {
  setAddActiveRow(true);
}

const handleActiveTable = () => {
  setAddActiveTable(true);
}
// details state start
  const [detailsItems, setDetailsItems] =  useState({})
  const [insertItems, setInsertItems] = useState([]); 
  const [detailsView, setDetailsView] = useState([]);
// details state end

functionsHelper.handleSubmitDetail = (e) => {
  e.preventDefault();
}

functionsHelper.handleInsertDetail = (value) => {
  let newValue = [...insertItems];
      newValue.push(value);
      console.log(newValue);
      setInsertItems(newValue);
}

functionsHelper.handleChangeInsertInput = ({target:{name, value}}) => {
  let newInfo = {...detailsItems};
        newInfo[name] = value;
      let products = [...detailsView];
      
      for(var item in newInfo){ 
        let value  = newInfo[item];
        let head  = item.split('_---_')[0]
        let position  = Number(item.split('_---_')[1]);
        let html = `<${head}>${value}</${head}>`
        
        products[position] = html;
}
setDetailsView(products);  
}

let names = [
  `<h1>Hello world</h1>`,
  `<h1>Hello world</h1>`,
  `<h1>Hello world</h1>`,
  `<h1>Hello world</h1>`,
  `<h1>Hello world</h1>`,
  `<h1>Hello world</h1>`,
  `<h1>Hello world</h1>`,
  `<h1>Hello world</h1>`
]

console.log(names.join(""));



  functionsHelper.handleRemoveInsertField = (index) => {
      let newInfo = [...insertItems];
          newInfo.splice(index, 1);
          setInsertItems(newInfo)
  }
  
  function markerMaker () {
    return {__html: detailsView.join("")}
  }

  return (
    <div className='product__upload__container'>
      <div className='product__item__insert__container'>
          <div className='upload__items__container'>
              <form onSubmit={functionsHelper.handleProductIntroSubmit}>
                  <div className='form__item'>
                  <p>Select Collection</p>
                  <select disabled={links.length ? false : true} onChange={functionsHelper.handleChangeCollections} name='collection'>
                    <option value='default'>Select Collection</option> 
                    {
                      links.length ? 

                        links.map((info, index) =>  <option key={index} value={`${info.link__name}=====${index}`}>{info.link__name}</option> )

                        : ""
                    }  
                    <option value='add__a__collection'>Add A Collection</option>
                  </select>
                </div> 
                <div className='form__item'>
                  <p>Select Category</p>
                  <select disabled={collection.complete ? false : true} onChange={functionsHelper.handleChangeCategory} name='category'>
                    <option value='default'>Select Category</option> 
                    {collection.infos.map((info, index) => <option value={`${info.parent}=====${index}`} key={index} >{info.parent}</option>)}
                    <option value='add__a__category'>Add A Category</option>
                  </select>
                </div>  
                <div className='form__item'>
                  <p>Select  Type</p>
                  <select disabled={category.complete ? false : true} onChange={functionsHelper.handleChangeType} name='type'>
                    <option value='default'>Select Type</option> 
                    {category.infos.map((info, index) => <option value={`${info.child}=====${index}`} key={index} >{info.child}</option>)}
                    <option value='add__a__type'>Add A Type</option>
                  </select>
                </div> 
                <div className='form__item'>
                  <p>Product Title</p>
                    <input disabled={type.complete ? false : true} onChange={functionsHelper.handleChange} name='product__title' placeholder='Enter Product Title'  required></input>
                </div>
                <div className='form__item'>
                    <p>Upload Images</p>
                    <input disabled={type.complete ? false : true} accept='image/*' multiple onChange={functionsHelper.handleChangeFile} type='file' name='product__title' placeholder='Enter Product Title'  required></input>
                </div>
                  <div className='form__item form__item__many'>
                    <div>
                      <p>Product ID</p>
                      <input  disabled={type.complete ? false : true} onChange={functionsHelper.handleChange} name='product__id' placeholder='Enter Product ID'  required></input>
                    </div>
                    <div>
                      <p>Current Price</p>
                      <input  disabled={type.complete ? false : true} onChange={functionsHelper.handleChange} name='current__price' placeholder='Enter current price'  required></input>
                    </div>
                    <div>
                      <p>Previous Price</p>
                      <input  disabled={type.complete ? false : true} onChange={functionsHelper.handleChange} name='previous__price' placeholder='Enter previous price'  required></input>
                    </div>
                    <div>
                      <p>Cost Per Item</p>
                      <input  disabled={type.complete ? false : true} onChange={functionsHelper.handleChange} name='cost__per__item' placeholder='Enter cost per item'  required></input>
                    </div>
                  </div>
                  <div className='form__item'>
                  <button disabled={type.complete ? false : true}  type='submit' className='insert__button'>Save Form</button>
              </div>
              </form>

              <form onSubmit={showOverviews? functionsHelper.handleSubmitOverviewsInsertButton : functionsHelper.handleClickOverviewsInsertButton}>
              {
                !showOverviews ? 
                <div className='form__item'>
                    <button disabled={type.complete ? false : true}  type='submit' className='insert__button'>Insert Quick Overviews</button>
                </div>: ""
              }
                {overviewsArray.length && showOverviews? 
    
                    overviewsArray.map((info, index) => {
                      return <div className='form__item' key={index}>
                            <p>Enter overview item {index}</p>
                            <input name={`overview__${index}`} placeholder={`Enter overview item ${index}`} onChange={functionsHelper.handleChangeOverviews} required/> 
                        </div> 
                    })
    
                :""}
    
                {
                  showOverviews ? 
                  <div className='form__item'>
                      <button type='submit'>Submit Quick Overviews</button>
                  </div>: ""
                }
              </form>
                {type.complete? 
              <form onSubmit={functionsHelper.handleProductSpecificationsSubmit}>
                  {
                    type.infos.info.map ((info,  index) => {
                      return <div className='form__item form__item__specifications' key={index}>
                                    <p className='specification__header'>{info.title}</p>
                                    {
                                      info.infos.map((inputInfo, InputIndex) => {
                                        return <div className='specification__input__box' key={InputIndex}>
                                                      <input type='text' disabled placeholder={inputInfo.title}></input>
                                                      <input onChange={functionsHelper.handleSpecificationInputValueChange} type='text' name={ info.title.replace(/ /g,'_----_') + '_-----_' +inputInfo.title.replace(/ /g,'_--------_') + '_------_' + index + '_-------_' + InputIndex} placeholder={inputInfo.title} required></input>
                                                  </div>
                                      })
                                    } 
                                      <div className='specification__input__box'>
                                          <input disabled={addActiveRow ? false : true} type='text' className='addNewValueSpecifications'  onChange={(e)=>setAddNewSpecification({value: e.target.value, parent: info.title})} placeholder='Enter Value' required></input>
                                          <button type='button' onClick={()=> addActiveRow ? handleAddOneMoreSubmit(info.title, index) : handleActiveRow('hello')}>Add A Row</button>
                                      </div> 
                                      <div className='specification__input__box'>
                                        <input  disabled={addActiveTable ? false : true}  type='text' className='addNewValueSpecifications'  onChange={(e)=>setAddNewTable({value: e.target.value, parent: info.title})} placeholder='Enter Table Name' required></input>
                                        <button type='button' onClick={()=>addActiveTable ? handleAddOneMoreTableSubmit(info.title,  index) : handleActiveTable("hello")}>Add A Table</button>
                                      </div> 
                                </div>
                                
                    })
                  } 
                  <button type='submit'>Submit</button>
              </form>  :""}
              <form onSubmit={functionsHelper.handleSubmitDetail}>
                <p className='specification__header'>Add Product Details</p>
                <div className='insert__button__refer__container'>
                    <button type='button' className='insert__refer__button' onClick={()=> functionsHelper.handleInsertDetail("h1")}>h1</button>
                    <button type='button' className='insert__refer__button' onClick={()=> functionsHelper.handleInsertDetail("h2")}>h2</button>
                    <button type='button' className='insert__refer__button' onClick={()=> functionsHelper.handleInsertDetail("h3")}>h3</button>
                    <button type='button' className='insert__refer__button' onClick={()=> functionsHelper.handleInsertDetail("h4")}>h4</button>
                    <button type='button' className='insert__refer__button' onClick={()=> functionsHelper.handleInsertDetail("p")}>p</button>
                    <button type='button' className='insert__refer__button' onClick={()=> functionsHelper.handleInsertDetail("b")}>p (b)</button> 
                </div>  


                  {
                    insertItems.map((info, index) => {
                      return     <div className='form__item' key={index}>
                      <input name={`${info}_---_${index}`} onChange={functionsHelper.handleChangeInsertInput} placeholder={`Enter ${info} value`} required></input>
                      <button onClick={()=> functionsHelper.handleRemoveInsertField(index)}>Remove</button>
                    </div>
                    })
                  }
                  <button type='submit'>Submit</button>
              </form>
              {
                detailsView.length ?                   <div className='products__details__container' dangerouslySetInnerHTML={markerMaker()}>
              
                </div> :  ""
              }
          </div>
      </div>

      <div className='preview__container'>
            {
              type.complete ? 
            <div className='category__or__product__link__container'>
              <Link to='/' className='body__header__middle__Link'>Home</Link>
              <FontAwesomeIcon className='body__header__middle__arrow' icon={faAnglesRight}/> 
              <Link to={`/allProducts?father=${collection.name}`} className='body__header__middle__Link'>{collection.name}</Link>
              <FontAwesomeIcon className='body__header__middle__arrow' icon={faAnglesRight}/> 
              <Link to={`/parentProducts?parentFather=${collection.name}&&parent=${category.name}`} className='body__header__middle__Link'>{category.name}</Link>
              <FontAwesomeIcon className='body__header__middle__arrow' icon={faAnglesRight}/> 
              <Link to={`/childProducts?parentFather=${collection.name}&&parent=${category.name}&&child=${type.name}`} className='body__header__middle__Link'>{type.name}</Link>
            </div> : ""
            }
            <div className='image__preview__container' id='image__preview__container'></div>
      </div>
    </div>
  );
};

export default MultipleImageUpload;

