const  data  =  [
    {
        "title": "General",
        "infos": [
            {
                "title": "Brand",
                "info": "Asus"
            },
            {
                "title": "Model",
                "info": "Asus X515MA"
            },
            {
                "title": "Part No",
                "info": "BQ636T-X515MA"
            }
        ]
    },
    {
        "title": "Processor",
        "infos": [
            {
                "title": "Processor Brand",
                "info": "Intel"
            },
            {
                "title": "Processor Type",
                "info": "Intel Celeron Dual Core"
            },
            {
                "title": "Processor Model",
                "info": "CDC N4020"
            },
            {
                "title": "Processor Base Frequency",
                "info": "1.10 GHz"
            },
            {
                "title": "Processor Max Turbo Frequency",
                "info": "2.80 GHz"
            },
            {
                "title": "Processor Core",
                "info": "2"
            },
            {
                "title": "Processor Thread",
                "info": "2"
            },
            {
                "title": "CPU Cache",
                "info": "4MB"
            }
        ]
    },
    {
        "title": "Memory",
        "infos": [
            {
                "title": "RAM",
                "info": "4GB"
            },
            {
                "title": "Installed RAM Details",
                "info": "1 x 4GB Non-Removable"
            },
            {
                "title": "RAM Type",
                "info": "DDR4"
            },
            {
                "title": "Total RAM Slot",
                "info": "2"
            },
            {
                "title": "Empty/Expansion RAM Slot",
                "info": "1"
            },
            {
                "title": "Max. RAM Support",
                "info": "12GB"
            }
        ]
    },
    {
        "title": "Storage",
        "infos": [
            {
                "title": "Storage",
                "info": "1TB HDD"
            },
            {
                "title": "Installed HDD Type",
                "info": "SATA 3"
            },
            {
                "title": "HDD RPM",
                "info": "5400 RPM"
            },
            {
                "title": "M.2/SSD Expansion Slot",
                "info": "1"
            },
            {
                "title": "Storage Upgrade",
                "info": "Aditional SSD Can be addedsss@@sss@@@sss HDD can be replaced"
            }
        ]
    },
    {
        "title": "Graphics",
        "infos": [
            {
                "title": "Graphics Chipset",
                "info": "Intel UHD Graphics"
            },
            {
                "title": "Graphics Memory Accessibility",
                "info": "Integrated"
            },
            {
                "title": "Graphics Memory",
                "info": "Shared"
            }
        ]
    },
    {
        "title": "Display",
        "infos": [
            {
                "title": "Display Size (Inch)",
                "info": "15.6"
            },
            {
                "title": "Display Type",
                "info": "FHD LED"
            },
            {
                "title": "Display Resolution",
                "info": "1920x1080 (WxH) FHD"
            },
            {
                "title": "Display Surface",
                "info": "Anti-glare"
            },
            {
                "title": "Touch Screen",
                "info": "No"
            },
            {
                "title": "Display Features",
                "info": "Panel Typesssccsssccsssccsssccsssccsss IPSsss@@sss@@@sss 16sssccsssccsssccsssccsssccsss9 aspect ratiosss@@sss@@@sss LED Backlitsss@@sss@@@sss 200nitssss@@sss@@@sss 45% NTSC color gamutsss@@sss@@@sss Screen-to-body ratiosssccsssccsssccsssccsssccsss 83 %"
            }
        ]
    },
    {
        "title": "Ports & Slots",
        "infos": [
            {
                "title": "Optical Drive",
                "info": "No"
            },
            {
                "title": "Multimedia Card Slot",
                "info": "Yes"
            },
            {
                "title": "Supported Multimedia Card",
                "info": "Micro SD"
            },
            {
                "title": "USB 2 Port",
                "info": "2 x USB 2.0 Type-A"
            },
            {
                "title": "USB 3 Port",
                "info": "1 x USB 3.2 Gen 1 Type-A"
            },
            {
                "title": "USB C / Thunderbolt Port",
                "info": "1 x USB 3.2 Gen 1 Type-C"
            },
            {
                "title": "HDMI Port",
                "info": "1"
            },
            {
                "title": "Headphone Port",
                "info": "Combo"
            },
            {
                "title": "Microphone Port",
                "info": "Combo"
            }
        ]
    },
    {
        "title": "Network & Connectivity",
        "infos": [
            {
                "title": "WiFi",
                "info": "WiFi 5 (802.11ac)"
            },
            {
                "title": "Bluetooth",
                "info": "Bluetooth 4.1"
            }
        ]
    },
    {
        "title": "Audio & Camera",
        "infos": [
            {
                "title": "Audio Properties",
                "info": "SonicMastersss@@sss@@@sss Audio by ICEpower"
            },
            {
                "title": "Speaker",
                "info": "Yes"
            },
            {
                "title": "Microphone.",
                "info": "Yes"
            },
            {
                "title": "WebCam",
                "info": "Yes"
            }
        ]
    },
    {
        "title": "Keyboard",
        "infos": [
            {
                "title": "Keyboard Layout",
                "info": "Chiclet Keyboard"
            },
            {
                "title": "Keyboard Back-lit",
                "info": "Yes"
            },
            {
                "title": "Num Key pad",
                "info": "Yes"
            },
            {
                "title": "Pointing Device",
                "info": "TouchPad"
            }
        ]
    },
    {
        "title": "Security",
        "infos": [
            {
                "title": "Finger Print Sensor",
                "info": "Yes"
            }
        ]
    },
    {
        "title": "Software",
        "infos": [
            {
                "title": "Operating System",
                "info": "Windows 10 Home"
            }
        ]
    },
    {
        "title": "Physical Description",
        "infos": [
            {
                "title": "Color",
                "info": "Slate Grey"
            },
            {
                "title": "Dimensions",
                "info": "360.2 x 234.9 x 19.9mm"
            },
            {
                "title": "Weight (Kg)",
                "info": "1.80 kg"
            }
        ]
    },
    {
        "title": "Power",
        "infos": [
            {
                "title": "Battery",
                "info": "2 Cell"
            },
            {
                "title": "Battery Capacity",
                "info": "37WH"
            },
            {
                "title": "Battery Type",
                "info": "Li-ion"
            },
            {
                "title": "Adapter Type",
                "info": "33W AC Adapter"
            }
        ]
    },
    {
        "title": "Warranty",
        "infos": [
            {
                "title": "Warranty",
                "info": "2 Year (Battery 1 Year)"
            },
            {
                "title": "Warranty Claim Duration (Approximate)",
                "info": "Estimated Warranty Claim Duration 20 Days. It may take additional time up to 40 days"
            }
        ]
    },
    {
        "title": "Additional Info",
        "infos": [
            {
                "title": "Country Of Origin",
                "info": "Taiwan"
            },
            {
                "title": "Made in/ Assemble",
                "info": "China"
            }
        ]
    }
]

module.exports = data;