
// import axios from 'axios';
// import React, { useEffect, useState } from 'react';
// import { handleDeleteData, momentTimeMaker, stringConverter, stringMacker } from '../../utils';

// const Upload = () => {

//   /// app object module scafollding
//   const app  = {};
//   const [productInfos, setProductInfos] = useState({});
//   const [file, setFile] = useState(''); 
//   const [otherOne, setOtherOne] = useState('');
//   const [otherTwo, setOtherTwo] = useState('');
//   const [otherThree, setOtherThree] = useState('');
//   const [otherFour, setOtherFour] = useState(''); 
//   const [update, setUpdate] = useState(false);
//   const [updateInfo, setUpdateInfo] = useState({});

//   const [prevCategoryNames, setPrevCategoryNames] = useState([]);
//   const [prevCollectionsId, setPrevCollectionsId] = useState([]);
//   const [prevProduct, setPrevProduct] = useState([])


//   const getAllDataCategory =  (collectionName) => {
//     axios.get('http://localhost:3009/getAllCollection',{headers:{collection: collectionName}})
//     .then(res => { 

//         let result = res.data.result;
//         if(res.data.status__code === 200 && result.length){
//             let prevCollectionNam =[]
//             result.forEach(info => {
//                 prevCollectionNam.push(info.name);
//             }) 
//             setPrevCategoryNames(prevCollectionNam);
            
//         }
//     }).catch(err => {
//         console.log(err.message);
//     })
// }
//   const getAllData =  (collectionName) => {
//     axios.get('http://localhost:3009/getAllCollection',{headers:{collection: collectionName}})
//     .then(res => { 

//         let result = res.data.result;
//         if(res.data.status__code === 200 && result.length){
//             let prevCollectionId =[]
//             result.forEach(info => {
//                 prevCollectionId.push(info.product__id);
//             })
//             setPrevProduct(result); 
//             setPrevCollectionsId(prevCollectionId);
//         }
//     }).catch(err => {
//         console.log(err.message);
//     })
// }

// useEffect(()=>{
//     getAllData('product__info');
//     getAllDataCategory('categories');
// },[])

//   app.handleSetCartPhoto = (e) => {  
    
//     let fr = new FileReader(); 
//     fr.onload = () =>{
//         setFile(fr.result)
//     } 
//     fr.readAsDataURL(e.target.files[0]);
    
// }

// function fileReaderOne (one) {
//     let fr = new FileReader(); 
//     fr.onload = () => {
//         setOtherOne(fr.result);
//     } 

//     fr.readAsDataURL(one); 
// }

// function fileReaderTwo  (one ,two)   {
//     let fr = new FileReader();
//     let frT = new FileReader();
//     fr.onload = () => {
//         setOtherOne(fr.result);
//     }
//     frT.onload = () => { 
//         setOtherTwo(frT.result)
//     }

//     fr.readAsDataURL(one);
//     frT.readAsDataURL(two);
// }

// function fileReaderThree  (one ,two, three)   {
//     let fr = new FileReader();
//     let frT = new FileReader();
//     let frTh = new FileReader();
//     fr.onload = () => {
//         setOtherOne(fr.result);
//     }
//     frT.onload = () => { 
//     setOtherTwo(frT.result)
// }

// frTh.onload = () => {
//     setOtherThree(frTh.result)
// }

// fr.readAsDataURL(one);
// frT.readAsDataURL(two);
// frTh.readAsDataURL(three);

// }

// function fileReaderFour (one, two, three ,four) {

//     let fr = new FileReader();
//     let frT = new FileReader();
//     let frTh = new FileReader();
//     let frF = new FileReader();

//     fr.onload = () => {
//         setOtherOne(fr.result);
//     }
//     frT.onload = () => { 
//     setOtherTwo(frT.result)
//     } 
//     frTh.onload = () => {
//         setOtherThree(frTh.result)
//     }
//     frF.onload = () => {
//         setOtherFour(frF.result)
//     }

// fr.readAsDataURL(one);
// frT.readAsDataURL(two);
// frTh.readAsDataURL(three);
// frF.readAsDataURL(four);

// }


// app.Second = (e) =>{  
//     let images = [...e.target.files];  

//     if(images.length === 1) {
//         fileReaderOne(images[0]);
//     }

//     if(images.length === 2){
//         fileReaderTwo(images[0],images[1]);
        
//     } 

//     if(images.length === 3){
//         fileReaderThree(images[0], images[1], images[2]);
//     }

//     if(images.length === 4){
//         fileReaderFour(images[0], images[1], images[2], images[3]);
//     }
    
// }

// const handleChange = (e) =>  {
//     let newInfo = {...productInfos};
//     newInfo[e.target.name] = e.target.value;
//     setProductInfos(newInfo);
// }

// const handleUpdateChange = (e) => {
//     let newInfo = {...updateInfo};
//     newInfo[e.target.name] = e.target.value;
//     setUpdateInfo(newInfo);
// }

// app.hadleSubmit = (e) => {
//     e.preventDefault();
//     let images = [file];
//     if(otherOne.length){
//         images.push(otherOne);
//     }

//     if(otherTwo.length){
//         images.push(otherTwo);
//     }

//     if(otherThree.length){
//         images.push(otherThree);
//     }

//     if(otherFour.length){
//         images.push(otherFour);
//     } 
//     productInfos.images =  JSON.stringify({images}); 
//     productInfos.title = stringMacker(productInfos.title);
//     productInfos.overview = stringMacker(productInfos.overview);
//     productInfos.post__time = momentTimeMaker();
    
    
    
//     if(prevCollectionsId.indexOf(productInfos.id) !== -1){
//         alert(`This ${productInfos.id} id is already exist`)
//     }else{  
//         if(productInfos.category !== 'empty'){

//         axios.post('http://localhost:3009/addProduct',  productInfos)
//         .then(res => {  
//             console.log(res);
//             if(res.data.status__code === 200){
//                 const inputs = document.querySelectorAll('input');
//                 const textarea = document.getElementById('overview');
//                 textarea.value = ''
//                 inputs.forEach(input => {
//                     input.value=''
//                 })     

//                 getAllData('product__info')
//                 setOtherOne('')
//                 setOtherTwo('')
//                 setOtherThree('')
//                 setOtherFour('')
//                 setFile('')
//             } 
//         }).catch(err => {
//             console.log(err.message);
//         })   

//     }else{
//         alert('Please select category')
//     }
//     }
    

// } 

// app.handleUpdateSubmit = (e) => {
//     e.preventDefault();
//     let images = [file];
//     if(otherOne.length){
//         images.push(otherOne);
//     }

//     if(otherTwo.length){
//         images.push(otherTwo);
//     }

//     if(otherThree.length){
//         images.push(otherThree);
//     }

//     if(otherFour.length){
//         images.push(otherFour);
//     }  
    
//     updateInfo.images =  JSON.stringify({images});
 
//     if(updateInfo.id){ 
        
//     }else{ 
//         updateInfo.id = updateInfo.product__id
//     }
//     updateInfo.id = updateInfo.product__id;
//     updateInfo.title = stringMacker(updateInfo.title);
//     updateInfo.overview = stringMacker(updateInfo.overview);

//     console.log(updateInfo);
    
//         if(updateInfo.category !== 'empty'){

//         axios.post('http://localhost:3009/updateProduct',  updateInfo)
//         .then(res => {  
//             console.log(res);
//             if(res.data.status__code === 200){
//                 const inputs = document.querySelectorAll('input');
//                 const textarea = document.getElementById('overview');
//                 textarea.value = ''
//                 inputs.forEach(input => {
//                     input.value=''
//                 })     


//                 setOtherOne('')
//                 setOtherTwo('')
//                 setOtherThree('')
//                 setOtherFour('')
//                 setFile('');
//                 setUpdate(false);
//                 setUpdateInfo({});
//                 getAllData('product__info');

//             } 
//         }).catch(err => {
//             console.log(err.message);
//         })   

//         } else {
//             alert('Please select category');
//         } 
// } 

// const handleUpdateHandler = (info) => {
    
//     setUpdate(false);
//     setOtherOne("");
//     setOtherTwo("");
//     setOtherThree("");
//     setOtherFour("");

//     const inputs = document.querySelectorAll('.image__field');
    
//     inputs.forEach(input => {
//         input.value=''
//     })   
    
//     let images =  JSON.parse( info.images).images; 
//     setFile(images[0]);
//     if(images.length === 2){
//         setOtherOne(images[1]);
//     }

//     if(images.length === 3){
//         setOtherOne(images[1]);
//         setOtherTwo(images[2]);
//     }

//     if(images.length === 4){
//         setOtherOne(images[1]);
//         setOtherTwo(images[2]);
//         setOtherThree(images[3]);
//     }

//     if(images.length === 5){
//         setOtherOne(images[1]);
//         setOtherTwo(images[2]);
//         setOtherThree(images[3]);
//         setOtherFour(images[4]);
//     }

//     setUpdateInfo(info);  
//     setUpdate(true);


    
// }

// const handleCancleUpdate  = () => {
//     setUpdate(false);
//     setFile('')
//     setOtherOne("");
//     setOtherTwo("");
//     setOtherThree("");
//     setOtherFour("");
//     setUpdateInfo({});

// }




//     return (
//         <div className='upload__container'>
//         <h1>Hello world</h1>
//         <h1>Hello world</h1>
//         <h1>Hello world</h1>
//         <h1>Hello world</h1>
//         <h1>Hello world</h1>
//         <h1>Hello world</h1>
//         <h1>Hello world</h1>
//         <h1>Hello world</h1>
//         <h1>Hello world</h1>
//         <h1>Hello world</h1>
//         <h1>Hello world</h1>
//         <h1>Hello world</h1>
//         <h1>Hello world</h1>
//         <h1>Hello world</h1>
//         <h1>Hello world</h1>
//         <h1>Hello world</h1>
//         <h1>Hello world</h1>
//         <h1>Hello world</h1>
//         <h1>Hello world</h1>
//         <h1>Hello world</h1>
//         <h1>Hello world</h1>
//         <h1>Hello world</h1>
//         <h1>Hello world</h1>
//         <h1>Hello world</h1>
//         <h1>Hello world</h1>
//         <h1>Hello world</h1>
//         <h1>Hello world</h1>
//         <h1>Hello world</h1>
//         <h1>Hello world</h1>
//         <h1>Hello world</h1>
//         <h1>Hello world</h1>
//         <h1>Hello world</h1>
//         <h1>Hello world</h1>
//         <h1>Hello world</h1>
//         <h1>Hello world</h1>
//         <h1>Hello world</h1>
//         <h1>Hello world</h1>
//         <h1>Hello world</h1>
//         <h1>Hello world</h1>
//         <h1>Hello world</h1>
//         <h1>Hello world</h1>
//         <h1>Hello world</h1>
//         <h1>Hello world</h1>
//         <h1>Hello world</h1>
//         <h1>Hello world</h1>
//         <h1>Hello world</h1>
//         <h1>Hello world</h1>
//         <h1>Hello world</h1>
//         <h1>Hello world</h1>
//         <h1>Hello world</h1>
//         <h1>Hello world</h1>
//         <h1>Hello world</h1>
//         <h1>Hello world</h1>
//         <h1>Hello world</h1>
//         <h1>Hello world</h1>
//         <h1>Hello world</h1>
//             <div className='upload__product__info__container'> 
//                 {update === false ? 
//                 <form onSubmit={app.hadleSubmit}> 
//                     <div>
//                         <p>Product Title</p>
//                         <input type='text' name='title' onChange={handleChange}  placeholder='Enter product title' required/>
//                     </div>
//                     <div className='mini__input'>
//                         {prevCategoryNames.length? 
//                         <div>
//                             <p>Select Category</p>
//                             <select onChange={handleChange} name='category'>    
//                                 <option value='empty'>select category</option> 
//                                 {
//                                     prevCategoryNames.map((info,index) =>  {
//                                         return <option key={index} value={info}>{info}</option> 
//                                     })
//                                 }
//                             </select>
//                         </div> :""}
//                         <div>
//                             <p>Product ID</p>
//                             <input type='text' name='id' onChange={handleChange}  placeholder='Enter product title' required/>
//                         </div>
//                         <div>
//                             <p>Quantity</p>
//                             <input type='number' name='quantity' onChange={handleChange}  placeholder='Enter product Quantity' required/>
//                         </div>
//                         <div>
//                             <p>Previous Price</p>
//                             <input type='number' name='previous__price' onChange={handleChange}  placeholder='Enter previous price' required/>
//                         </div>
//                         <div>
//                             <p>Current Price</p>
//                             <input type='number' name='price' onChange={handleChange}  placeholder='Enter current price' required/>
//                         </div>
                        
//                         <div>
//                             <p>Cart Image</p>
//                             <input type='file' accept='image/*' onChange={app.handleSetCartPhoto} required/>
//                         </div>
                        
//                         <div>
//                             <p>Other Images</p>
//                             <input type='file' accept='image/*' multiple onChange={app.Second}/>
//                         </div> 
//                     </div>

//                     <div>
//                         <p>Quick Overview</p>
//                         <textarea type='text' name='overview'  onChange={handleChange}  placeholder='Describe product overview' id='overview' required/>
//                     </div>
//                     <div>
//                         <button type='submit'>SUBMIT</button>
//                     </div>
                
//                 </form> 
//                 :""}
//                 {update? 
//                 <form  onSubmit={app.handleUpdateSubmit}> 
//                 <div>
//                     <p>Product Title</p>
//                     <input type='text' name='title' onChange={handleUpdateChange} defaultValue={stringConverter(updateInfo.title)}  placeholder='Enter product title' required/>
//                 </div>
//                 <div className='mini__input'>
//                     {prevCategoryNames.length? 
//                     <div>
//                         <p>Select Category</p>
//                         <select onChange={handleUpdateChange} name='category'>    
//                             <option value='empty'>select category</option> 
//                             {
//                                 prevCategoryNames.map((info,index) =>  {
//                                     return <option key={index} value={info}>{info}</option> 
//                                 })
//                             }
//                         </select>
//                     </div> :""}
//                     <div>
//                         <p>Product ID</p>
//                         <input type='text' name='id' onChange={handleUpdateChange} defaultValue={updateInfo.product__id}  placeholder='Enter product title' required/>
//                     </div>
//                     <div>
//                         <p>Quantity</p>
//                         <input type='text' name='quantity' defaultValue={updateInfo.quantity} onChange={handleUpdateChange}  placeholder='Enter product Quantity' required/>
//                     </div>
//                     <div>
//                         <p>Previous Price</p>
//                         <input type='text' name='previous__price' onChange={handleUpdateChange} defaultValue={updateInfo.previous__price}  placeholder='Enter previous price' required/>
//                     </div>
//                     <div>
//                         <p>Current Price</p>
//                         <input type='text' name='price' onChange={handleUpdateChange} defaultValue={updateInfo.price}  placeholder='Enter current price' required/>
//                     </div>
                    
//                     <div>
//                         <p>Cart Image</p>
//                         <input type='file' accept='image/*' className='image__field' onChange={app.handleSetCartPhoto}/>
//                     </div>
                    
//                     <div>
//                         <p>Other Images</p>
//                         <input type='file' accept='image/*'  className='image__field' multiple onChange={app.Second}/>
//                     </div> 
//                 </div>

//                 <div>
//                     <p>Quick Overview</p>
//                     <textarea type='text' name='overview'  onChange={handleUpdateChange} defaultValue={stringConverter(updateInfo.overview)}  placeholder='Describe product overview' id='overview' required/>
//                 </div>
//                 <div>
//                     <button type='submit'>UPDATE</button>
//                     <button className='cancel__button' onClick={handleCancleUpdate}>CANCEL</button>
//                 </div>
            
//                 </form> :""}
//                 {update === false? 
//                 <div className='upload__image_view'>
//                         {file?<img src={file} alt='' className='top__image'   id='banner__image'/>:''} 
//                         <div className='child__images'>
//                             {otherOne.length? <img src={otherOne} alt='' className='child__image'/> :""}
//                             {otherTwo.length? <img src={otherTwo} alt='' className='child__image'/> :""}
//                             {otherThree.length? <img src={otherThree} alt='' className='child__image'/> :""}
//                             {otherFour.length? <img src={otherFour} alt='' className='child__image'/> :""}
//                         </div>  
//                 </div>
//                         :
//                     <div className='upload__image_view'> 
//                         {update?<img src={file} alt='' className='top__image'  id='banner__image'/>:''} 
//                         <div className='child__images'> 
//                         {update? <img src={otherOne} alt='' className='child__image'/> :""}
//                         {update? <img src={otherTwo} alt='' className='child__image'/> :""}
//                         {update? <img src={otherThree} alt='' className='child__image'/> :""}
//                         {update? <img src={otherFour} alt='' className='child__image'/> :""}
//                         </div>  
//                 </div>
//                 }
//             </div>
//             {prevProduct.length? 
//             <div className='prev__upload__view'>
//                     {
//                         prevProduct.map((info, index) => {
//                             return                    <div className='prev__product__item' id={info.ID} key={index}>
//                                                             <div className='image__container'> 
//                                                                 <img src={JSON.parse(info.images).images[0]} alt='product__image'/>
//                                                             </div>
//                                                             <div className='info__container'>
//                                                                 <p className='product__title'>{stringConverter(info.title)}</p>
//                                                                 <p className='product__id'><b>Product Id: </b>  {info.product__id}</p>
//                                                                 <p className='product__id'><b>Regular Price: </b> {info.previous__price}</p>
//                                                                 <p className='product__id'><b>Special Price: </b> {info.price}</p>
//                                                                 <p className='product__id'><b>Quantity: </b> {info.quantity}</p>
//                                                             </div>
//                                                             <div className='button__container'>
//                                                                 <button onClick={()=>handleDeleteData('product__info', info.ID)}>DELETE</button>
//                                                                 <button onClick={()=>handleUpdateHandler(info)}>UPDATE</button> 
//                                                             </div>
//                                                     </div>
//                         })
//                     }
//             </div> :""}
//         </div>
//   );
// };

// export default Upload;