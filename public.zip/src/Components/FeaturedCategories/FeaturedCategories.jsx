import { Link } from 'react-router-dom';
import TopRowHeaderTitleWithBorder from '../TopRowHeaderTitleWithBorder/TopRowHeaderTitleWithBorder';
const FeaturedCategories = () => {

   const categories =  [
        {
            "name": "Umart Gaming PCs",
            "link": "/childProducts?parentFather=Gaming&&parent=Gaming%20Desktop%20PC&&child=Danguli%20PC",
            "img__src": "/categories/gaming__pc.webp"
        },
        {
            "name": "Apple",
            "link": "/AllBrands/Apple",
            "img__src": "/categories/apple.webp"
        },
        {
            "name": "Laptops / Notebooks",
            "link": "/parentProducts?parentFather=Laptop&&parent=All%20Laptop",
            "img__src": "/categories/laptop__notebook.webp"
        },
        {
            "name": "Speakers",
            "link": "/parentProducts?parentFather=Sound%20System&&parent=Speaker",
            "img__src": "/categories/speaker.webp"
        },
        {
            "name": "Memory (RAM)",
            "link": "/childProducts?parentFather=Desktop%20PC%20and%20Server&&parent=Desktop%20Component&&child=Desktop%20Ram",
            "img__src": "/categories/memory__ram.webp"
        },
        {
            "name": "Power Supply / PSU",
            "link": "/childProducts?parentFather=Desktop%20PC%20and%20Server&&parent=Desktop%20Component&&child=Power%20Supply",
            "img__src": "/categories/power__supply.webp"
        },
        {
            "name": "Monitors",
            "link": "/parentProducts?parentFather=Monitor&&parent=All%20Monitor",
            "img__src": "/categories/monitor.webp"
        },
        {
            "name": "Headphones",
            "link": "/childProducts?parentFather=Sound%20System&&parent=Headphone&&child=Headphone",
            "img__src": "/categories/headphone.webp"
        },
        {
            "name": "SSD Hard Drives",
            "link": "/childProducts?parentFather=Storage&&parent=Internal%20SSD&&child=Internal%20SSD",
            "img__src": "/categories/ssd.webp"
        },
        {
            "name": "Graphics Cards / GPU",
            "link": "/childProducts?parentFather=Desktop%20PC%20and%20Server&&parent=Desktop%20Component&&child=Graphics%20Card",
            "img__src": "/categories/graphics__card.webp"
        },
        {
            "name": "CPU Processors",
            "link": "/childProducts?parentFather=Desktop%20PC%20and%20Server&&parent=Desktop%20Component&&child=Processor",
            "img__src": "/categories/processor.webp"
        }
    ]
    return (
        <div className='featured__category__container'>  
                    <TopRowHeaderTitleWithBorder infos={{ bgc: '#f0f2f5',  brc: 'none', brr: 10, title:  'Featured Categories' , display: 'block', strkbg:'#761bcc'}}/> 

            <div className='container'> 
                    {
                        categories.map((info, index) => {
                            return         <div className='category__item' key={index}>
                            <div className='image__container'>
                                <Link to={info.link}>
                                    <img src={info.img__src} alt={info.name}/>
                                </Link>
                            </div>
                            <Link to={info.link} className='link__parent'>
                                <p className='title'>{info.name}</p>
                            </Link>
                        </div>
                        })
                    } 
                    <div className='view__all'> 
                        <Link to='/allCategories' className='title'>+ VIEW ALL</Link>
                    </div>
                    
            </div>
        </div>
    );
};

export default FeaturedCategories;
