import React from 'react';

const CarouselItem = () => {
    return (
        <div className='my__carousel__container'>   
            <img src='/banner/one.jpg' atl=''></img>
        </div> 
    );
};

export default CarouselItem;