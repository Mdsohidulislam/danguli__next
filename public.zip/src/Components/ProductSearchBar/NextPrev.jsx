import { faAnglesLeft, faAnglesRight } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import React from 'react';

const NextPrev = ({infos}) => {
    let {currentPageAllProducts, setViewProducts,  showCount, setShowCount, viewCount} = infos;
    
    

    const handleNext = () => {
        setViewProducts(currentPageAllProducts.slice(showCount, showCount+viewCount));
        setShowCount(showCount+viewCount);
    }

    const handlePrevious = () => {
        setViewProducts(currentPageAllProducts.slice( showCount-viewCount*2   ,showCount-viewCount));
        setShowCount(showCount - viewCount);
    }

    return (
        <div className='next__prev__container'> 
        {viewCount === showCount ||  currentPageAllProducts.length === viewCount || currentPageAllProducts.length < viewCount ? <button disabled className='dis'>  <FontAwesomeIcon icon={faAnglesLeft}/>  </button> : <button onClick={handlePrevious}> <FontAwesomeIcon icon={faAnglesLeft}/> </button> }
        <p>{currentPageAllProducts.length > showCount ? showCount : currentPageAllProducts.length} of  {currentPageAllProducts.length}</p>
        {currentPageAllProducts.length > showCount ? <button onClick={handleNext}> <FontAwesomeIcon icon={faAnglesRight}/></button> : <button disabled className='dis'> <FontAwesomeIcon icon={faAnglesRight}/> </button>}
    </div>
    );
};

export default NextPrev;