import { faTrash } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import axios from 'axios';
import React, { useEffect, useState } from 'react';
import { serverHelper } from '../../UTILS/ServerUtils';
import { utilsHelper } from '../../UTILS/utils';
const Category = () => {

//  product uploader

    const [collectionName, setCollectionName] = useState({});
    const [catCollName, setCatCollName]  = useState('')
    const [categoryName, setCategoryName] = useState({});
    const [serverPort ]  = useState('http://localhost:3009/')  
    const [prevCollection, setPrevCollection] = useState([]);
    const [prevCategory, setPrevCategory] = useState([]);
    const [prevCollectionNames, setPrevCollectionNames] = useState([]);
    const [prevCategoryNames, setPrevCategoryNames] = useState([]);
    const [file, setFile] = useState('');
    const [categoryFile, setCategoryFile] = useState('');
    
    const getAllData =  (collectionName) => {
        axios.get('http://localhost:3009/getAllCollection',{headers:{collection: collectionName}})
        .then(res => { 

            let result = res.data.result;
            if(res.data.status__code === 200 && result.length){
                let prevCollectionNam =[]
                result.forEach(info => {
                    prevCollectionNam.push(info.name);
                })
                setPrevCollection(result); 
                setPrevCollectionNames(prevCollectionNam);
                
            }
        }).catch(err => {
            console.log(err.message);
        })
    }
    
    const getAllDataCategory =  (collectionName) => {
        axios.get('http://localhost:3009/getAllCollection',{headers:{collection: collectionName}})
        .then(res => { 

            let result = res.data.result;
            if(res.data.status__code === 200 && result.length){
                let prevCollectionNam =[]
                result.forEach(info => {
                    prevCollectionNam.push(info.name);
                })
                setPrevCategory(result); 
                setPrevCategoryNames(prevCollectionNam);
                
            }
        }).catch(err => {
            console.log(err.message);
        })
    }
    useEffect(()=>{
        getAllData('collections');  
        getAllDataCategory('categories');
    },[]);

 

    const handleSubmit = (e) => {
        e.preventDefault();  
        
        if(prevCollectionNames.indexOf(collectionName.collection__name) !== -1){
            alert(`${collectionName.collection__name} collection is already exist`)
        }else{ 
    

            let formData = new FormData();
            formData.append('name',collectionName.collection__name);
            formData.append('img__src', file); 
            formData.append('post__time', utilsHelper.timeManagements.momentTimeMaker());
            axios.post('http://localhost:3009/addCollection',  formData)
            .then(res => {  
                if(res.data.status__code === 200){
                    const inputs = document.querySelectorAll('input');
                    inputs.forEach(input => {
                        input.value=''
                    })   
                    getAllData('collections')
                } 
            }).catch(err => {
                console.log(err.message);
            }) 
        } 
    }
    
    const handleSubmitCategory = (e) => {
        
        e.preventDefault();  
        
        if(prevCategoryNames.indexOf(categoryName.name) !== -1){
            alert(`${categoryName.name} category is already exist`)
        }else{ 
            
            if(catCollName !== 'empty'){

                let formData = new FormData();
                formData.append('name', categoryName.name);
                formData.append('collection', catCollName);
                formData.append('post__time', utilsHelper.timeManagements.momentTimeMaker());

                formData.append('img__src', categoryFile); 
                axios.post('http://localhost:3009/addCategory',  formData)
                .then(res => {  
                    if(res.data.status__code === 200){
                        const inputs = document.querySelectorAll('input');
                        inputs.forEach(input => {
                            input.value=''
                        })    

                        getAllDataCategory('categories');

                    } 
                }).catch(err => {
                    console.log(err.message);
                }) 
            }else{
                alert('please select collection')
            }
        } 
    }

    const handleChange = (e) => {
        let newInfo = {...collectionName};
        newInfo[e.target.name] = e.target.value;
        setCollectionName(newInfo);
    }

    const handleChangeCategory = (e) => {
        let newInfo = {...categoryName};
        newInfo[e.target.name] = e.target.value;
        setCategoryName(newInfo);
    }
    

    return (
        <div className='category__main__container'> 
                <div className='category__banner'>

                </div> 
                <div className='category__information'>
                    <div className='upload__product__info__container'> 
                    <form onSubmit={handleSubmit}> 
                        <p className='head__title'>Add Product Collection</p>

                        <div>
                            <p>Collection Name</p>
                            <input type='text' name='collection__name' onChange={handleChange}  placeholder='Enter collection name' required/>
                        </div> 
                        <div>
                            <p>Collection Image</p>
                            <input type='file' accept='image/*' onChange={(e)=>setFile(e.target.files[0])} required/>
                            {/**<input type='file' accept='image/*' onChange={handleSetCartPhoto} required/>  */}
                        </div>                
                        <div>
                            <button type='submit'>SUBMIT</button>
                        </div> 

                    </form>  
                    </div>
                    <div className='upload__product__info__container'> 
                    <form onSubmit={handleSubmitCategory}> 
                        <p className='head__title'>Add Product Category</p>
                        <div>
                            <p>Category Name</p>
                            <input type='text' name='name' onChange={handleChangeCategory}  placeholder='Enter Category Name' required/>
                        </div> 
                        <div>
                            <p>Select Collection</p>
                            <select onChange={(e)=> setCatCollName(e.target.value)}>    
                                <option value='empty'>select collection</option> 
                                {
                                    prevCollectionNames.map((info,index) =>  {
                                        return <option key={index} value={info}>{info}</option> 
                                    })
                                }
                            </select>
                        </div> 
                        <div>
                            <p>Category Image</p>
                            <input type='file' accept='image/*' onChange={(e)=>setCategoryFile(e.target.files[0])} required/>
                        </div>                 
                        <div>
                            <button type='submit'>SUBMIT</button>
                        </div> 
                    </form>  
                    </div>
                    {prevCollection.length? 
                    <div className=' preview collection__preview'>
                            {
                                prevCollection.map((info, index) => {
                                    return <div className='item' key={index} id={info.ID}> 
                                                    <img src={`${serverPort}/${info.img__src}`} alt='collection iamge'/> 
                                                    <p>{info.name}</p>
                                                    <button onClick={()=>  utilsHelper.timeManagements.momentTimeMaker('collections', info.ID)}><FontAwesomeIcon icon={faTrash}/></button>
                                                </div>
                                })
                            }
                    </div> :""}
                    {prevCategory.length? 
                        <div className=' preview collection__preview'>
                                {
                                    prevCategory.map((info, index) => {
                                        return <div className='item' key={index} id={info.ID}> 
                                                        <img src={`${serverPort}/${info.img__src}`} alt='collection iamge'/> 
                                                        <p>{info.collection}/{info.name}</p>
                                                        <button onClick={()=> serverHelper.handleDeleteData('categories', info.ID)}><FontAwesomeIcon icon={faTrash}/></button>
                                                    </div>
                                    })
                                }
                        </div> :""}
 
                </div>
        </div>
    );
};

export default Category;