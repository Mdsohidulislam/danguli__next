import TopRowHeaderTitleWithBorder from '../TopRowHeaderTitleWithBorder/TopRowHeaderTitleWithBorder';

const MoreSave = () => {
    return (
        <div className='more__save__container'>
            <TopRowHeaderTitleWithBorder infos={{ bgc: '#f0f2f5',  brc: 'none', brr: 10, title: 'More way to save' , display: 'block', strkbg:'#761bcc'}}/>
            <div className='help__anywhere__container'>
                <div className='item__left any__item'>
                    <img src='/more__save/one.webp' alt='hello world'></img>
                </div>
                <div className='item__right any__item'>
                    <img src='/more__save/two.webp' alt='hello world'></img>
                </div> 
            </div>
        </div>
    );
};

export default MoreSave;