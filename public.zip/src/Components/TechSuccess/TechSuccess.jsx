import TopRowHeaderTitleWithBorder from '../TopRowHeaderTitleWithBorder/TopRowHeaderTitleWithBorder';

const TechSuccess = () => {
    return (
        <div className='tech__success__container'>
            <TopRowHeaderTitleWithBorder infos={{ bgc: '#f0f2f5',  brc: 'none', brr: 10, title: 'Tech for Success' , display: 'block', strkbg:'#761bcc'}}/>
            <div className='help__anywhere__container'>
                <div className='item__left any__item'>
                    <img src='/tech__success/one.webp' alt='hello world'></img>
                </div>
                <div className='item__right any__item'>
                    <img src='/tech__success/two.jpg' alt='hello world'></img>
                </div>
                <div className='item__right any__item'>
                    <img src='/tech__success/three.jpg' alt='hello world'></img>
                </div>
            </div>
        </div>
    );
};

export default TechSuccess;