import React from 'react';
import TopBannerItem from './TopBannerItem';


const TopBannerNavbar = () => {

    let count = 1;

    return (
        <div className='my__banner__shop__container'  >
                <ul>
                    <TopBannerItem/> 
                    <TopBannerItem/> 
                    <TopBannerItem/> 
                    <TopBannerItem/> 
                    <TopBannerItem/> 
                    <TopBannerItem/> 
                    <TopBannerItem/> 
                    <TopBannerItem/> 
                </ul>
        </div>
    );
};

export default TopBannerNavbar;