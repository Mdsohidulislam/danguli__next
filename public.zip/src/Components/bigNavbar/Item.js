import { faCaretDown, faRightLong } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import React from 'react';
import { Link } from 'react-router-dom';
import { uid } from 'uid';
const Item = ({infos, count}) => { 
    // console.log(brandQuantity, filterProduct);  
    
    return (
        <li key={count+uid()}>
        
            <div className='button__link__container'>
                <button className='button'>{infos.parentFather}</button>
                <button className='icon__button'><FontAwesomeIcon className='icon' icon={faCaretDown}/> </button>
            </div>
            <div className='info__container'>   
                <div className='link__container'>  
                    {
                        infos.links.map((infoParent, indexParent) => {
                            

                            
                            return <React.Fragment key={uid()+indexParent}>
                                        <Link to={`/parentProducts?parentFather=${infos.parentFather}&&parent=${infoParent.parent}`}   className='nav__link'>{infoParent.parent}  <FontAwesomeIcon icon={faRightLong}/></Link>
                                        {
                                            infoParent.links.map((info, indexChild) => {
                                                return <Link to={`/childProducts?parentFather=${infos.parentFather}&&parent=${infoParent.parent}&&child=${info.child}`} className='nav__link__bold' key={indexChild + indexParent + uid()}>{info.child}</Link>
                                            })
                                        }
                                        </React.Fragment> 
                        })
                    } 
                </div>
            </div>
    </li>   
    );
};

export default Item;

/// old search engine
/// old search engine
/// old search engine
/// old search engine
/// old search engine

// const handleClick = (brand,  category, type, other) => {
        
//     let fileteredArray = [];
//     let collections = [];
//     let filteredBrandProductQuantity = [];

//     if(other === 2){
//         let [oneQuery, twoQuery] = category.split(' ');
        
//         products.forEach((info)=>{
//             if(info.title.toLowerCase().search(oneQuery.toLowerCase()) !== -1 && info.title.toLowerCase().search(twoQuery.toLowerCase()) !== -1){
//                 fileteredArray.push(info);

//                 if(collections.indexOf(info.collection) !== -1){
//                     let index = collections.indexOf(info.collection); 
//                     let {count} = filteredBrandProductQuantity[index];
//                     filteredBrandProductQuantity[index] = {brand: info.collection, count: count+1};
//                 }else{
//                     collections.push(info.collection);
//                     filteredBrandProductQuantity.push({brand: info.collection, count: 1});
//                 }
//             }
//         })

//     }else if(category === brand && !other){ 

//         products.forEach((info) => {
//             if(info.category.toLowerCase() === brand){
//                 fileteredArray.push(info);

//                 if(collections.indexOf(info.collection) !== -1){
//                     let index = collections.indexOf(info.collection); 
//                     let {count} = filteredBrandProductQuantity[index];
//                     filteredBrandProductQuantity[index] = {brand: info.collection, count: count+1};
//                 }else{
//                     collections.push(info.collection);
//                     filteredBrandProductQuantity.push({brand: info.collection, count: 1});
//                 }
//             }
//         })

//         // let filterArray = products.filter(info => info.category.toLowerCase() === brand);
//         // setFilterProduct(filterArray);   
//     }else if(categories.indexOf(category) !== -1 && allBrands.indexOf(brand) !== -1){ 

//         products.forEach((info) => {
//             if(info.category.toLowerCase() === category && info.collection.toLowerCase() === brand){
//                 fileteredArray.push(info);

//                 if(collections.indexOf(info.collection) !== -1){
//                     let index = collections.indexOf(info.collection); 
//                     let {count} = filteredBrandProductQuantity[index];
//                     filteredBrandProductQuantity[index] = {brand: info.collection, count: count+1};
//                 }else{
//                     collections.push(info.collection);
//                     filteredBrandProductQuantity.push({brand: info.collection, count: 1});
//                 }
//             }
//         })
//             // let filteredArray = products.filter((info) => info.category.toLowerCase() === category && info.collection.toLowerCase() === brand);
//             // setFilterProduct(filteredArray);
//     }else if(categories.indexOf(brand) !==-1){

//         products.forEach((info) => {
//             if(info.category.toLowerCase() === brand){
//                 fileteredArray.push(info);

//                 if(collections.indexOf(info.collection) !== -1){
//                     let index = collections.indexOf(info.collection); 
//                     let {count} = filteredBrandProductQuantity[index];
//                     filteredBrandProductQuantity[index] = {brand: info.collection, count: count+1};
//                 }else{
//                     collections.push(info.collection);
//                     filteredBrandProductQuantity.push({brand: info.collection, count: 1});
//                 }
//             }
//         })
//         // let filteredArray = products.filter((info) => info.category.toLowerCase() === brand);
//         // setFilterProduct(filteredArray);
//     }else{  

//         products.forEach((info)=>{
//             if(info.title.toLowerCase().search(brand.toLowerCase()) !== -1){
//                 fileteredArray.push(info);

//                 if(collections.indexOf(info.collection) !== -1){
//                     let index = collections.indexOf(info.collection); 
//                     let {count} = filteredBrandProductQuantity[index];
//                     filteredBrandProductQuantity[index] = {brand: info.collection, count: count+1};
//                 }else{
//                     collections.push(info.collection);
//                     filteredBrandProductQuantity.push({brand: info.collection, count: 1});
//                 }
//             }
//         })
//         // let fileteredArray = products.filter((info) => info.title.toLowerCase().search(brand.toLowerCase()) !== -1);
//         // setFilterProduct(fileteredArray);
//     }
//     // history.push('/')
//     // history.push(`/category/${parent.toLowerCase()}/${type.toLowerCase()}/${category.toLowerCase()}/${other}`);
//     // '/category/:category/:type/:brand/:other' 

//     if(type === 'head' && !other ){
//         setFilterProduct(fileteredArray);
//         setBrandQuantity(filteredBrandProductQuantity);
//         history.push(`/category/${category}/${type}/${brand}/${other}`)
//     }else if(type === 'link'){
//         setFilterProduct(fileteredArray);
//         setBrandQuantity(filteredBrandProductQuantity);
//         history.push(`/category/${category}/${type}/${brand}/${other}`);
//     }else if(other === 2){
//         setFilterProduct(fileteredArray);
//         setBrandQuantity(filteredBrandProductQuantity);
//         history.push(`/category/${category}/${type}/${brand}/${other}`);
//     }
// } 