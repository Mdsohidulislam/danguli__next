import { faHome } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import React, { useContext } from 'react';
import { useHistory } from 'react-router-dom';
import { uid } from 'uid';
import { danguliContext } from '../../DanguliContext';
import Item from './Item';





const BigNavbar = () => {

    

    const {links} = useContext(danguliContext);
    
    const history = useHistory();
    const handleGoHome = () => {
        history.push('/')
    }
    return (
        <div className='my__big__shop__container' id='my__big__navbar__container'> 
            <div className='container'>  
                <FontAwesomeIcon icon={faHome} onClick={handleGoHome} className='home__icon'/>
                
                <ul>  
                {
                    links.map((info, index) => {
                        return <Item infos={info} count={index} key={uid()+index}/> 
                    })
                } 
                </ul>
            </div> 
        </div>
    );
};

export default BigNavbar;