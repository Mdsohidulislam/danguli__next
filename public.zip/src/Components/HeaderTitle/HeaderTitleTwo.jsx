import React from 'react';

const HeaderTitleTwo = () => {
    return (
        <div className='title__header__for__category__parent__two'>
            <p>Inspired by Your Browsing History</p>
            <div  className='bottom__arrow'>
                <div className='arrow arrow__one'></div>
                <div className='arrow arrow__two'></div>
                <div className='arrow arrow__three'></div>
            </div>
        </div>
    );
};

export default HeaderTitleTwo;