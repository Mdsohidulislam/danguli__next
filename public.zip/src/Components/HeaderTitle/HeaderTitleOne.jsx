import React from 'react';

const HeaderTitleOne = () => {
    return (
        <div className='title__header__for__category__parent__one'>
            <p className=''>
                Recently Views
            </p>
        </div>
    );
};

export default HeaderTitleOne;