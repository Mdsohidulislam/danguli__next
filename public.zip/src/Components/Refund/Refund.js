import React from 'react';
import FooterBanner from '../FooterBanner/FooterBanner';
import HelpFooter from '../FooterBanner/HelpFooter';
import CartBox from '../SideBar/CartBox';
import TopNavbar from '../TopNavbar/TopNavbar';
import TopSmallNavbar from '../TopNavbar/TopSmallNavbar';

const Refund = () => {
    return (
        <div>
        <CartBox/>
        <TopSmallNavbar/>
        <TopNavbar/>
                <div className='privacy__policy'>
                <h1>Refund policy</h1>
                <p>Since the Website offers non-tangible, irrevocable goods we do not provide refunds after the product is purchased, which you acknowledge prior to purchasing any product on the Website. Please make sure that you’ve carefully read product description before making a purchase.</p>
                <h2>Contacting us</h2>
                <p>If you have any questions, concerns, or complaints regarding this refund policy, we encourage you to contact us using the details below:</p>
                <p><a target="_blank" rel="nofollow noreferrer" href="https://danguli.com.bd/contact">https://danguli.com.bd/contact</a><br/>a&#100;m&#105;n&#64;&#100;an&#103;u&#108;&#105;.&#99;&#111;&#109;.b&#100;<br/>Rohanpur Station Bazar, Chapainawabganj, Rajshahi, Bangladesh</p>
                <p>This document was last updated on March 12, 2022</p>
                </div>
                <FooterBanner/>
                <HelpFooter/>
        </div>
    );
};

export default Refund;