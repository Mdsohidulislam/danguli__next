import React, { useEffect } from 'react';
import BigNavbar from '../bigNavbar/bigNavbar';
import SearchBarContainer from '../SearchBarContainer/SearchBarContainer';

const TopNavbar = () => {

    useEffect(()=>{
        let myTopNav = document.getElementById('my__top__navbar');
        let windowScrollY = 0;
    window.addEventListener('scroll',()=>{

        let totalFound = document.getElementById('total__found');

        let str = ''
        if(totalFound){
                str = totalFound.innerHTML;
                str = str.length;
        }

        if(window.scrollY >= myTopNav.offsetHeight && !str){
                myTopNav.classList.add('open'); 
        }else{
            myTopNav.classList.remove('open') 
        } 
    })
    },[]) 

    return (
        <div className='top__navbar__container' id='my__top__navbar'> 
            <SearchBarContainer/>
            <BigNavbar/> 
        </div>
    );
};

export default TopNavbar;