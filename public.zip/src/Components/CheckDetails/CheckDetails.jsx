import axios from 'axios';
import React, { useContext, useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { danguliContext } from '../../DanguliContext';
import { Developer } from '../ProductDetails/ProductDetails';


const CheckDetails = () => {

    const {products,  wishlist, setWishlist,cart, setCart,compareList, setCompareList,wishlistId, setWishlistId,cartId, setCartId,compareListId, setCompareListId, currentProduct, setCurrentProduct} = useContext(danguliContext);
    const [getProduct, setGetProduct] = useState({});
    const [showDetails, setShowDetails] = useState(false);
    const [smallInfo, setSmallInfo] = useState({});
    
    const {url } = useParams();
    
    useEffect(()=>{  
        let product = products.filter((info) => info.product__id === url);
        if(product[0].product__id){ 
            axios.get(product[0].details__url)
            .then(res => { 
                if(res.data){  
                    let productData = res.data; 
                    let startCutStr = 'Overview</p>'
                    let startCutStrLen = 'Overview</p>'.length;
                    let endCutStr = '<div class="row-detail-action">'  
            
                    let overviewData = productData.slice(productData.indexOf(startCutStr)+startCutStrLen, productData.indexOf(endCutStr));  
                    
                    
                    let showOf = document.getElementById('server__result');
                    showOf.innerHTML = res.data;
                    showOf.style.display = 'none';
                    
                    let images = document.querySelectorAll('#productGallery > .elevatezoom-gallery');
                    let zoomImages = [];
                    images.forEach(info =>  {
                        zoomImages.push(info.dataset.zoomImage);
                    })


                    let headerMother  = document.querySelectorAll('.specs-wrapper > .row > .col-sm-12');
                    let totalSpecifications = []
                    headerMother.forEach(info =>  {
                        let newInfo = {}
                        let infos = [];
                    
                        let title = info.querySelector('.group');
                        if(title){
                            newInfo.title = title.innerText
                        let tableRows = info.querySelectorAll('.specs-item-wrapper > .row');
                            tableRows.forEach(info => {
                                let data = {};
                                let headText = info.querySelector('.attribute_set').innerHTML;
                                let text = info.querySelector('.col-md-10').innerHTML;
                                data.title = headText;
                                data.info = text; 
                                infos.push(data);
                            })  
                        }else{
                    
                            newInfo.title = 'General'; 
                        
                            let tableRows = info.querySelectorAll('.specs-item-wrapper > .row');
                                tableRows.forEach(info => {
                                    let data = {};
                                    let headText = info.querySelector('.attribute_set').innerHTML;
                                    let text = info.querySelector('.col-md-10').innerHTML;
                                    data.title = headText;
                                    data.info = text; 
                                    infos.push(data);
                                })
                                
                        }
                            
                            newInfo.infos = infos;
                        totalSpecifications.push(newInfo);
                    
                    })

                    let data = document.getElementById('description');
                    let newData = data.innerHTML 
                    
                    let productDetails = {
                        images: zoomImages,
                        specification: totalSpecifications,
                        overview: overviewData,
                        details: newData,
                        reviews: [],
                        QA: [],
                    } 
                    handlePostData(productDetails,  product[0]) 
                }
            }).catch(err => {
                console.log(err.message);
            })
        }
    },[])
    
    const handlePostData = (data, smallInfo) =>{
        setGetProduct(data);
        setSmallInfo(smallInfo);  
        setShowDetails(true); 
        document.getElementById('server__result').innerHTML=''
    }

    return (
        <div>  
            {showDetails? <Developer small={smallInfo} detail={getProduct}/> :''}

            <div id='server__result'></div>
        </div>
    );
};

export default CheckDetails;








// let headerMother  = document.querySelectorAll('.specs-wrapper > .row > .col-sm-12');
// let totalSpecifications = []
// headerMother.forEach(info =>  {
//     let newInfo = {}
//     let infos = [];

//     let title = info.querySelector('.group');
//     if(title){
//         newInfo.title = title.innerText
//     let tableRows = info.querySelectorAll('.specs-item-wrapper > .row');
//         tableRows.forEach(info => {
//             let data = {};
//             let headText = info.querySelector('.attribute_set').innerHTML;
//             let text = info.querySelector('.col-md-10').innerHTML;
//             data.title = headText;
//             data.info = text; 
//             infos.push(data);
//         })  
//     }else{

//         newInfo.title = 'General'; 
    
//         let tableRows = info.querySelectorAll('.specs-item-wrapper > .row');
//             tableRows.forEach(info => {
//                 let data = {};
//                 let headText = info.querySelector('.attribute_set').innerHTML;
//                 let text = info.querySelector('.col-md-10').innerHTML;
//                 data.title = headText;
//                 data.info = text; 
//                 infos.push(data);
//             })
            
//     }
        
//         newInfo.infos = infos;
//     totalSpecifications.push(newInfo);

// })








