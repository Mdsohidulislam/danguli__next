// import React from 'react';

// const Scss = () => {                  
//     return (
//         <div className=''>  
//             <div className='row jcc bg w-70 pr-50'>
//                 <div className='col-5 bg width-20'>
                
//                 </div> 
//                 <div className='col-5 bg width-20'>Hello world</div> 
//                 <div className='col-5'>Hello world</div> 
//                 <div className='col-5'>Hello world</div> 
//                 <div className='col-5'>Hello world</div> 
//             </div>
//             <p>What learn today scss</p>
//             <p>@else @if @else if</p>
//             <p>@for @while</p>
//             <p>@each</p>
//             <p>Variable</p>
//             <p>Nesting</p>
//             <p>import and partials</p>
//             <p>@mixin and include</p>
//             <p>@extend</p>
//         </div>
//     );
// };

// export default Scss;