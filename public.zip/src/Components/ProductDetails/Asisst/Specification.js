import React from 'react';
import { utilsHelper } from '../../../UTILS/utils';

const Specification = ({info}) => {
    
    let {title, infos} = info; 
    return (
        <div className='details__item'>
        <p className='details__header'>{utilsHelper.stringOperations.specificationsStringConverter(title)}</p>
        <table>
            <tbody> 
                {
                    infos.map((info, index) => {
                        return                  <tr key={index}>
                        <td className='title'>{utilsHelper.stringOperations.specificationsStringConverter(info.title)}</td>
                        <td className='info'>{utilsHelper.stringOperations.specificationsStringConverter(info.info)}</td>
                    </tr>
                    })
                } 
            </tbody>
        </table>
</div> 
    );
};

export default Specification;