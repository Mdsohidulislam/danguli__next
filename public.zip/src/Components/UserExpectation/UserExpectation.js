import React, { useContext, useEffect, useState } from 'react';
import { useParams } from 'react-router-dom/cjs/react-router-dom.min';
import { danguliContext } from '../../DanguliContext';
import SearchEngine from '../../UTILS/SearchEngineUtils';
import { utilsHelper } from '../../UTILS/utils';
import CartOne from '../Carts/CartOne/CartOne';
import FilterNavbar from '../FilterNavbar/FilterNavbar';
import TopNavbar from '../TopNavbar/TopNavbar';
import TopSmallNavbar from '../TopNavbar/TopSmallNavbar';

    

const UserExpectation = () => {
    const {products,  filterProduct, setFilterProduct, brandQuantity, setBrandQuantity, specifications} =  useContext(danguliContext); 
    const [showCount, setShowCount] = useState(0);
    const [countLimit, ]   = useState(32); 
    const [currentBrand] = useState('');
    const [currentPath, setCurrentPath] = useState('');
    const [filterNavbar, setFilterNavbar] = useState([]);
    let params = useParams();
    
    let {link__name, parent, other ,subCategory} = params;
    other = Number(other);
    link__name =utilsHelper.stringOperations.slashStringConverter(link__name);
    if(link__name[0] === ' '){
        link__name = link__name.slice(1,link__name.length);
    } 
    
    

    function getAllCategoriesData () {
        let result = {}
        if(other === 2){
            result =  SearchEngine.ParentProductsFinder(link__name, parent, products, subCategory);
        } else if(other === 3){
            result =  SearchEngine.ParentProductsFinder(link__name, parent, products, subCategory);
        } else if(other === 4){
            result =  SearchEngine.ChildProductsFinder(link__name, parent,  products, subCategory);
        } else if(other === 1){
            result = SearchEngine.allItemsFinder(parent, products)
        }
        let {sortedArray, filteredBrandProductQuantity, productId} = result;
        setFilterProduct(sortedArray);
        setBrandQuantity(filteredBrandProductQuantity);
        let specification = SearchEngine.specificationsFilter(specifications, productId);
            specification = SearchEngine.handleFilterByProductIdAndItem(specification);
        setFilterNavbar(specification);
        
    }  

    
    useEffect(()=>{  
        if(specifications.length){
            getAllCategoriesData();
        }
        setCurrentPath(window.location.pathname);
    },[])

    

    const handleFilterByCollection = (brands) => {
        let result = SearchEngine.handleCollectionFilter(brands, filterProduct);
        let {sortedArray, filteredBrandProductQuantity, productId} = result;
        setFilterProduct(sortedArray);
        setBrandQuantity(filteredBrandProductQuantity)
    }
     
    const handlePrevious = () => {
        if(showCount > 32 || showCount === 32){
            setShowCount(showCount-32);
        }
    }

    const handleNext = () => {
        if(filterProduct.length > showCount+32){
            setShowCount(showCount+32)
        }
    }  

    const handleUrlValidator = () => {
        if(window.location.pathname !== currentPath){
            setCurrentPath(window.location.pathname)
            setTimeout(()=>{
                getAllCategoriesData();
            },100)
        }
    }

    handleUrlValidator();
    
    return (
        <div>   
        <TopNavbar/>
        <TopSmallNavbar/> 
        {filterNavbar.length? <FilterNavbar filterNavbarData={filterNavbar}/>: ""}
            {
                brandQuantity.length? 
            <div className='result__brand__quantity'>
                {
                    brandQuantity.map((info, index) => <button className={`${currentBrand == info.brand? 'active__brand__button' : ''}`} onClick={()=>handleFilterByCollection(info.brand)} key={index}>{info.brand} <span >{info.count}</span></button>)
                }
                </div>  : ""
            }
            <div className='home__page__container'>  
            {filterProduct.length?  
                <div className='container'>
                    {
                        filterProduct.slice(showCount, showCount+countLimit).map((info, index)=>{
                            return <CartOne key={index} infos={info}/>
                        })
                    }
                </div>
                :""}
            </div>
            <button onClick={handlePrevious} >Previous</button>
            <button onClick={handleNext}>Next</button> 
        </div>
    );
};

export default UserExpectation;





/// old  user search handler start
// const handleFilterByCollection = (brands) => {
//     setCurrentBrand(brands);
//     let filteredArray = []; 
//     if(type === 'link' && other === 'true'){
//         products.forEach((info) => {
//             if(info.title.toLowerCase().search(brand.toLowerCase()) !== -1 && info.collection.toLowerCase() === brands.toLowerCase()){
//                 filteredArray.push(info);
//             }
//         })
//     }else if(other === '2'){
//         let [oneQuery, twoQuery] = category.split(' ');
        
//         products.forEach((info) => {
//             if(info.title.toLowerCase().search(oneQuery.toLowerCase()) !== -1 && info.title.toLowerCase().search(twoQuery.toLowerCase()) !== -1 && info.collection.toLowerCase() === brands.toLowerCase()){
//                 filteredArray.push(info);
//             }
//         })  
//     } else{

//         products.forEach((info) => {
//             // && info.category.toLowerCase() === category
//             if(info.collection.toLowerCase() === brands.toLowerCase() && info.category.toLowerCase() === category){ 

//                 filteredArray.push(info); 

//             }
//         })
//     }   
//     setFilterProduct(filteredArray);
// }