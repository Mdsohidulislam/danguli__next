import React from 'react';
import Item from './Item';

const OnNavbar = () => {
    let count = 0;
    return (
        <div className='on__navbar__container'>
            <ul className='container'>
                <Item/>
                <Item/>
                <Item/>
                <Item/>
                <Item/>
                <Item/>
                <Item/>
                <Item/>
                <Item/>
                <Item/>
                <Item/>
                <Item/>
                <Item/>
                <Item/>
                <Item/>
                <Item/>
                <Item/>
                <Item/>
            </ul>
        </div>
    );
};

export default OnNavbar;