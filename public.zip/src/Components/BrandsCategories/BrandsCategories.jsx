import { Link } from 'react-router-dom';
import TopRowHeaderTitleWithBorder from '../TopRowHeaderTitleWithBorder/TopRowHeaderTitleWithBorder';

const BrandsCategories = () => {

 
    const categories =   [
        {
            "name": "Apple",
            "img__src": "/brand/apple.webp",
            "url": "/allBrands/Apple"
        },
        {
            "name": "Intel",
            "img__src": "/brand/intel.webp",
            "url": "/allBrands/Intel"
        },
        {
            "name": "AMD",
            "img__src": "/brand/amd.webp",
            "url": "/allBrands/AMD"
        },
        {
            "name": "Corsair",
            "img__src": "/brand/corsair.webp",
            "url": "/allBrands/Corsair"
        },
        {
            "name": "Gigabyte",
            "img__src": "/brand/gigabyte.webp",
            "url": "/allBrands/Gigabyte"
        },
        {
            "name": "HP",
            "img__src": "/brand/hp.webp",
            "url": "/allBrands/HP"
        },
        {
            "name": "MSI",
            "img__src": "/brand/msi.webp",
            "url": "/allBrands/MSI"
        },
        {
            "name": "Samsung",
            "img__src": "/brand/samsung.webp",
            "url": "/allBrands/Samsung"
        },
        {
            "name": "Microsoft",
            "img__src": "/brand/microsoft.webp",
            "url": "/allBrands/Microsoft"
        },
        {
            "name": "Thermaltake",
            "img__src": "/brand/thermaltake.webp",
            "url": "/allBrands/Thermaltake"
        },
        {
            "name": "LG",
            "img__src": "/brand/lg.webp",
            "url": "/allBrands/LG"
        }
    ]
    
    // LG Thermaltake Microsoft Samsung MSI HP Gigabyte Corsair AMD Intel Apple
    return (
        <div className='brand__category__container'> 
                    <TopRowHeaderTitleWithBorder infos={{ bgc: '#f0f2f5',  brc: 'none', brr: 10, title:  'Save big on top brands' , display: 'block', strkbg:'#761bcc'}}/> 
            <div className='container'> 
                    {
                        categories.map((info, index) => {
                            return         <div className='category__item' key={index}>
                            <div className='image__container'> 
                                <Link to={info.url}>
                                <img src={info.img__src} alt={info.name} title={info.name}/> </Link>
                            </div> 
                        </div>
                        })
                    } 
                    <div className='view__all'> 
                        <Link to='/allBrands' className='title'>+ VIEW ALL</Link>
                    </div>
                    
            </div>
        </div>
    );
};

export default BrandsCategories;