import { useContext } from 'react';
import { danguliContext } from '../../DanguliContext';
import CartEightNext from '../Carts/CartEight/CartEightNext';

const WishList = () => {
    const {totalHearts} = useContext(danguliContext);

    return (
        <div>   
            <div className='my__wishlist__container'>
                <div className='wishlist__intro'>
                    <h1>YOUR WISHLIST</h1>
                    {totalHearts.cart.length > 1 ? <p>{totalHearts.cart.length} PRODUCTS</p> : <p>{totalHearts.cart.length} PRODUCT</p>}
                </div>
                {totalHearts.cart.length? 
                    <div className='wishlist__container'>
                        {
                            totalHearts.cart.map((info, index) =>   <CartEightNext infos={info} count={index}  key={index}/>)
                        }
                        
                    </div> : ""}
            </div> 
        </div>
    );
};

export default WishList;

