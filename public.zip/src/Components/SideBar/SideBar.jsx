import React from 'react';

const SideBar = () => {
    
 
    

    // app object module scafolding
    const pageHandler = {};

    pageHandler.handleOpenCart =  () => {
 
        const main = document.getElementById('home__banner__container');
        main.classList.toggle('active__cart');
 
    } 
    pageHandler.handleOpenNavbar = () => {

        const main = document.getElementById('home__banner__container');
        main.classList.toggle('active__navbar'); 

    } 

    pageHandler.addToCart = () => {
        const body = document.getElementById('pop__up__elements');
        const elements = document.getElementById('pop__up__body');
        body.classList.toggle('active')
        elements.classList.toggle('active')
    }

    return (
        <div className="main__container">
            <div className="pop__up__container">
                <div className="pop__up__main__all__body" id='pop__up__body' onClick={pageHandler.addToCart}>
                </div>
                <div className="pop__up" id='pop__up__elements'>
                        <div className="message__body">
                            <button className="cross" onClick={pageHandler.addToCart}>❌</button>
                            <h3>🔒 save to wishlist</h3>
                            <p> <span className="padding">Login or create an account to save this item to your</span>
                            <span className="padding">wishlist. We'll drop you back here after you have entered</span>
                            <span className="padding">your details</span></p>
                            <button>login</button>
                            <button>create account</button>
                        </div>
                </div>
            </div>
            <div className='sidebar__container' id='home__banner__container'> 
                <div className="navbar__container">
                        <button onClick={pageHandler.handleOpenNavbar}>Navbar</button>
                        <button onClick={pageHandler.addToCart}>add to cart</button>
                        <button onClick={pageHandler.handleOpenCart}>Cart</button>
                </div>
                <div className="side__navbar__desing">
                    <div className="container">
                        <p className='link__name'>Home</p>
                        <p className='link__name'>Home</p>
                        <p className='link__name'>Home</p>
                        <p className='link__name'>Home</p>
                        <p className='link__name'>Home</p>
                        <p className='link__name'>Home</p>
                        <p className='link__name'>Home</p>
                        <p className='link__name'>Home</p>
                        <p className='link__name'>Home</p> 
                    </div>
                </div>
                <div className='side__product__cart__design'>
                </div> 
            </div>
        </div>
    );
};

export default SideBar;