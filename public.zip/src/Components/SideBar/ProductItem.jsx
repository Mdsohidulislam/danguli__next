import { faHeart, faTrash } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import axios from 'axios';
import { useContext, useState } from 'react';
import { Link } from 'react-router-dom';
import { danguliContext } from '../../DanguliContext';
import { utilsHelper } from '../../UTILS/utils';
    
const ProductItem = ({infos}) => {

    const [count, setCount] = useState(infos.infos.quantity);
    const {cart,  cartId, setCart, setCartId, setCartTotalInfo, totalCarts, serverPort, setTotalCarts } = useContext(danguliContext)
    
    const handleIncreaseCount = () => {
        if(infos.infos.quantity < 10){  
            
             let currentProduct = {...infos};
                        currentProduct.infos.quantity = currentProduct.infos.quantity + 1;
                        let wholePrice = currentProduct.infos.current__price / 10; 
                        currentProduct.infos.whole__price = infos.infos.current__price - wholePrice; 
                        axios.put('http://localhost:3009/putSingleBrowsingProduct',{infos: currentProduct, database: 'add__to__cart'}).then(res => {
                            if(res.data.status__code === 200){
                                handleGetCartInfos();
                            }
                        }).catch(err => {
                            console.log(err.message);
                        })
        }
    }

    const handleDecreaseCount = ( ) => {
        if(infos.infos.quantity > 1){
            let currentProduct = {...infos};
                        currentProduct.infos.quantity = currentProduct.infos.quantity - 1;
                        let wholePrice = currentProduct.infos.current__price / 10; 
                        currentProduct.infos.whole__price = infos.infos.current__price - wholePrice; 
                        axios.put('http://localhost:3009/putSingleBrowsingProduct',{infos: currentProduct, database: 'add__to__cart'}).then(res => {
                            if(res.data.status__code === 200){
                                handleGetCartInfos();
                            }
                        }).catch(err => {
                            console.log(err.message);
                        })
        }
    }

    const handleRemoveFromCart = ( ) => {
        let user__key = localStorage.getItem('user__key'); 
       
        axios.delete('http://localhost:3009/deleteSingleBrowsingProduct', {headers: {user__key, product__id: infos.product__id, database: 'add__to__cart'}}).then(res => {
            
            let total__products = productDelete(totalCarts.cart, infos.product__id);
            let twp = 0;
            let tcp = 0;
            let tip = 0;
            let ides =  [];
            let tq = 0;
            total__products.forEach((info, index) => { 
                ides.push(info.product__id) 
    
                let intwp = info.infos.whole__price * info.infos.quantity;
                let intcp = info.infos.current__price * info.infos.quantity;
                let intip =  ( info.infos.current__price / 10) * info.infos.quantity; 
                    twp += intwp;
                    tcp += intcp;
                    tip += intip; 
                    tq += info.infos.quantity;
            })   
            
            setTotalCarts({cart: total__products, quantity: tq, ides, total__whole__price: twp, total__current__price: tcp, total__interest__price: tip});
        }).catch(err => {
            console.log(err.message);
        }) 
    }
    const handleGetCartInfos = () => { 
        let user__key = localStorage.getItem('user__key');
        axios.get('http://localhost:3009/getSingleBrowsingProduct',{headers:{user__key , database: 'add__to__cart'}}).then(res => {  
            if(res.data.status__code === 200){
                let {products} = res.data;       
                let total__products = [...products]
                let twp = 0;
                            let tcp = 0;
                            let tip = 0;
                            let ides =  [];
                            let tq = 0;
                            total__products.forEach((info, index) => { 
                                ides.push(info.product__id)
    
                                let intwp = info.infos.whole__price * info.infos.quantity;
                                let intcp = info.infos.current__price * info.infos.quantity;
                                let intip =  ( info.infos.current__price / 10) * info.infos.quantity; 
                                    twp += intwp;
                                    tcp += intcp;
                                    tip += intip; 
                                    tq += info.infos.quantity;
                            }) 
                            setTotalCarts({cart: total__products, quantity: tq, ides, total__whole__price: twp, total__current__price: tcp, total__interest__price: tip}); 
            }
        }).catch(err => {
            console.log(err);
        })
    }
    

    const productDelete = (productes, product__id) => {
        let final__products  =  productes.filter((info, index) => info.product__id !== product__id);
        return final__products;
    }

    let newImages = infos.infos.images.length ? infos.infos.images : [];
    let newImageCollection = [];
    for(let i = 0; i < newImages.length; i ++){
        if(newImages[i].indexOf('ryanscomputers') === -1){
            newImageCollection.push(serverPort+newImages[i])
        }
    }  
    return (
        <div className='product'>
        <div className='image__container'> 
                {/* <img src={"/CartImages/"+images[Math.ceil(Math.random()*11)]}alt='product'/>  */}
                {newImageCollection.length ? 
                    <Link to={`/${infos.visible__url}_-_${infos.parent__father}`}>
                        <img src={newImageCollection[0]} alt="" /> 
                    </Link> :  
                    <Link to={`/${infos.visible__url}_-_${infos.parent__father}`}>
                        <img src='/sorry__image.jpg' alt="" />
                    </Link> 
                }
        </div>
        <div className='info__container'>
            <p className='product__title' >{utilsHelper.stringOperations.cartStringCutter(infos.infos.title)}</p>  
            <p className='total__price'>PRICE :  { infos.infos.current__price}</p> 
            <p className='total__price'>SUB-TOTAL : {infos.infos.current__price} x {infos.infos.quantity} = {infos.infos.quantity * infos.infos.current__price}</p> 
            <div className='button__container'>
                <button className='action__button' onClick={handleDecreaseCount}>-</button> 
                <button className='action__button count'>{infos.infos.quantity}</button> 
                <button className='action__button' onClick={handleIncreaseCount}>+</button>
            </div>
            <div className='wish__and__trash__button__container'>
            <button className='product__remove__from__cart__button' onClick={handleRemoveFromCart}><FontAwesomeIcon icon={faTrash}/></button>
            <button className='add__in__wishlist'><FontAwesomeIcon icon={faHeart}/></button> </div>
        </div>
    </div> 
    );
};

export default ProductItem;