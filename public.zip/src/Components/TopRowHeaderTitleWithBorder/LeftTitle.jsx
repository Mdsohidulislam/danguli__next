
const LeftTitle = ({info}) => {
    return (
        <div className="left__title__container">
            <h1>{info.name}</h1>
        </div>
    );
};

export default LeftTitle;