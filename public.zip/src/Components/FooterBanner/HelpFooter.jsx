import React from 'react';
import { Link } from 'react-router-dom';

const HelpFooter = () => {
    return (
        <div className='help__footer__container'>
            <div className='image__container'>
                <img alt='customer' src='/help.jpg'/>
            </div>
            <div className='info__container'>
                <Link to='/services' className='p'>We're here to help! Click here to contact Customer Service</Link>
                <div className='link__and__logo'>
                    <div className='help__center info__logo'>
                        <img src='/help__log.webp' alt='help__center__logo'/>
                        <Link to='services' className='p'> Help centre</Link>
                    </div>
                    <div className='contact__us info__logo'>
                        <img src='/contact___log.png' alt='contact__us__logo'/>
                        <Link to='contactUs' className='p'> Contact Us</Link>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default HelpFooter;