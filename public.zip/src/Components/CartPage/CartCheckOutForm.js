import { useContext } from 'react';
import { Link, useHistory } from 'react-router-dom';
import { danguliContext } from '../../DanguliContext';
import active__utils from '../../UTILS/Active__utils';

const CartCheckOutForm = ({showRemoveButton}) => {
    const {totalCarts} = useContext(danguliContext);
    const handleVoucherCodeSubmit = (e) => {
        e.preventDefault();
    }
    // const {showRemoveButton} = params;
    const history = useHistory();
    const handleGoHome =  () => {
        active__utils.active__cart();
        history.push('/');
    }
    return (
        <div className='checkout__and__voucher__container'> 
            <div className='total__price'>
                <p>TOTAL ({totalCarts.quantity}) : </p>
                <p>৳: {totalCarts.total__current__price}</p>
            </div>
            <form onSubmit={handleVoucherCodeSubmit} className='voucher__form'>
                <input type='text' placeholder='Enter voucher code' name='voucher__code'/>
                <button type='submit'>Apply</button> 
            </form>
            <Link to='/checkout' className='checkout__button'>Checkout</Link>
            {showRemoveButton?
                
            <p onClick={handleGoHome} className='continue__shopping__button'>Continue Shopping</p>  
            
            : 
            
            <Link to='/' className='continue__shopping__button'>Continue Shopping</Link> }
        </div>
    );
};

export default CartCheckOutForm;