import { faHeart, faTrash } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import axios from 'axios';
import { useContext } from 'react';
import { Link, useHistory } from 'react-router-dom';
import { danguliContext } from '../../DanguliContext';
import { utilsHelper } from '../../UTILS/utils';

const CartPageItem = ({infos}) => {
    
    const {totalCarts, cart,  cartId, setCart, setTotalCarts ,setCartTotalInfo, serverPort} = useContext(danguliContext) 
    const handleIncreaseCount = (id) => {
        if(infos.infos.quantity < 10){  
            
             let currentProduct = {...infos};
                        currentProduct.infos.quantity = currentProduct.infos.quantity + 1;
                        let wholePrice = currentProduct.infos.current__price / 10; 
                        currentProduct.infos.whole__price = infos.infos.current__price - wholePrice; 
                        axios.put('http://localhost:3009/putSingleBrowsingProduct',{infos: currentProduct, database: 'add__to__cart'}).then(res => {
                            if(res.data.status__code === 200){
                                handleGetCartInfos();
                            }
                        }).catch(err => {
                            console.log(err.message);
                        })
        }
    }

    const handleDecreaseCount = (id) => {
        if(infos.infos.quantity > 1){
            let currentProduct = {...infos};
                        currentProduct.infos.quantity = currentProduct.infos.quantity - 1;
                        let wholePrice = currentProduct.infos.current__price / 10; 
                        currentProduct.infos.whole__price = infos.infos.current__price - wholePrice; 
                        axios.put('http://localhost:3009/putSingleBrowsingProduct',{infos: currentProduct, database: 'add__to__cart'}).then(res => {
                            if(res.data.status__code === 200){
                                handleGetCartInfos();
                            }
                        }).catch(err => {
                            console.log(err.message);
                        })
        }
    }

    const handleRemoveFromCart = (id) => {
        let user__key = localStorage.getItem('user__key'); 
       
        axios.delete('http://localhost:3009/deleteSingleBrowsingProduct', {headers: {user__key, product__id: infos.product__id, database: 'add__to__cart'}}).then(res => {
            
            let total__products = productDelete(totalCarts.cart, infos.product__id);
            let twp = 0;
            let tcp = 0;
            let tip = 0;
            let ides =  [];
            let tq = 0;
            total__products.forEach((info, index) => { 
                ides.push(info.product__id) 
    
                let intwp = info.infos.whole__price * info.infos.quantity;
                let intcp = info.infos.current__price * info.infos.quantity;
                let intip =  ( info.infos.current__price / 10) * info.infos.quantity; 
                    twp += intwp;
                    tcp += intcp;
                    tip += intip; 
                    tq += info.infos.quantity;
            })   
            
            setTotalCarts({cart: total__products, quantity: tq, ides, total__whole__price: twp, total__current__price: tcp, total__interest__price: tip});
        }).catch(err => {
            console.log(err.message);
        }) 
    }
    const handleGetCartInfos = () => { 
        let user__key = localStorage.getItem('user__key');
        axios.get('http://localhost:3009/getSingleBrowsingProduct',{headers:{user__key , database: 'add__to__cart'}}).then(res => {  
            if(res.data.status__code === 200){
                let {products} = res.data;       
                let total__products = [...products]
                let twp = 0;
                            let tcp = 0;
                            let tip = 0;
                            let ides =  [];
                            let tq = 0;
                            total__products.forEach((info, index) => { 
                                ides.push(info.product__id)
    
                                let intwp = info.infos.whole__price * info.infos.quantity;
                                let intcp = info.infos.current__price * info.infos.quantity;
                                let intip =  ( info.infos.current__price / 10) * info.infos.quantity; 
                                    twp += intwp;
                                    tcp += intcp;
                                    tip += intip; 
                                    tq += info.infos.quantity;
                            }) 
                            setTotalCarts({cart: total__products, quantity: tq, ides, total__whole__price: twp, total__current__price: tcp, total__interest__price: tip}); 
            }
        }).catch(err => {
            console.log(err);
        })
    }
    

    const productDelete = (productes, product__id) => {
        let final__products  =  productes.filter((info, index) => info.product__id !== product__id);
        return final__products;
    }
    const history = useHistory(); 
    const handleGoDetails = (id) => {
        history.push(`/product/details/${id}`);
    }  
    
    let newImages = infos.infos.images.length ? infos.infos.images : [];
    let newImageCollection = [];
    for(let i = 0; i < newImages.length; i ++){
        if(newImages[i].indexOf('ryanscomputers') === -1){
            newImageCollection.push(serverPort+newImages[i])
        }
    }  
    return (
        <div className='item'>
        <div className='product product__info'>
            <div className='image__container'>
                {/* <img src={"/CartImages/"+images[Math.ceil(Math.random()*11)]}alt='product'/>  */}
                {newImageCollection.length ? 
                    <Link to={`/${infos.visible__url}_-_${infos.parent__father}`}>
                        <img src={newImageCollection[0]} alt="" /> 
                    </Link> :  
                    <Link to={`/${infos.visible__url}_-_${infos.parent__father}`}>
                        <img src='/sorry__image.jpg' alt="" />
                    </Link> 
                }
            </div>
            <div className='info__container'>
                <p className='product__title'  onClick={()=>handleGoDetails(infos.infos.product__id)} >{utilsHelper.stringOperations.cartStringCutter(infos.infos.title)}</p>
                <p className='product__id'  onClick={()=>handleGoDetails(infos.infos.product__id)} >Product ID :  {infos.infos.product__id}</p>
                <p className='price'>৳: {infos.infos.current__price}</p>
            </div>
        </div>
        <div className='product product__quantity'>
        <div className='button__container'>
            <button className='action__button' onClick={()=> handleDecreaseCount(infos.infos.product__id)}>-</button> 
            <button className='action__button count'>{infos.infos.quantity}</button> 
            <button className='action__button' onClick={()=> handleIncreaseCount(infos.infos.product__id)}>+</button>
        </div>
        <div className='action__button__center'>
            <button className='product__remove__from__cart__button' onClick={()=>handleRemoveFromCart(infos.infos.product__id)}><FontAwesomeIcon icon={faTrash}/></button>
            <button className='add__in__wishlist'><FontAwesomeIcon icon={faHeart}/></button>
        </div>
        </div>
        <div className='product product__subtotal'>
            <p className='subtotal__price'> ৳:  {infos.infos.current__price * infos.infos.quantity}</p>
        </div>
    </div>
    );
};

export default CartPageItem;