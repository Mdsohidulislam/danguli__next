import React from 'react';
import ReactDOM from 'react-dom';
import "react-responsive-carousel/lib/styles/carousel.min.css";
import {
  BrowserRouter as Router
} from "react-router-dom";
import "slick-carousel/slick/slick-theme.css";
import "slick-carousel/slick/slick.css";
import App from './Appp';
// scss  learning start 
import './CartEleven/CartEleven.globals.scss';
import './Components/bigNavbar/bigNavbar.globals.scss';
import './Components/BrandsCategories/BrandsCategories.globals.scss';
import './Components/Carousel/Carousel.globals.scss';
import './Components/CartPage/CartCheckOutForm.globals.scss';
import './Components/CartPage/CartPage.globals.scss';
import './Components/Carts/CartChowddo/CartChowddo.globals.scss';
import './Components/Carts/CartEight/CartEight.globals.scss';
import './Components/Carts/CartEleven/CartEleven.globals.scss';
import './Components/Carts/CartFive/CartFive.globals.scss';
import './Components/Carts/CartFour/CartFour.globals.scss';
import './Components/Carts/CartNine/CartNine.globals.scss';
import './Components/Carts/CartNn/CartNn.globals.scss';
import './Components/Carts/CartNn/LandingCartOne.globals.scss';
import './Components/Carts/CartOne/CartOne.globals.scss';
import './Components/Carts/CartSeven/CartSeven.globals.scss';
import './Components/Carts/CartSix/CartSix.globals.scss';
import './Components/Carts/CartTen/CartTen.globals.scss';
import './Components/Carts/CartThero/CartThero.globals.scss';
import './Components/Carts/CartThree/CartThree.globals.scss';
import './Components/Carts/CartTwo/CartTwo.globals.scss';
import './Components/Carts/CartTwoelve/CartTwoelve.globals.scss';
import './Components/Carts/RowCart/RowCart.globals.scss';
import './Components/Category/Category.globals.scss';
import './Components/FeaturedCategories/FeaturedCategory.globals.scss';
import './Components/FilterNavbar/FilterNavbar.globals.scss';
import './Components/Footer/Footer.globals.scss';
import './Components/FooterBanner/FooterBanner.globals.scss';
import './Components/HeaderButton/HeaderButton.globals.scss';
import './Components/HomePage/HomePage.globals.scss';
import './Components/HomeRow/HomeRows.globals.scss';
import './Components/ImageGrid/HomeImageGridView.globals.scss';
import './Components/ImageZoom/ImageZoom.globals.scss';
import './Components/Loading/loading.globals.scss';
import './Components/MultipleImageUpload/MultipleImageUpload.globals.scss';
import './Components/Views/AllBrandViews/AllBrandViews.globals.scss';
// components  style import start 
import './Components/HelpAnywhere/HelpAnyWhere.globals.scss';
import './Components/HomePagerSliders/HomePageSlider.globals.scss';
import './Components/MoreSave/MoreSave.globals.scss';
import './Components/OnNavbar/OnNavbar.globals.scss';
import './Components/OwenerFeatures/OwenerFeatures.globals.scss';
import './Components/ParentProduct/ParentProduct.globals.scss';
import './Components/PrintHomeBanner/PrintHomeBanner.globals.scss';
import './Components/ProductDetails/ProductDetails.globals.scss';
import './Components/ProductSearchBar/ProductSearchBar.globals.scss';
import './Components/ProductTopHeader/ProductTopHeader.globals.scss';
import './Components/SCSS/my__css__framework.globals.scss';
import './Components/Search/Search.globals.scss';
import './Components/SearchBarContainer/SearchBarContainer.globals.scss';
import './Components/SideBar/ProductItem.globals.scss';
import './Components/TechSuccess/TechSuccess.globals.scss';
// import './Components/SCSS/_variable.globals.scss';
import './Components/QuickView/QuickView.globals.scss';
import './Components/SideBar/SideBar.globals.scss';
import './Components/SliderSlider/SliderSlider.globals.scss';
import './Components/Terms/terms.globals.scss';
import './Components/TopNavbar/TopNavbar.globals.scss';
import './Components/TopRowHeaderTitleWithBorder/TopRowHeaderTitleWithBorder.globals.scss';
import './Components/Upload/Upload.globals.scss';
import './Components/UserExpectation/UserExpectation.globals.scss';
import './Components/UserGuideOption/UserGuideOption.globals.scss';
import './Components/Views/ChildProductsViews/ChildProductsViews.globals.scss';
import './Components/WishList/WishList.globals.scss';
import './index.css';
import './SelectedCarts/CartChowddo/CartChowddo.globals.scss';
// import './SelectedCarts/CartEight/CartEight.globals.scss';
import './SelectedCarts/CartEleven/CartEleven.globals.scss';
import './SelectedCarts/CartFive/CartFive.globals.scss';
import './SelectedCarts/CartFour/CartFour.globals.scss';
import './SelectedCarts/CartNine/CartNine.globals.scss';
import './SelectedCarts/CartOne/CartOne.globals.scss';
import './SelectedCarts/CartShow/CartShow.globals.scss';
import './SelectedCarts/CartTen/CartTen.globals.scss';
import './SelectedCarts/CartThero/CartThero.globals.scss';
import './SelectedCarts/CartTwo/CartTwo.globals.scss';
import './SelectedCarts/CartTwoelve/CartTwoelve.globals.scss';



ReactDOM.render(
  <React.StrictMode>
  <Router> 
      <App/>
    </Router>
  </React.StrictMode>,
  document.getElementById('root')
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals 
