import { faCartShopping, faHeart, faSearch } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { Link } from 'react-router-dom';
import { utilsHelper } from '../UTILS/utils';

const CartElevenDemoNextNoButton = ({infos}) => {
    
    return ( 
            <div className='cart__eleven__container__next'>
                <div className="image__container"> 
                    <Link to={`/${infos.visible__url}_-_${infos.parent__father}`}>
                        <img src={infos.infos.images[0].replace(/\/images\/assests/g, 'http://localhost:3009/images/assests')} alt='Hello world' title='Hello world' />      
                    </Link>
                    <div className='button__container'>
                <button> <FontAwesomeIcon icon={faCartShopping}/> </button>
                <button> <FontAwesomeIcon icon={faHeart}/></button>
                <button><FontAwesomeIcon icon={faSearch}/></button>
            </div>
                </div>
                <div className="info__container">
                    <hr className="top" />
                    <p className='product__category'>{infos.child}</p>
                    <div className='product__title__parent'>
                    <p className="product__title">{utilsHelper.stringOperations.cartNnStringCutter(infos.infos.title)}</p>
                    </div>
                    <div className="current__price">৳  {infos.infos.current__price}<span className="prev__price">৳ {infos.infos.previous__price}</span></div>  
                    
                </div>   
            </div>  
    );  
};

export default CartElevenDemoNextNoButton;