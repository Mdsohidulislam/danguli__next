// import React from 'react';

// const Specifications = () => {
//     return (
//         <div>
//             <h1>Hello world</h1>
//         </div>
//     );
// };

// export { Specifications };



let specificationsDemo = [
    {
        "title": "General",
        "infos": [
            {
                "title": "Brand",
                "info": "Asus"
            },
            {
                "title": "Model",
                "info": "Asus VP229HE"
            },
            {
                "title": "Series",
                "info": "Regular"
            },
            {
                "title": "Shape",
                "info": "Widescreen"
            }
        ]
    },
    {
        "title": "Display",
        "infos": [
            {
                "title": "Display Size (Inch)",
                "info": "21.5"
            },
            {
                "title": "Display Type",
                "info": "FHD IPS LED Display"
            },
            {
                "title": "Panel Type",
                "info": "IPS"
            },
            {
                "title": "Touch Screen",
                "info": "No"
            },
            {
                "title": "Display Resolution",
                "info": "1920x1080 (WxH) FHD"
            },
            {
                "title": "Aspect Ratio",
                "info": "16:9"
            },
            {
                "title": "Display Surface",
                "info": "Non-Glare"
            },
            {
                "title": "Brightness (cd/m2)",
                "info": "250cd/m2"
            },
            {
                "title": "Contrast Ratio (TCR/DCR)",
                "info": "1000:1"
            },
            {
                "title": "Refresh Rate (Hz)",
                "info": "75Hz"
            },
            {
                "title": "Adaptive-Sync Technology",
                "info": "Yes"
            },
            {
                "title": "AMD Radeon FreeSync",
                "info": "Yes"
            },
            {
                "title": "Color Support / Display Color",
                "info": "16.7 Million"
            },
            {
                "title": "Response Time (ms)",
                "info": "5ms (Gray to Gray)"
            },
            {
                "title": "Horizontal Viewing Angle",
                "info": "178 Degree"
            },
            {
                "title": "Vertical Viewing Angle",
                "info": "178 Degree"
            }
        ]
    },
    {
        "title": "Ports & Slots",
        "infos": [
            {
                "title": "VGA Port",
                "info": "1"
            },
            {
                "title": "HDMI Port",
                "info": "1"
            },
            {
                "title": "Lock Slot",
                "info": "Kensington Lock"
            }
        ]
    },
    {
        "title": "Audio",
        "infos": [
            {
                "title": "Speaker (Built-in)",
                "info": "No"
            }
        ]
    },
    {
        "title": "Adjustment",
        "infos": [
            {
                "title": "Height Adjustment",
                "info": "No"
            },
            {
                "title": "Tilt Adjustment",
                "info": "+23 degree - -5 degree"
            },
            {
                "title": "VESA Wall Mount Standard",
                "info": "100 x 100mm"
            }
        ]
    },
    {
        "title": "Power",
        "infos": [
            {
                "title": "Power Consumption",
                "info": "0.5W (Power Saving Mode), 0.3W (Power Off), 12W (Power Consumption)"
            }
        ]
    },
    {
        "title": "Physical Description",
        "infos": [
            {
                "title": "Weight (Kg)",
                "info": "2.86 Kg (With Stand), 2.52 Kg (Without Stand)"
            },
            {
                "title": "Dimensions",
                "info": "490 x 363 x 199mm (With Stand), 490 x 298 x 53mm (Without Stand)"
            }
        ]
    },
    {
        "title": "Warranty",
        "infos": [
            {
                "title": "Warranty",
                "info": "3 year"
            }
        ]
    },
    {
        "title": "Additional Info",
        "infos": [
            {
                "title": "Specialty",
                "info": "21.5-inch Full HD (1920 x 1080) LED backlight display with IPS 178 Degree wide viewing angle panel. Up to 75Hz refresh rate with Adaptive-Sync/FreeSync technology to eliminate tracing and ensure crisp and clear video playback. Extensive connectivity including HDMI and D-sub ports. ASUS Eye Care monitors feature TUV Rheinland-certified Flicker-free and Low Blue Light technologies to ensure a comfortable viewing experience."
            },
            {
                "title": "Others",
                "info": "Pixel Pitch: 0.248mm, ASUS Smart Contrast Ratio (ASCR) : 100000000:1, Flicker-free : Yes, Trace Free Technology : Yes, SPLENDID Technology : Yes, Color Temp. Selection : Yes(4 modes), QuickFit : Yes, HDCP : Yes, 1.4, VRR Technology : FreeSync, Low Blue Light : Yes, Signal Frequency: Digital Signal Frequency : 30-85 KHz (H) / 48-75 Hz (V), Analog Signal Frequency : 30-85 KHz (H) / 48-75 Hz (V), Voltage : 100-240V, 50/60Hz"
            },
            {
                "title": "Country Of Origin",
                "info": "Taiwan"
            },
            {
                "title": "Made in/ Assemble",
                "info": "China"
            }
        ]
    }
]

let detailsDemo = [
    {
        "tag": "h2",
        "text": "Details"
    },
    {
        "tag": "h2",
        "text": "Acer Nitro 7 AN715-51 Intel core i5 9300H 15.6 Inch FHD IPS Display Black Gaming Laptop"
    },
    {
        "tag": "p",
        "text": "Acer Nitro 7 AN715-51 Intel core i5 9300H 15.6 Inch FHD IPS Display Black Gaming Laptop is a high range laptop in Bangladesh. Acer Nitro 7 AN715-51 is a Acer brand laptop. Right Now available the Acer Nitro 7 AN715-51 Intel core i5 9300H 15.6 Inch FHD IPS Display Black Gaming Laptop includes all Ryans computers branches and our website."
    },
    {
        "tag": "p",
        "text": "Acer Nitro 7 AN715-51 comes with 9th Gen Intel Core i5 9300H processor. The Processor base frequency is 2.40 GHz to 4.10 GHz. 9th Gen Intel Core i5 9300H has 4 core and 8 Thread."
    },
    {
        "tag": "p",
        "text": "The Acer Nitro 7 AN715-51 laptop has DDR4 8GB RAM. The laptop Expansion RAM Slot is one . Maximum ram support 32GB."
    },
    {
        "tag": "p",
        "text": "Storage & Graphics"
    },
    {
        "tag": "p",
        "text": "Let’s discuss Acer Nitro 7 AN715-51 laptop storage. 1TB HDD SATA 7200 RPM & 256GB SSD NVMe PCIe used in this laptop. The Acer laptop has 6GB Dedicated Nvidia GTX 1660Ti."
    },
    {
        "tag": "p",
        "text": "Display & Ports & Slots"
    },
    {
        "tag": "p",
        "text": "The Acer Nitro 7 AN715-51 comes with a 15.6 inch FHD IPS LED display. Display Resolution is 1920 x 1080. The Acer laptop has Speaker. The WebCam offers you nice video calling, video recording, video streaming, clear picture capture, etc. The laptop has wifi, bluetooth & LAN connection."
    },
    {
        "tag": "p",
        "text": "The laptop has Black color variation in Bangladesh. The Acer Nitro 7 AN715-51 Intel core i5 9300H 15.6 Inch FHD IPS Display Black Gaming Laptop dimension is 23.14 x 363.4 x 259.5 mm. It’s a lightweight laptop, 2.50 Kg only. Acer Nitro 7 AN715-51 is assembled in China."
    },
    {
        "tag": "h2",
        "text": "Latest Acer Nitro 7 AN715-51 laptop Price in Bangladesh"
    },
    {
        "tag": "p",
        "text": "The latest Acer Nitro 7 AN715-51 laptop price in BD is given above. You can buy the Acer Nitro 7 AN715-51 Intel core i5 9300H 15.6 Inch FHD IPS Display Black Gaming Laptop from all Ryans computers Branches or our website. This Acer laptop is given 2 year (1 year for Battery and Adapter) Warranty. Ryans computers ensure that you can claim warranty from any branches, where you can purchase doesn’t matter."
    }
]

export { specificationsDemo, detailsDemo };

