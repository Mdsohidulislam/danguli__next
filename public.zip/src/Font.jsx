// bold font  start
// font-family: 'Fredoka One', cursive;
// font-family: 'Source Sans Pro', sans-serif;
// bold font  end