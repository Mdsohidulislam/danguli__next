// // import React from 'react'; 
// import { recommendedData } from "./database/CurrentData";

// const Appp = () => {
//     console.log(recommendedData);

//     const handleFilterData = () => {
//         let brandCollection = [];
//         let brandIdCollection = []; 
//         let typeCollection = [];
//         let typeIdCollection = [];
//         recommendedData.forEach((info, index) => {
            // if(brandCollection.indexOf(info.brand) === -1){
            //     brandCollection.push(info.brand);
            //     brandIdCollection.push([info.product__id]);
            // }else{
            //     let brandIndex = brandCollection.indexOf(info.brand);
            //         brandIdCollection[brandIndex].push(info.product__id)
            // }
            // if(typeCollection.indexOf(info.child) === -1){
            //     typeCollection.push(info.child);
            //     typeIdCollection.push([info.product__id]);
            // }else{
            //     let typeIndex = typeCollection.indexOf(info.child);
            //     typeIdCollection[typeIndex].push(info.product__id)
            // }
//         })
//         console.log(brandCollection, brandIdCollection);
//         console.log(typeCollection, typeIdCollection);
//     }
//     const handleRangeChange = (e) => {
//         console.log(e.target.value);
//     } 
//     return (
//         <div>
//             <h1>Hello World</h1>
//             <button onClick={handleFilterData}>filterData</button>
//             <input type='range' min={0} max={500} style={{width:'300px'}} onChange={handleRangeChange}/>
//         </div>
//     );
// };

// export default Appp;


  import { ContextProvider } from './DanguliContext';
import DanguliRouter from './DanguliRouter';


const App = () => {
    
    return (
        <div>
            
            <ContextProvider>
                <DanguliRouter/>
            </ContextProvider>
        </div>
    );
};

export default App; 

