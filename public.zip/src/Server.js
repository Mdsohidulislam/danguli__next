import axios from 'axios';
import React, { useState } from 'react';
import { specificationsBackwardSlashMacker, stringConverter } from './UTILS/utils';


const Server = () => {

    const [products, setProducts] = useState([]);
const handleGetAllCollection = (database) => {
    axios.get('http://localhost:3009/getAllCollection',{headers:{collection:'specifications'}})
    .then(res => { 
        let resultData = res.data.result;
        
        const collections = [];
        // console.log(JSON.parse(stringConverter(specificationsBackwardSlashMacker(resultData[2843].specifications)))); /// 596

        resultData.forEach((info, index) => {
            collections.push(JSON.parse(stringConverter(specificationsBackwardSlashMacker(info.specifications))));
        }) 
        setProducts(collections);
    }).catch(err => {
        console.log(err.message);
    })
}
    console.log(products);
    return (
        <div>
            <h1>Hello world</h1>
            <button onClick={()=>handleGetAllCollection()}>Get All Data</button>
            {products.length? <div dangerouslySetInnerHTML={{__html: products[Math.floor(Math.random()*products.length - 2)].overviews}}></div> : ""}
        </div>
    );
};

export default Server;

//todo get all overviews start
// const [products, setProducts] = useState([]);
// const handleGetAllCollection = () => {
//     axios.get('http://localhost:3009/getAllCollection',{headers:{collection:'overviews'}})
//     .then(res => { 
//         let resultData = res.data.result;
        
//         const collections = [];
//         // console.log(JSON.parse(stringConverter(specificationsBackwardSlashMacker(resultData[2843].specifications)))); /// 596

//         resultData.forEach((info, index) => {
//             // collections.push(JSON.parse(stringConverter(specificationsBackwardSlashMacker(resultData     
//             let newInfo = {...info};
//             let details = stringConverter(specificationsStringConverter(info.overviews));
//             details = details.slice(1);
//             details = details.slice(0, details.length - 1);
//             newInfo.overviews = details;
//             collections.push(newInfo); 
//         })  
//         setProducts(collections);
//     }).catch(err => {
//         console.log(err.message);
//     })
// }
// console.log(products);
//todo get all overviews end

// TODO get all details from server start
// const [products, setProducts] = useState([]);
// const handleGetAllCollection = (database) => {
//     axios.get('http://localhost:3009/getAllCollection',{headers:{collection:'details'}})
//     .then(res => { 
//         let resultData = res.data.result;
        
//         const collections = [];
//         // console.log(JSON.parse(stringConverter(specificationsBackwardSlashMacker(resultData[2843].specifications)))); /// 596

//         resultData.forEach((info, index) => {
//             // collections.push(JSON.parse(stringConverter(specificationsBackwardSlashMacker(resultData     
//             let newInfo = {...info};
//             let details = stringConverter(specificationsStringConverter(info.details));
//             details = details.slice(1);
//             details = details.slice(0, details.length - 1);
//             newInfo.details = details;
//             collections.push(newInfo);
//         })  
//         setProducts(collections);
//     }).catch(err => {
//         console.log(err.message);
//     })
// }
// console.log(products);
// {products.length? <div dangerouslySetInnerHTML={{__html: products[Math.floor(Math.random()*products.length - 2)].details}}></div> : ""}
// TODO get all details from server end

// TODO get all specifications from server start
// const [products, setProducts] = useState([]);
// const handleGetAllCollection = (database) => {
//     axios.get('http://localhost:3009/getAllCollection',{headers:{collection:'specifications'}})
//     .then(res => { 
//         let resultData = res.data.result;
        
//         const collections = [];
//         // console.log(JSON.parse(stringConverter(specificationsBackwardSlashMacker(resultData[2843].specifications)))); /// 596

//         resultData.forEach((info, index) => {
//             collections.push(JSON.parse(stringConverter(specificationsBackwardSlashMacker(resultData[2843].specifications))));
//         })  
//         setProducts(collections);
//     }).catch(err => {
//         console.log(err.message);
//     })
// }
 
//TODO get all specifications from server end


// TODO get all products form server  start

// const [products, setProducts] = useState([]);
// const handleGetAllCollection = (database) => {
//     axios.get('http://localhost:3009/getAllCollection',{headers:{collection:'product'}})
//     .then(res => { 
//         let resultData = res.data.result;

//         const collections = [];
//         if(res.data.status__code === 200){
//             resultData.forEach((info) => {
//                 let item = stringConverter(info.infos); 
//                 collections.push(JSON.parse(item))
//             })
//         }
//         setProducts(collections);
//     }).catch(err => {
//         console.log(err.message);
//     })
// }


// TODO get all products from server end


// items to allNavLinksConverter start
// let items = [
//     {
//         "name": "All Laptop",
//         "link__name": "All Laptop",
//         "img__src": "/laptop.jpg",
//         "parent__link": "LAPTOP",
//         "type": "head",
//         "other": true,
//         "topper": "All Laptop"
//     },
//     {
//         "name": " Apple",
//         "link__name": " Apple",
//         "img__src": "/laptop.jpg",
//         "parent__link": "LAPTOP",
//         "type": "link",
//         "other": false,
//         "topper": "All Laptop"
//     },
//     {
//         "name": " Asus",
//         "link__name": " Asus",
//         "img__src": "/laptop.jpg",
//         "parent__link": "LAPTOP",
//         "type": "link",
//         "other": false,
//         "topper": "All Laptop"
//     },
//     {
//         "name": " Acer",
//         "link__name": " Acer",
//         "img__src": "/laptop.jpg",
//         "parent__link": "LAPTOP",
//         "type": "link",
//         "other": false,
//         "topper": "All Laptop"
//     },
//     {
//         "name": " Avita",
//         "link__name": " Avita",
//         "img__src": "/laptop.jpg",
//         "parent__link": "LAPTOP",
//         "type": "link",
//         "other": false,
//         "topper": "All Laptop"
//     },
//     {
//         "name": " Dell",
//         "link__name": " Dell",
//         "img__src": "/laptop.jpg",
//         "parent__link": "LAPTOP",
//         "type": "link",
//         "other": false,
//         "topper": "All Laptop"
//     },
//     {
//         "name": " Chuwi",
//         "link__name": " Chuwi",
//         "img__src": "/laptop.jpg",
//         "parent__link": "LAPTOP",
//         "type": "link",
//         "other": false,
//         "topper": "All Laptop"
//     },
//     {
//         "name": " HP",
//         "link__name": " HP",
//         "img__src": "/laptop.jpg",
//         "parent__link": "LAPTOP",
//         "type": "link",
//         "other": false,
//         "topper": "All Laptop"
//     },
//     {
//         "name": " Huawei",
//         "link__name": " Huawei",
//         "img__src": "/laptop.jpg",
//         "parent__link": "LAPTOP",
//         "type": "link",
//         "other": false,
//         "topper": "All Laptop"
//     },
//     {
//         "name": " i-Life",
//         "link__name": " i-Life",
//         "img__src": "/laptop.jpg",
//         "parent__link": "LAPTOP",
//         "type": "link",
//         "other": false,
//         "topper": "All Laptop"
//     },
//     {
//         "name": " Lenovo",
//         "link__name": " Lenovo",
//         "img__src": "/laptop.jpg",
//         "parent__link": "LAPTOP",
//         "type": "link",
//         "other": false,
//         "topper": "All Laptop"
//     },
//     {
//         "name": " Microsoft",
//         "link__name": " Microsoft",
//         "img__src": "/laptop.jpg",
//         "parent__link": "LAPTOP",
//         "type": "link",
//         "other": false,
//         "topper": "All Laptop"
//     },
//     {
//         "name": " MSI",
//         "link__name": " MSI",
//         "img__src": "/laptop.jpg",
//         "parent__link": "LAPTOP",
//         "type": "link",
//         "other": false,
//         "topper": "All Laptop"
//     },
//     {
//         "name": " Nexstgo",
//         "link__name": " Nexstgo",
//         "img__src": "/laptop.jpg",
//         "parent__link": "LAPTOP",
//         "type": "link",
//         "other": false,
//         "topper": "All Laptop"
//     },
//     {
//         "name": " Razer",
//         "link__name": " Razer",
//         "img__src": "/laptop.jpg",
//         "parent__link": "LAPTOP",
//         "type": "link",
//         "other": false,
//         "topper": "All Laptop"
//     },
//     {
//         "name": " Gigabyte",
//         "link__name": " Gigabyte",
//         "img__src": "/laptop.jpg",
//         "parent__link": "LAPTOP",
//         "type": "link",
//         "other": false,
//         "topper": "All Laptop"
//     },
//     {
//         "name": "Accessories",
//         "link__name": "Accessories",
//         "img__src": "/laptop.jpg",
//         "parent__link": "LAPTOP",
//         "type": "head",
//         "other": true,
//         "topper": "Accessories"
//     },
//     {
//         "name": " Laptop Ram",
//         "link__name": " Laptop Ram",
//         "img__src": "/laptop.jpg",
//         "parent__link": "LAPTOP",
//         "type": "link",
//         "other": false,
//         "topper": "Accessories"
//     },
//     {
//         "name": " Laptop Cooler",
//         "link__name": " Laptop Cooler",
//         "img__src": "/laptop.jpg",
//         "parent__link": "LAPTOP",
//         "type": "link",
//         "other": false,
//         "topper": "Accessories"
//     },
//     {
//         "name": " Caddy",
//         "link__name": " Caddy",
//         "img__src": "/laptop.jpg",
//         "parent__link": "LAPTOP",
//         "type": "link",
//         "other": false,
//         "topper": "Accessories"
//     },
//     {
//         "name": " Laptop Bag",
//         "link__name": " Laptop Bag",
//         "img__src": "/laptop.jpg",
//         "parent__link": "LAPTOP",
//         "type": "link",
//         "other": false,
//         "topper": "Accessories"
//     },
//     {
//         "name": " Stand",
//         "link__name": " Stand",
//         "img__src": "/laptop.jpg",
//         "parent__link": "LAPTOP",
//         "type": "link",
//         "other": false,
//         "topper": "Accessories"
//     },
//     {
//         "name": " Battery",
//         "link__name": " Battery",
//         "img__src": "/laptop.jpg",
//         "parent__link": "LAPTOP",
//         "type": "link",
//         "other": false,
//         "topper": "Accessories"
//     },
//     {
//         "name": " Adapter",
//         "link__name": " Adapter",
//         "img__src": "/laptop.jpg",
//         "parent__link": "LAPTOP",
//         "type": "link",
//         "other": false,
//         "topper": "Accessories"
//     },
//     {
//         "name": "Desktop PC",
//         "link__name": "Desktop PC",
//         "img__src": "/laptop.jpg",
//         "parent__link": "DESKTOP PC AND SERVER",
//         "type": "head",
//         "other": true,
//         "topper": "Desktop PC"
//     },
//     {
//         "name": " Brand Desktop PC",
//         "link__name": " Brand Desktop PC",
//         "img__src": "/laptop.jpg",
//         "parent__link": "DESKTOP PC AND SERVER",
//         "type": "link",
//         "other": false,
//         "topper": "Desktop PC"
//     },
//     {
//         "name": " All In One PC",
//         "link__name": " All In One PC",
//         "img__src": "/laptop.jpg",
//         "parent__link": "DESKTOP PC AND SERVER",
//         "type": "link",
//         "other": false,
//         "topper": "Desktop PC"
//     },
//     {
//         "name": " Mini PC",
//         "link__name": " Mini PC",
//         "img__src": "/laptop.jpg",
//         "parent__link": "DESKTOP PC AND SERVER",
//         "type": "link",
//         "other": false,
//         "topper": "Desktop PC"
//     },
//     {
//         "name": " Ryans PC",
//         "link__name": " Ryans PC",
//         "img__src": "/laptop.jpg",
//         "parent__link": "DESKTOP PC AND SERVER",
//         "type": "link",
//         "other": false,
//         "topper": "Desktop PC"
//     },
//     {
//         "name": "Desktop Component",
//         "link__name": "Desktop Component",
//         "img__src": "/laptop.jpg",
//         "parent__link": "DESKTOP PC AND SERVER",
//         "type": "head",
//         "other": true,
//         "topper": "Desktop Component"
//     },
//     {
//         "name": " Processor",
//         "link__name": " Processor",
//         "img__src": "/laptop.jpg",
//         "parent__link": "DESKTOP PC AND SERVER",
//         "type": "link",
//         "other": false,
//         "topper": "Desktop Component"
//     },
//     {
//         "name": " Motherboard",
//         "link__name": " Motherboard",
//         "img__src": "/laptop.jpg",
//         "parent__link": "DESKTOP PC AND SERVER",
//         "type": "link",
//         "other": false,
//         "topper": "Desktop Component"
//     },
//     {
//         "name": " Desktop Ram",
//         "link__name": " Desktop Ram",
//         "img__src": "/laptop.jpg",
//         "parent__link": "DESKTOP PC AND SERVER",
//         "type": "link",
//         "other": false,
//         "topper": "Desktop Component"
//     },
//     {
//         "name": " Optical Device",
//         "link__name": " Optical Device",
//         "img__src": "/laptop.jpg",
//         "parent__link": "DESKTOP PC AND SERVER",
//         "type": "link",
//         "other": false,
//         "topper": "Desktop Component"
//     },
//     {
//         "name": " Graphics Card",
//         "link__name": " Graphics Card",
//         "img__src": "/laptop.jpg",
//         "parent__link": "DESKTOP PC AND SERVER",
//         "type": "link",
//         "other": false,
//         "topper": "Desktop Component"
//     },
//     {
//         "name": " Power Supply",
//         "link__name": " Power Supply",
//         "img__src": "/laptop.jpg",
//         "parent__link": "DESKTOP PC AND SERVER",
//         "type": "link",
//         "other": false,
//         "topper": "Desktop Component"
//     },
//     {
//         "name": " Casing",
//         "link__name": " Casing",
//         "img__src": "/laptop.jpg",
//         "parent__link": "DESKTOP PC AND SERVER",
//         "type": "link",
//         "other": false,
//         "topper": "Desktop Component"
//     },
//     {
//         "name": " Casing Fan",
//         "link__name": " Casing Fan",
//         "img__src": "/laptop.jpg",
//         "parent__link": "DESKTOP PC AND SERVER",
//         "type": "link",
//         "other": false,
//         "topper": "Desktop Component"
//     },
//     {
//         "name": " CPU Cooler",
//         "link__name": " CPU Cooler",
//         "img__src": "/laptop.jpg",
//         "parent__link": "DESKTOP PC AND SERVER",
//         "type": "link",
//         "other": false,
//         "topper": "Desktop Component"
//     },
//     {
//         "name": " Keyboard",
//         "link__name": " Keyboard",
//         "img__src": "/laptop.jpg",
//         "parent__link": "DESKTOP PC AND SERVER",
//         "type": "link",
//         "other": false,
//         "topper": "Desktop Component"
//     },
//     {
//         "name": " Mouse",
//         "link__name": " Mouse",
//         "img__src": "/laptop.jpg",
//         "parent__link": "DESKTOP PC AND SERVER",
//         "type": "link",
//         "other": false,
//         "topper": "Desktop Component"
//     },
//     {
//         "name": " Keyboard and Mouse Combo",
//         "link__name": " Keyboard and Mouse Combo",
//         "img__src": "/laptop.jpg",
//         "parent__link": "DESKTOP PC AND SERVER",
//         "type": "link",
//         "other": false,
//         "topper": "Desktop Component"
//     },
//     {
//         "name": " Mouse Pad",
//         "link__name": " Mouse Pad",
//         "img__src": "/laptop.jpg",
//         "parent__link": "DESKTOP PC AND SERVER",
//         "type": "link",
//         "other": false,
//         "topper": "Desktop Component"
//     },
//     {
//         "name": " UPS",
//         "link__name": " UPS",
//         "img__src": "/laptop.jpg",
//         "parent__link": "DESKTOP PC AND SERVER",
//         "type": "link",
//         "other": false,
//         "topper": "Desktop Component"
//     },
//     {
//         "name": "Server",
//         "link__name": "Server",
//         "img__src": "/laptop.jpg",
//         "parent__link": "DESKTOP PC AND SERVER",
//         "type": "head",
//         "other": true,
//         "topper": "Server"
//     },
//     {
//         "name": " Rack",
//         "link__name": " Rack",
//         "img__src": "/laptop.jpg",
//         "parent__link": "DESKTOP PC AND SERVER",
//         "type": "link",
//         "other": false,
//         "topper": "Server"
//     },
//     {
//         "name": " Tower",
//         "link__name": " Tower",
//         "img__src": "/laptop.jpg",
//         "parent__link": "DESKTOP PC AND SERVER",
//         "type": "link",
//         "other": false,
//         "topper": "Server"
//     },
//     {
//         "name": "Server Component",
//         "link__name": "Server Component",
//         "img__src": "/laptop.jpg",
//         "parent__link": "DESKTOP PC AND SERVER",
//         "type": "head",
//         "other": true,
//         "topper": "Server Component"
//     },
//     {
//         "name": " Server Cabinet",
//         "link__name": " Server Cabinet",
//         "img__src": "/laptop.jpg",
//         "parent__link": "DESKTOP PC AND SERVER",
//         "type": "link",
//         "other": false,
//         "topper": "Server Component"
//     },
//     {
//         "name": " Server Ram",
//         "link__name": " Server Ram",
//         "img__src": "/laptop.jpg",
//         "parent__link": "DESKTOP PC AND SERVER",
//         "type": "link",
//         "other": false,
//         "topper": "Server Component"
//     },
//     {
//         "name": "Desktop Accessories",
//         "link__name": "Desktop Accessories",
//         "img__src": "/laptop.jpg",
//         "parent__link": "DESKTOP PC AND SERVER",
//         "type": "head",
//         "other": true,
//         "topper": "Desktop Accessories"
//     },
//     {
//         "name": " LED Strip",
//         "link__name": " LED Strip",
//         "img__src": "/laptop.jpg",
//         "parent__link": "DESKTOP PC AND SERVER",
//         "type": "link",
//         "other": false,
//         "topper": "Desktop Accessories"
//     },
//     {
//         "name": " Casing Accessories",
//         "link__name": " Casing Accessories",
//         "img__src": "/laptop.jpg",
//         "parent__link": "DESKTOP PC AND SERVER",
//         "type": "link",
//         "other": false,
//         "topper": "Desktop Accessories"
//     },
//     {
//         "name": " Side Panel",
//         "link__name": " Side Panel",
//         "img__src": "/laptop.jpg",
//         "parent__link": "DESKTOP PC AND SERVER",
//         "type": "link",
//         "other": false,
//         "topper": "Desktop Accessories"
//     },
//     {
//         "name": " Thermal Paste",
//         "link__name": " Thermal Paste",
//         "img__src": "/laptop.jpg",
//         "parent__link": "DESKTOP PC AND SERVER",
//         "type": "link",
//         "other": false,
//         "topper": "Desktop Accessories"
//     },
//     {
//         "name": "Gaming Component",
//         "link__name": "Gaming Component",
//         "img__src": "/laptop.jpg",
//         "parent__link": "GAMING",
//         "type": "head",
//         "other": true,
//         "topper": "Gaming Component"
//     },
//     {
//         "name": " Gaming Console",
//         "link__name": " Gaming Console",
//         "img__src": "/laptop.jpg",
//         "parent__link": "GAMING",
//         "type": "link",
//         "other": false,
//         "topper": "Gaming Component"
//     },
//     {
//         "name": " Gaming Controller",
//         "link__name": " Gaming Controller",
//         "img__src": "/laptop.jpg",
//         "parent__link": "GAMING",
//         "type": "link",
//         "other": false,
//         "topper": "Gaming Component"
//     },
//     {
//         "name": " Capture Card",
//         "link__name": " Capture Card",
//         "img__src": "/laptop.jpg",
//         "parent__link": "GAMING",
//         "type": "link",
//         "other": false,
//         "topper": "Gaming Component"
//     },
//     {
//         "name": " Games",
//         "link__name": " Games",
//         "img__src": "/laptop.jpg",
//         "parent__link": "GAMING",
//         "type": "link",
//         "other": false,
//         "topper": "Gaming Component"
//     },
//     {
//         "name": " Gaming Chair",
//         "link__name": " Gaming Chair",
//         "img__src": "/laptop.jpg",
//         "parent__link": "GAMING",
//         "type": "link",
//         "other": false,
//         "topper": "Gaming Component"
//     },
//     {
//         "name": " Gaming Desk",
//         "link__name": " Gaming Desk",
//         "img__src": "/laptop.jpg",
//         "parent__link": "GAMING",
//         "type": "link",
//         "other": false,
//         "topper": "Gaming Component"
//     },
//     {
//         "name": "Gaming Laptop",
//         "link__name": "Gaming Laptop",
//         "img__src": "/laptop.jpg",
//         "parent__link": "GAMING",
//         "type": "head",
//         "other": true,
//         "topper": "Gaming Laptop"
//     },
//     {
//         "name": "Gaming Desktop PC",
//         "link__name": "Gaming Desktop PC",
//         "img__src": "/laptop.jpg",
//         "parent__link": "GAMING",
//         "type": "head",
//         "other": true,
//         "topper": "Gaming Desktop PC"
//     },
//     {
//         "name": " Ryans PC",
//         "link__name": " Ryans PC",
//         "img__src": "/laptop.jpg",
//         "parent__link": "GAMING",
//         "type": "link",
//         "other": false,
//         "topper": "Gaming Desktop PC"
//     },
//     {
//         "name": "Gaming Desktop Component",
//         "link__name": "Gaming Desktop Component",
//         "img__src": "/laptop.jpg",
//         "parent__link": "GAMING",
//         "type": "head",
//         "other": true,
//         "topper": "Gaming Desktop Component"
//     },
//     {
//         "name": " Motherboard",
//         "link__name": " Motherboard",
//         "img__src": "/laptop.jpg",
//         "parent__link": "GAMING",
//         "type": "link",
//         "other": false,
//         "topper": "Gaming Desktop Component"
//     },
//     {
//         "name": " Desktop Ram",
//         "link__name": " Desktop Ram",
//         "img__src": "/laptop.jpg",
//         "parent__link": "GAMING",
//         "type": "link",
//         "other": false,
//         "topper": "Gaming Desktop Component"
//     },
//     {
//         "name": " Graphics Card",
//         "link__name": " Graphics Card",
//         "img__src": "/laptop.jpg",
//         "parent__link": "GAMING",
//         "type": "link",
//         "other": false,
//         "topper": "Gaming Desktop Component"
//     },
//     {
//         "name": " Power Supply",
//         "link__name": " Power Supply",
//         "img__src": "/laptop.jpg",
//         "parent__link": "GAMING",
//         "type": "link",
//         "other": false,
//         "topper": "Gaming Desktop Component"
//     },
//     {
//         "name": " Casing",
//         "link__name": " Casing",
//         "img__src": "/laptop.jpg",
//         "parent__link": "GAMING",
//         "type": "link",
//         "other": false,
//         "topper": "Gaming Desktop Component"
//     },
//     {
//         "name": " CPU Cooler",
//         "link__name": " CPU Cooler",
//         "img__src": "/laptop.jpg",
//         "parent__link": "GAMING",
//         "type": "link",
//         "other": false,
//         "topper": "Gaming Desktop Component"
//     },
//     {
//         "name": " Keyboard",
//         "link__name": " Keyboard",
//         "img__src": "/laptop.jpg",
//         "parent__link": "GAMING",
//         "type": "link",
//         "other": false,
//         "topper": "Gaming Desktop Component"
//     },
//     {
//         "name": " Mouse",
//         "link__name": " Mouse",
//         "img__src": "/laptop.jpg",
//         "parent__link": "GAMING",
//         "type": "link",
//         "other": false,
//         "topper": "Gaming Desktop Component"
//     },
//     {
//         "name": " Mouse Pad",
//         "link__name": " Mouse Pad",
//         "img__src": "/laptop.jpg",
//         "parent__link": "GAMING",
//         "type": "link",
//         "other": false,
//         "topper": "Gaming Desktop Component"
//     },
//     {
//         "name": " LED Strip",
//         "link__name": " LED Strip",
//         "img__src": "/laptop.jpg",
//         "parent__link": "GAMING",
//         "type": "link",
//         "other": false,
//         "topper": "Gaming Desktop Component"
//     },
//     {
//         "name": "Gaming Monitor",
//         "link__name": "Gaming Monitor",
//         "img__src": "/laptop.jpg",
//         "parent__link": "GAMING",
//         "type": "head",
//         "other": true,
//         "topper": "Gaming Monitor"
//     },
//     {
//         "name": "Sound System",
//         "link__name": "Sound System",
//         "img__src": "/laptop.jpg",
//         "parent__link": "GAMING",
//         "type": "head",
//         "other": true,
//         "topper": "Sound System"
//     },
//     {
//         "name": " Speaker",
//         "link__name": " Speaker",
//         "img__src": "/laptop.jpg",
//         "parent__link": "GAMING",
//         "type": "link",
//         "other": false,
//         "topper": "Sound System"
//     },
//     {
//         "name": " Headphone",
//         "link__name": " Headphone",
//         "img__src": "/laptop.jpg",
//         "parent__link": "GAMING",
//         "type": "link",
//         "other": false,
//         "topper": "Sound System"
//     },
//     {
//         "name": " Microphone",
//         "link__name": " Microphone",
//         "img__src": "/laptop.jpg",
//         "parent__link": "GAMING",
//         "type": "link",
//         "other": false,
//         "topper": "Sound System"
//     },
//     {
//         "name": " Earphone",
//         "link__name": " Earphone",
//         "img__src": "/laptop.jpg",
//         "parent__link": "GAMING",
//         "type": "link",
//         "other": false,
//         "topper": "Sound System"
//     },
//     {
//         "name": "Network Router",
//         "link__name": "Network Router",
//         "img__src": "/laptop.jpg",
//         "parent__link": "GAMING",
//         "type": "head",
//         "other": true,
//         "topper": "Network Router"
//     },
//     {
//         "name": "All Monitor",
//         "link__name": "All Monitor",
//         "img__src": "/laptop.jpg",
//         "parent__link": "MONITOR",
//         "type": "head",
//         "other": true,
//         "topper": "All Monitor"
//     },
//     {
//         "name": " Asus",
//         "link__name": " Asus",
//         "img__src": "/laptop.jpg",
//         "parent__link": "MONITOR",
//         "type": "link",
//         "other": false,
//         "topper": "All Monitor"
//     },
//     {
//         "name": " Aoc",
//         "link__name": " Aoc",
//         "img__src": "/laptop.jpg",
//         "parent__link": "MONITOR",
//         "type": "link",
//         "other": false,
//         "topper": "All Monitor"
//     },
//     {
//         "name": " Acer",
//         "link__name": " Acer",
//         "img__src": "/laptop.jpg",
//         "parent__link": "MONITOR",
//         "type": "link",
//         "other": false,
//         "topper": "All Monitor"
//     },
//     {
//         "name": " Benq",
//         "link__name": " Benq",
//         "img__src": "/laptop.jpg",
//         "parent__link": "MONITOR",
//         "type": "link",
//         "other": false,
//         "topper": "All Monitor"
//     },
//     {
//         "name": " Dell",
//         "link__name": " Dell",
//         "img__src": "/laptop.jpg",
//         "parent__link": "MONITOR",
//         "type": "link",
//         "other": false,
//         "topper": "All Monitor"
//     },
//     {
//         "name": " Gigabyte",
//         "link__name": " Gigabyte",
//         "img__src": "/laptop.jpg",
//         "parent__link": "MONITOR",
//         "type": "link",
//         "other": false,
//         "topper": "All Monitor"
//     },
//     {
//         "name": " HP",
//         "link__name": " HP",
//         "img__src": "/laptop.jpg",
//         "parent__link": "MONITOR",
//         "type": "link",
//         "other": false,
//         "topper": "All Monitor"
//     },
//     {
//         "name": " Xiaomi",
//         "link__name": " Xiaomi",
//         "img__src": "/laptop.jpg",
//         "parent__link": "MONITOR",
//         "type": "link",
//         "other": false,
//         "topper": "All Monitor"
//     },
//     {
//         "name": " Gamemax",
//         "link__name": " Gamemax",
//         "img__src": "/laptop.jpg",
//         "parent__link": "MONITOR",
//         "type": "link",
//         "other": false,
//         "topper": "All Monitor"
//     },
//     {
//         "name": " LG",
//         "link__name": " LG",
//         "img__src": "/laptop.jpg",
//         "parent__link": "MONITOR",
//         "type": "link",
//         "other": false,
//         "topper": "All Monitor"
//     },
//     {
//         "name": " Lenovo",
//         "link__name": " Lenovo",
//         "img__src": "/laptop.jpg",
//         "parent__link": "MONITOR",
//         "type": "link",
//         "other": false,
//         "topper": "All Monitor"
//     },
//     {
//         "name": " MSI",
//         "link__name": " MSI",
//         "img__src": "/laptop.jpg",
//         "parent__link": "MONITOR",
//         "type": "link",
//         "other": false,
//         "topper": "All Monitor"
//     },
//     {
//         "name": " Philips",
//         "link__name": " Philips",
//         "img__src": "/laptop.jpg",
//         "parent__link": "MONITOR",
//         "type": "link",
//         "other": false,
//         "topper": "All Monitor"
//     },
//     {
//         "name": " Samsung",
//         "link__name": " Samsung",
//         "img__src": "/laptop.jpg",
//         "parent__link": "MONITOR",
//         "type": "link",
//         "other": false,
//         "topper": "All Monitor"
//     },
//     {
//         "name": " Viewsonic",
//         "link__name": " Viewsonic",
//         "img__src": "/laptop.jpg",
//         "parent__link": "MONITOR",
//         "type": "link",
//         "other": false,
//         "topper": "All Monitor"
//     },
//     {
//         "name": " Huawei",
//         "link__name": " Huawei",
//         "img__src": "/laptop.jpg",
//         "parent__link": "MONITOR",
//         "type": "link",
//         "other": false,
//         "topper": "All Monitor"
//     },
//     {
//         "name": " Fantech",
//         "link__name": " Fantech",
//         "img__src": "/laptop.jpg",
//         "parent__link": "MONITOR",
//         "type": "link",
//         "other": false,
//         "topper": "All Monitor"
//     },
//     {
//         "name": " Corsair",
//         "link__name": " Corsair",
//         "img__src": "/laptop.jpg",
//         "parent__link": "MONITOR",
//         "type": "link",
//         "other": false,
//         "topper": "All Monitor"
//     },
//     {
//         "name": " Hikvision",
//         "link__name": " Hikvision",
//         "img__src": "/laptop.jpg",
//         "parent__link": "MONITOR",
//         "type": "link",
//         "other": false,
//         "topper": "All Monitor"
//     },
//     {
//         "name": " INNOVTECH",
//         "link__name": " INNOVTECH",
//         "img__src": "/laptop.jpg",
//         "parent__link": "MONITOR",
//         "type": "link",
//         "other": false,
//         "topper": "All Monitor"
//     },
//     {
//         "name": " Razer",
//         "link__name": " Razer",
//         "img__src": "/laptop.jpg",
//         "parent__link": "MONITOR",
//         "type": "link",
//         "other": false,
//         "topper": "All Monitor"
//     },
//     {
//         "name": "Monitor Accessories",
//         "link__name": "Monitor Accessories",
//         "img__src": "/laptop.jpg",
//         "parent__link": "MONITOR",
//         "type": "head",
//         "other": true,
//         "topper": "Monitor Accessories"
//     },
//     {
//         "name": " Monitor Mounts and Brackets",
//         "link__name": " Monitor Mounts and Brackets",
//         "img__src": "/laptop.jpg",
//         "parent__link": "MONITOR",
//         "type": "link",
//         "other": false,
//         "topper": "Monitor Accessories"
//     },
//     {
//         "name": "Regular Tablet",
//         "link__name": "Regular Tablet",
//         "img__src": "/laptop.jpg",
//         "parent__link": "TABLET",
//         "type": "head",
//         "other": true,
//         "topper": "Regular Tablet"
//     },
//     {
//         "name": " All Brands",
//         "link__name": " All Brands",
//         "img__src": "/laptop.jpg",
//         "parent__link": "TABLET",
//         "type": "link",
//         "other": false,
//         "topper": "Regular Tablet"
//     },
//     {
//         "name": " Amazon",
//         "link__name": " Amazon",
//         "img__src": "/laptop.jpg",
//         "parent__link": "TABLET",
//         "type": "link",
//         "other": false,
//         "topper": "Regular Tablet"
//     },
//     {
//         "name": " Lenovo",
//         "link__name": " Lenovo",
//         "img__src": "/laptop.jpg",
//         "parent__link": "TABLET",
//         "type": "link",
//         "other": false,
//         "topper": "Regular Tablet"
//     },
//     {
//         "name": " Samsung",
//         "link__name": " Samsung",
//         "img__src": "/laptop.jpg",
//         "parent__link": "TABLET",
//         "type": "link",
//         "other": false,
//         "topper": "Regular Tablet"
//     },
//     {
//         "name": " Huawei",
//         "link__name": " Huawei",
//         "img__src": "/laptop.jpg",
//         "parent__link": "TABLET",
//         "type": "link",
//         "other": false,
//         "topper": "Regular Tablet"
//     },
//     {
//         "name": "Apple Tablet",
//         "link__name": "Apple Tablet",
//         "img__src": "/laptop.jpg",
//         "parent__link": "TABLET",
//         "type": "head",
//         "other": true,
//         "topper": "Apple Tablet"
//     },
//     {
//         "name": " iPad",
//         "link__name": " iPad",
//         "img__src": "/laptop.jpg",
//         "parent__link": "TABLET",
//         "type": "link",
//         "other": false,
//         "topper": "Apple Tablet"
//     },
//     {
//         "name": "E-Reader Tablet",
//         "link__name": "E-Reader Tablet",
//         "img__src": "/laptop.jpg",
//         "parent__link": "TABLET",
//         "type": "head",
//         "other": true,
//         "topper": "E-Reader Tablet"
//     },
//     {
//         "name": " Amazon",
//         "link__name": " Amazon",
//         "img__src": "/laptop.jpg",
//         "parent__link": "TABLET",
//         "type": "link",
//         "other": false,
//         "topper": "E-Reader Tablet"
//     },
//     {
//         "name": "Kids Tablet",
//         "link__name": "Kids Tablet",
//         "img__src": "/laptop.jpg",
//         "parent__link": "TABLET",
//         "type": "head",
//         "other": true,
//         "topper": "Kids Tablet"
//     },
//     {
//         "name": "Graphics Tablet",
//         "link__name": "Graphics Tablet",
//         "img__src": "/laptop.jpg",
//         "parent__link": "TABLET",
//         "type": "head",
//         "other": true,
//         "topper": "Graphics Tablet"
//     },
//     {
//         "name": " All Brands",
//         "link__name": " All Brands",
//         "img__src": "/laptop.jpg",
//         "parent__link": "TABLET",
//         "type": "link",
//         "other": false,
//         "topper": "Graphics Tablet"
//     },
//     {
//         "name": " Wacom",
//         "link__name": " Wacom",
//         "img__src": "/laptop.jpg",
//         "parent__link": "TABLET",
//         "type": "link",
//         "other": false,
//         "topper": "Graphics Tablet"
//     },
//     {
//         "name": " XP-PEN",
//         "link__name": " XP-PEN",
//         "img__src": "/laptop.jpg",
//         "parent__link": "TABLET",
//         "type": "link",
//         "other": false,
//         "topper": "Graphics Tablet"
//     },
//     {
//         "name": " Xiaomi",
//         "link__name": " Xiaomi",
//         "img__src": "/laptop.jpg",
//         "parent__link": "TABLET",
//         "type": "link",
//         "other": false,
//         "topper": "Graphics Tablet"
//     },
//     {
//         "name": "Mobile and Tablet Accessories",
//         "link__name": "Mobile and Tablet Accessories",
//         "img__src": "/laptop.jpg",
//         "parent__link": "TABLET",
//         "type": "head",
//         "other": true,
//         "topper": "Mobile and Tablet Accessories"
//     },
//     {
//         "name": " Power Bank",
//         "link__name": " Power Bank",
//         "img__src": "/laptop.jpg",
//         "parent__link": "TABLET",
//         "type": "link",
//         "other": false,
//         "topper": "Mobile and Tablet Accessories"
//     },
//     {
//         "name": " Car Charger",
//         "link__name": " Car Charger",
//         "img__src": "/laptop.jpg",
//         "parent__link": "TABLET",
//         "type": "link",
//         "other": false,
//         "topper": "Mobile and Tablet Accessories"
//     },
//     {
//         "name": " Wireless Charger",
//         "link__name": " Wireless Charger",
//         "img__src": "/laptop.jpg",
//         "parent__link": "TABLET",
//         "type": "link",
//         "other": false,
//         "topper": "Mobile and Tablet Accessories"
//     },
//     {
//         "name": " Wall Charger",
//         "link__name": " Wall Charger",
//         "img__src": "/laptop.jpg",
//         "parent__link": "TABLET",
//         "type": "link",
//         "other": false,
//         "topper": "Mobile and Tablet Accessories"
//     },
//     {
//         "name": " Cable Organizer",
//         "link__name": " Cable Organizer",
//         "img__src": "/laptop.jpg",
//         "parent__link": "TABLET",
//         "type": "link",
//         "other": false,
//         "topper": "Mobile and Tablet Accessories"
//     },
//     {
//         "name": " Phone Holder",
//         "link__name": " Phone Holder",
//         "img__src": "/laptop.jpg",
//         "parent__link": "TABLET",
//         "type": "link",
//         "other": false,
//         "topper": "Mobile and Tablet Accessories"
//     },
//     {
//         "name": " Screen Cleaner",
//         "link__name": " Screen Cleaner",
//         "img__src": "/laptop.jpg",
//         "parent__link": "TABLET",
//         "type": "link",
//         "other": false,
//         "topper": "Mobile and Tablet Accessories"
//     },
//     {
//         "name": "All Laser and INK Printer",
//         "link__name": "All Laser and INK Printer",
//         "img__src": "/laptop.jpg",
//         "parent__link": "PRINTER",
//         "type": "head",
//         "other": true,
//         "topper": "All Laser and INK Printer"
//     },
//     {
//         "name": " Laser Printer",
//         "link__name": " Laser Printer",
//         "img__src": "/laptop.jpg",
//         "parent__link": "PRINTER",
//         "type": "link",
//         "other": false,
//         "topper": "All Laser and INK Printer"
//     },
//     {
//         "name": " Ink Printer",
//         "link__name": " Ink Printer",
//         "img__src": "/laptop.jpg",
//         "parent__link": "PRINTER",
//         "type": "link",
//         "other": false,
//         "topper": "All Laser and INK Printer"
//     },
//     {
//         "name": "Label Printer",
//         "link__name": "Label Printer",
//         "img__src": "/laptop.jpg",
//         "parent__link": "PRINTER",
//         "type": "head",
//         "other": true,
//         "topper": "Label Printer"
//     },
//     {
//         "name": "Card Printer",
//         "link__name": "Card Printer",
//         "img__src": "/laptop.jpg",
//         "parent__link": "PRINTER",
//         "type": "head",
//         "other": true,
//         "topper": "Card Printer"
//     },
//     {
//         "name": "Dot Matrix Printer",
//         "link__name": "Dot Matrix Printer",
//         "img__src": "/laptop.jpg",
//         "parent__link": "PRINTER",
//         "type": "head",
//         "other": true,
//         "topper": "Dot Matrix Printer"
//     },
//     {
//         "name": "POS Printer",
//         "link__name": "POS Printer",
//         "img__src": "/laptop.jpg",
//         "parent__link": "PRINTER",
//         "type": "head",
//         "other": true,
//         "topper": "POS Printer"
//     },
//     {
//         "name": "Large Format Printer",
//         "link__name": "Large Format Printer",
//         "img__src": "/laptop.jpg",
//         "parent__link": "PRINTER",
//         "type": "head",
//         "other": true,
//         "topper": "Large Format Printer"
//     },
//     {
//         "name": "Printer Paper",
//         "link__name": "Printer Paper",
//         "img__src": "/laptop.jpg",
//         "parent__link": "PRINTER",
//         "type": "head",
//         "other": true,
//         "topper": "Printer Paper"
//     },
//     {
//         "name": "Consumable",
//         "link__name": "Consumable",
//         "img__src": "/laptop.jpg",
//         "parent__link": "PRINTER",
//         "type": "head",
//         "other": true,
//         "topper": "Consumable"
//     },
//     {
//         "name": " Toner",
//         "link__name": " Toner",
//         "img__src": "/laptop.jpg",
//         "parent__link": "PRINTER",
//         "type": "link",
//         "other": false,
//         "topper": "Consumable"
//     },
//     {
//         "name": " Cartridge",
//         "link__name": " Cartridge",
//         "img__src": "/laptop.jpg",
//         "parent__link": "PRINTER",
//         "type": "link",
//         "other": false,
//         "topper": "Consumable"
//     },
//     {
//         "name": " Ribbon",
//         "link__name": " Ribbon",
//         "img__src": "/laptop.jpg",
//         "parent__link": "PRINTER",
//         "type": "link",
//         "other": false,
//         "topper": "Consumable"
//     },
//     {
//         "name": " Refill",
//         "link__name": " Refill",
//         "img__src": "/laptop.jpg",
//         "parent__link": "PRINTER",
//         "type": "link",
//         "other": false,
//         "topper": "Consumable"
//     },
//     {
//         "name": " Drum Unit",
//         "link__name": " Drum Unit",
//         "img__src": "/laptop.jpg",
//         "parent__link": "PRINTER",
//         "type": "link",
//         "other": false,
//         "topper": "Consumable"
//     },
//     {
//         "name": " Print Head",
//         "link__name": " Print Head",
//         "img__src": "/laptop.jpg",
//         "parent__link": "PRINTER",
//         "type": "link",
//         "other": false,
//         "topper": "Consumable"
//     },
//     {
//         "name": " Accessories",
//         "link__name": " Accessories",
//         "img__src": "/laptop.jpg",
//         "parent__link": "PRINTER",
//         "type": "link",
//         "other": false,
//         "topper": "Consumable"
//     },
//     {
//         "name": "Flatbed Scanner",
//         "link__name": "Flatbed Scanner",
//         "img__src": "/laptop.jpg",
//         "parent__link": "SCANNER",
//         "type": "head",
//         "other": true,
//         "topper": "Flatbed Scanner"
//     },
//     {
//         "name": " Canon",
//         "link__name": " Canon",
//         "img__src": "/laptop.jpg",
//         "parent__link": "SCANNER",
//         "type": "link",
//         "other": false,
//         "topper": "Flatbed Scanner"
//     },
//     {
//         "name": " Epson",
//         "link__name": " Epson",
//         "img__src": "/laptop.jpg",
//         "parent__link": "SCANNER",
//         "type": "link",
//         "other": false,
//         "topper": "Flatbed Scanner"
//     },
//     {
//         "name": " HP",
//         "link__name": " HP",
//         "img__src": "/laptop.jpg",
//         "parent__link": "SCANNER",
//         "type": "link",
//         "other": false,
//         "topper": "Flatbed Scanner"
//     },
//     {
//         "name": " Plustek",
//         "link__name": " Plustek",
//         "img__src": "/laptop.jpg",
//         "parent__link": "SCANNER",
//         "type": "link",
//         "other": false,
//         "topper": "Flatbed Scanner"
//     },
//     {
//         "name": " Avision",
//         "link__name": " Avision",
//         "img__src": "/laptop.jpg",
//         "parent__link": "SCANNER",
//         "type": "link",
//         "other": false,
//         "topper": "Flatbed Scanner"
//     },
//     {
//         "name": "Sheetfed and Flatbed Scanner",
//         "link__name": "Sheetfed and Flatbed Scanner",
//         "img__src": "/laptop.jpg",
//         "parent__link": "SCANNER",
//         "type": "head",
//         "other": true,
//         "topper": "Sheetfed and Flatbed Scanner"
//     },
//     {
//         "name": " Canon",
//         "link__name": " Canon",
//         "img__src": "/laptop.jpg",
//         "parent__link": "SCANNER",
//         "type": "link",
//         "other": false,
//         "topper": "Sheetfed and Flatbed Scanner"
//     },
//     {
//         "name": " Epson",
//         "link__name": " Epson",
//         "img__src": "/laptop.jpg",
//         "parent__link": "SCANNER",
//         "type": "link",
//         "other": false,
//         "topper": "Sheetfed and Flatbed Scanner"
//     },
//     {
//         "name": " HP",
//         "link__name": " HP",
//         "img__src": "/laptop.jpg",
//         "parent__link": "SCANNER",
//         "type": "link",
//         "other": false,
//         "topper": "Sheetfed and Flatbed Scanner"
//     },
//     {
//         "name": " Plustek",
//         "link__name": " Plustek",
//         "img__src": "/laptop.jpg",
//         "parent__link": "SCANNER",
//         "type": "link",
//         "other": false,
//         "topper": "Sheetfed and Flatbed Scanner"
//     },
//     {
//         "name": " Brother",
//         "link__name": " Brother",
//         "img__src": "/laptop.jpg",
//         "parent__link": "SCANNER",
//         "type": "link",
//         "other": false,
//         "topper": "Sheetfed and Flatbed Scanner"
//     },
//     {
//         "name": "Barcode Scanner",
//         "link__name": "Barcode Scanner",
//         "img__src": "/laptop.jpg",
//         "parent__link": "SCANNER",
//         "type": "head",
//         "other": true,
//         "topper": "Barcode Scanner"
//     },
//     {
//         "name": " Zebex",
//         "link__name": " Zebex",
//         "img__src": "/laptop.jpg",
//         "parent__link": "SCANNER",
//         "type": "link",
//         "other": false,
//         "topper": "Barcode Scanner"
//     },
//     {
//         "name": " Sewoo",
//         "link__name": " Sewoo",
//         "img__src": "/laptop.jpg",
//         "parent__link": "SCANNER",
//         "type": "link",
//         "other": false,
//         "topper": "Barcode Scanner"
//     },
//     {
//         "name": " Honeywell",
//         "link__name": " Honeywell",
//         "img__src": "/laptop.jpg",
//         "parent__link": "SCANNER",
//         "type": "link",
//         "other": false,
//         "topper": "Barcode Scanner"
//     },
//     {
//         "name": " Rongta",
//         "link__name": " Rongta",
//         "img__src": "/laptop.jpg",
//         "parent__link": "SCANNER",
//         "type": "link",
//         "other": false,
//         "topper": "Barcode Scanner"
//     },
//     {
//         "name": " Zebra",
//         "link__name": " Zebra",
//         "img__src": "/laptop.jpg",
//         "parent__link": "SCANNER",
//         "type": "link",
//         "other": false,
//         "topper": "Barcode Scanner"
//     },
//     {
//         "name": "Document and Book Scanner",
//         "link__name": "Document and Book Scanner",
//         "img__src": "/laptop.jpg",
//         "parent__link": "SCANNER",
//         "type": "head",
//         "other": true,
//         "topper": "Document and Book Scanner"
//     },
//     {
//         "name": " CZUR",
//         "link__name": " CZUR",
//         "img__src": "/laptop.jpg",
//         "parent__link": "SCANNER",
//         "type": "link",
//         "other": false,
//         "topper": "Document and Book Scanner"
//     },
//     {
//         "name": "Portable Scanner",
//         "link__name": "Portable Scanner",
//         "img__src": "/laptop.jpg",
//         "parent__link": "SCANNER",
//         "type": "head",
//         "other": true,
//         "topper": "Portable Scanner"
//     },
//     {
//         "name": " Plustek",
//         "link__name": " Plustek",
//         "img__src": "/laptop.jpg",
//         "parent__link": "SCANNER",
//         "type": "link",
//         "other": false,
//         "topper": "Portable Scanner"
//     },
//     {
//         "name": "Cheque Scanner",
//         "link__name": "Cheque Scanner",
//         "img__src": "/laptop.jpg",
//         "parent__link": "SCANNER",
//         "type": "head",
//         "other": true,
//         "topper": "Cheque Scanner"
//     },
//     {
//         "name": " Canon",
//         "link__name": " Canon",
//         "img__src": "/laptop.jpg",
//         "parent__link": "SCANNER",
//         "type": "link",
//         "other": false,
//         "topper": "Cheque Scanner"
//     },
//     {
//         "name": "All Photocopier",
//         "link__name": "All Photocopier",
//         "img__src": "/laptop.jpg",
//         "parent__link": "PHOTOCOPIER",
//         "type": "head",
//         "other": true,
//         "topper": "All Photocopier"
//     },
//     {
//         "name": " Canon",
//         "link__name": " Canon",
//         "img__src": "/laptop.jpg",
//         "parent__link": "PHOTOCOPIER",
//         "type": "link",
//         "other": false,
//         "topper": "All Photocopier"
//     },
//     {
//         "name": " HP",
//         "link__name": " HP",
//         "img__src": "/laptop.jpg",
//         "parent__link": "PHOTOCOPIER",
//         "type": "link",
//         "other": false,
//         "topper": "All Photocopier"
//     },
//     {
//         "name": " Ricoh",
//         "link__name": " Ricoh",
//         "img__src": "/laptop.jpg",
//         "parent__link": "PHOTOCOPIER",
//         "type": "link",
//         "other": false,
//         "topper": "All Photocopier"
//     },
//     {
//         "name": " Sharp",
//         "link__name": " Sharp",
//         "img__src": "/laptop.jpg",
//         "parent__link": "PHOTOCOPIER",
//         "type": "link",
//         "other": false,
//         "topper": "All Photocopier"
//     },
//     {
//         "name": " Toshiba",
//         "link__name": " Toshiba",
//         "img__src": "/laptop.jpg",
//         "parent__link": "PHOTOCOPIER",
//         "type": "link",
//         "other": false,
//         "topper": "All Photocopier"
//     },
//     {
//         "name": "Photocopier Accessories",
//         "link__name": "Photocopier Accessories",
//         "img__src": "/laptop.jpg",
//         "parent__link": "PHOTOCOPIER",
//         "type": "head",
//         "other": true,
//         "topper": "Photocopier Accessories"
//     },
//     {
//         "name": "All Projector",
//         "link__name": "All Projector",
//         "img__src": "/laptop.jpg",
//         "parent__link": "PROJECTOR",
//         "type": "head",
//         "other": true,
//         "topper": "All Projector"
//     },
//     {
//         "name": " Maxell",
//         "link__name": " Maxell",
//         "img__src": "/laptop.jpg",
//         "parent__link": "PROJECTOR",
//         "type": "link",
//         "other": false,
//         "topper": "All Projector"
//     },
//     {
//         "name": " Benq",
//         "link__name": " Benq",
//         "img__src": "/laptop.jpg",
//         "parent__link": "PROJECTOR",
//         "type": "link",
//         "other": false,
//         "topper": "All Projector"
//     },
//     {
//         "name": " Optoma",
//         "link__name": " Optoma",
//         "img__src": "/laptop.jpg",
//         "parent__link": "PROJECTOR",
//         "type": "link",
//         "other": false,
//         "topper": "All Projector"
//     },
//     {
//         "name": " ViewSonic",
//         "link__name": " ViewSonic",
//         "img__src": "/laptop.jpg",
//         "parent__link": "PROJECTOR",
//         "type": "link",
//         "other": false,
//         "topper": "All Projector"
//     },
//     {
//         "name": " Micropack",
//         "link__name": " Micropack",
//         "img__src": "/laptop.jpg",
//         "parent__link": "PROJECTOR",
//         "type": "link",
//         "other": false,
//         "topper": "All Projector"
//     },
//     {
//         "name": " Asus",
//         "link__name": " Asus",
//         "img__src": "/laptop.jpg",
//         "parent__link": "PROJECTOR",
//         "type": "link",
//         "other": false,
//         "topper": "All Projector"
//     },
//     {
//         "name": " Epson",
//         "link__name": " Epson",
//         "img__src": "/laptop.jpg",
//         "parent__link": "PROJECTOR",
//         "type": "link",
//         "other": false,
//         "topper": "All Projector"
//     },
//     {
//         "name": " Vivitek",
//         "link__name": " Vivitek",
//         "img__src": "/laptop.jpg",
//         "parent__link": "PROJECTOR",
//         "type": "link",
//         "other": false,
//         "topper": "All Projector"
//     },
//     {
//         "name": " Casio",
//         "link__name": " Casio",
//         "img__src": "/laptop.jpg",
//         "parent__link": "PROJECTOR",
//         "type": "link",
//         "other": false,
//         "topper": "All Projector"
//     },
//     {
//         "name": "Projector Screen",
//         "link__name": "Projector Screen",
//         "img__src": "/laptop.jpg",
//         "parent__link": "PROJECTOR",
//         "type": "head",
//         "other": true,
//         "topper": "Projector Screen"
//     },
//     {
//         "name": "Digital Display",
//         "link__name": "Digital Display",
//         "img__src": "/laptop.jpg",
//         "parent__link": "PROJECTOR",
//         "type": "head",
//         "other": true,
//         "topper": "Digital Display"
//     },
//     {
//         "name": " Interactive Panel",
//         "link__name": " Interactive Panel",
//         "img__src": "/laptop.jpg",
//         "parent__link": "PROJECTOR",
//         "type": "link",
//         "other": false,
//         "topper": "Digital Display"
//     },
//     {
//         "name": " Digital Signage",
//         "link__name": " Digital Signage",
//         "img__src": "/laptop.jpg",
//         "parent__link": "PROJECTOR",
//         "type": "link",
//         "other": false,
//         "topper": "Digital Display"
//     },
//     {
//         "name": "Presenter",
//         "link__name": "Presenter",
//         "img__src": "/laptop.jpg",
//         "parent__link": "PROJECTOR",
//         "type": "head",
//         "other": true,
//         "topper": "Presenter"
//     },
//     {
//         "name": "Ceiling Mount kit",
//         "link__name": "Ceiling Mount kit",
//         "img__src": "/laptop.jpg",
//         "parent__link": "PROJECTOR",
//         "type": "head",
//         "other": true,
//         "topper": "Ceiling Mount kit"
//     },
//     {
//         "name": "Projector  Accessories",
//         "link__name": "Projector  Accessories",
//         "img__src": "/laptop.jpg",
//         "parent__link": "PROJECTOR",
//         "type": "head",
//         "other": true,
//         "topper": "Projector  Accessories"
//     },
//     {
//         "name": "Digital SLR Camera",
//         "link__name": "Digital SLR Camera",
//         "img__src": "/laptop.jpg",
//         "parent__link": "CAMERA",
//         "type": "head",
//         "other": true,
//         "topper": "Digital SLR Camera"
//     },
//     {
//         "name": " DSLR Camera",
//         "link__name": " DSLR Camera",
//         "img__src": "/laptop.jpg",
//         "parent__link": "CAMERA",
//         "type": "link",
//         "other": false,
//         "topper": "Digital SLR Camera"
//     },
//     {
//         "name": " Mirrorless Camera",
//         "link__name": " Mirrorless Camera",
//         "img__src": "/laptop.jpg",
//         "parent__link": "CAMERA",
//         "type": "link",
//         "other": false,
//         "topper": "Digital SLR Camera"
//     },
//     {
//         "name": " DSLR Camera Lens",
//         "link__name": " DSLR Camera Lens",
//         "img__src": "/laptop.jpg",
//         "parent__link": "CAMERA",
//         "type": "link",
//         "other": false,
//         "topper": "Digital SLR Camera"
//     },
//     {
//         "name": " DSLR Camera Accessories",
//         "link__name": " DSLR Camera Accessories",
//         "img__src": "/laptop.jpg",
//         "parent__link": "CAMERA",
//         "type": "link",
//         "other": false,
//         "topper": "Digital SLR Camera"
//     },
//     {
//         "name": "Digital Compact Camera",
//         "link__name": "Digital Compact Camera",
//         "img__src": "/laptop.jpg",
//         "parent__link": "CAMERA",
//         "type": "head",
//         "other": true,
//         "topper": "Digital Compact Camera"
//     },
//     {
//         "name": " Compact Camera",
//         "link__name": " Compact Camera",
//         "img__src": "/laptop.jpg",
//         "parent__link": "CAMERA",
//         "type": "link",
//         "other": false,
//         "topper": "Digital Compact Camera"
//     },
//     {
//         "name": " Handy Camera",
//         "link__name": " Handy Camera",
//         "img__src": "/laptop.jpg",
//         "parent__link": "CAMERA",
//         "type": "link",
//         "other": false,
//         "topper": "Digital Compact Camera"
//     },
//     {
//         "name": " Action Camera",
//         "link__name": " Action Camera",
//         "img__src": "/laptop.jpg",
//         "parent__link": "CAMERA",
//         "type": "link",
//         "other": false,
//         "topper": "Digital Compact Camera"
//     },
//     {
//         "name": " Compact Camera Accessories",
//         "link__name": " Compact Camera Accessories",
//         "img__src": "/laptop.jpg",
//         "parent__link": "CAMERA",
//         "type": "link",
//         "other": false,
//         "topper": "Digital Compact Camera"
//     },
//     {
//         "name": "Video Camera",
//         "link__name": "Video Camera",
//         "img__src": "/laptop.jpg",
//         "parent__link": "CAMERA",
//         "type": "head",
//         "other": true,
//         "topper": "Video Camera"
//     },
//     {
//         "name": "Webcam",
//         "link__name": "Webcam",
//         "img__src": "/laptop.jpg",
//         "parent__link": "CAMERA",
//         "type": "head",
//         "other": true,
//         "topper": "Webcam"
//     },
//     {
//         "name": "Drone",
//         "link__name": "Drone",
//         "img__src": "/laptop.jpg",
//         "parent__link": "CAMERA",
//         "type": "head",
//         "other": true,
//         "topper": "Drone"
//     },
//     {
//         "name": "CC Camera",
//         "link__name": "CC Camera",
//         "img__src": "/laptop.jpg",
//         "parent__link": "SECURITY SYSTEM",
//         "type": "head",
//         "other": true,
//         "topper": "CC Camera"
//     },
//     {
//         "name": "IP Camera",
//         "link__name": "IP Camera",
//         "img__src": "/laptop.jpg",
//         "parent__link": "SECURITY SYSTEM",
//         "type": "head",
//         "other": true,
//         "topper": "IP Camera"
//     },
//     {
//         "name": "Wireless Camera",
//         "link__name": "Wireless Camera",
//         "img__src": "/laptop.jpg",
//         "parent__link": "SECURITY SYSTEM",
//         "type": "head",
//         "other": true,
//         "topper": "Wireless Camera"
//     },
//     {
//         "name": "DVR",
//         "link__name": "DVR",
//         "img__src": "/laptop.jpg",
//         "parent__link": "SECURITY SYSTEM",
//         "type": "head",
//         "other": true,
//         "topper": "DVR"
//     },
//     {
//         "name": "NVR",
//         "link__name": "NVR",
//         "img__src": "/laptop.jpg",
//         "parent__link": "SECURITY SYSTEM",
//         "type": "head",
//         "other": true,
//         "topper": "NVR"
//     },
//     {
//         "name": "XVR",
//         "link__name": "XVR",
//         "img__src": "/laptop.jpg",
//         "parent__link": "SECURITY SYSTEM",
//         "type": "head",
//         "other": true,
//         "topper": "XVR"
//     },
//     {
//         "name": "CC/IP Camera Accessories",
//         "link__name": "CC/IP Camera Accessories",
//         "img__src": "/laptop.jpg",
//         "parent__link": "SECURITY SYSTEM",
//         "type": "head",
//         "other": true,
//         "topper": "CC/IP Camera Accessories"
//     },
//     {
//         "name": "Smart Lock, Door Bell and Video Door Phone",
//         "link__name": "Smart Lock, Door Bell and Video Door Phone",
//         "img__src": "/laptop.jpg",
//         "parent__link": "SECURITY SYSTEM",
//         "type": "head",
//         "other": true,
//         "topper": "Smart Lock, Door Bell and Video Door Phone"
//     },
//     {
//         "name": "Time Attendance System",
//         "link__name": "Time Attendance System",
//         "img__src": "/laptop.jpg",
//         "parent__link": "SECURITY SYSTEM",
//         "type": "head",
//         "other": true,
//         "topper": "Time Attendance System"
//     },
//     {
//         "name": " Access Control",
//         "link__name": " Access Control",
//         "img__src": "/laptop.jpg",
//         "parent__link": "SECURITY SYSTEM",
//         "type": "link",
//         "other": false,
//         "topper": "Time Attendance System"
//     },
//     {
//         "name": " Access Control Accessories",
//         "link__name": " Access Control Accessories",
//         "img__src": "/laptop.jpg",
//         "parent__link": "SECURITY SYSTEM",
//         "type": "link",
//         "other": false,
//         "topper": "Time Attendance System"
//     },
//     {
//         "name": "Network Router",
//         "link__name": "Network Router",
//         "img__src": "/laptop.jpg",
//         "parent__link": "NETWORK",
//         "type": "head",
//         "other": true,
//         "topper": "Network Router"
//     },
//     {
//         "name": "Access Point",
//         "link__name": "Access Point",
//         "img__src": "/laptop.jpg",
//         "parent__link": "NETWORK",
//         "type": "head",
//         "other": true,
//         "topper": "Access Point"
//     },
//     {
//         "name": "Range Extender",
//         "link__name": "Range Extender",
//         "img__src": "/laptop.jpg",
//         "parent__link": "NETWORK",
//         "type": "head",
//         "other": true,
//         "topper": "Range Extender"
//     },
//     {
//         "name": "Network Switch",
//         "link__name": "Network Switch",
//         "img__src": "/laptop.jpg",
//         "parent__link": "NETWORK",
//         "type": "head",
//         "other": true,
//         "topper": "Network Switch"
//     },
//     {
//         "name": "Lan Card",
//         "link__name": "Lan Card",
//         "img__src": "/laptop.jpg",
//         "parent__link": "NETWORK",
//         "type": "head",
//         "other": true,
//         "topper": "Lan Card"
//     },
//     {
//         "name": "Network Cable",
//         "link__name": "Network Cable",
//         "img__src": "/laptop.jpg",
//         "parent__link": "NETWORK",
//         "type": "head",
//         "other": true,
//         "topper": "Network Cable"
//     },
//     {
//         "name": "Optical Line Termination (OLT)",
//         "link__name": "Optical Line Termination (OLT)",
//         "img__src": "/laptop.jpg",
//         "parent__link": "NETWORK",
//         "type": "head",
//         "other": true,
//         "topper": "Optical Line Termination (OLT)"
//     },
//     {
//         "name": "Optical Network Unit (ONU)",
//         "link__name": "Optical Network Unit (ONU)",
//         "img__src": "/laptop.jpg",
//         "parent__link": "NETWORK",
//         "type": "head",
//         "other": true,
//         "topper": "Optical Network Unit (ONU)"
//     },
//     {
//         "name": "Network Storage",
//         "link__name": "Network Storage",
//         "img__src": "/laptop.jpg",
//         "parent__link": "NETWORK",
//         "type": "head",
//         "other": true,
//         "topper": "Network Storage"
//     },
//     {
//         "name": "Edge Modem",
//         "link__name": "Edge Modem",
//         "img__src": "/laptop.jpg",
//         "parent__link": "NETWORK",
//         "type": "head",
//         "other": true,
//         "topper": "Edge Modem"
//     },
//     {
//         "name": "Network Accessories",
//         "link__name": "Network Accessories",
//         "img__src": "/laptop.jpg",
//         "parent__link": "NETWORK",
//         "type": "head",
//         "other": true,
//         "topper": "Network Accessories"
//     },
//     {
//         "name": " Connector",
//         "link__name": " Connector",
//         "img__src": "/laptop.jpg",
//         "parent__link": "NETWORK",
//         "type": "link",
//         "other": false,
//         "topper": "Network Accessories"
//     },
//     {
//         "name": " Face Plate",
//         "link__name": " Face Plate",
//         "img__src": "/laptop.jpg",
//         "parent__link": "NETWORK",
//         "type": "link",
//         "other": false,
//         "topper": "Network Accessories"
//     },
//     {
//         "name": " Cable Lan",
//         "link__name": " Cable Lan",
//         "img__src": "/laptop.jpg",
//         "parent__link": "NETWORK",
//         "type": "link",
//         "other": false,
//         "topper": "Network Accessories"
//     },
//     {
//         "name": " Crimping Tool",
//         "link__name": " Crimping Tool",
//         "img__src": "/laptop.jpg",
//         "parent__link": "NETWORK",
//         "type": "link",
//         "other": false,
//         "topper": "Network Accessories"
//     },
//     {
//         "name": " Patch Cord",
//         "link__name": " Patch Cord",
//         "img__src": "/laptop.jpg",
//         "parent__link": "NETWORK",
//         "type": "link",
//         "other": false,
//         "topper": "Network Accessories"
//     },
//     {
//         "name": " Management Cable",
//         "link__name": " Management Cable",
//         "img__src": "/laptop.jpg",
//         "parent__link": "NETWORK",
//         "type": "link",
//         "other": false,
//         "topper": "Network Accessories"
//     },
//     {
//         "name": " Patch Panel",
//         "link__name": " Patch Panel",
//         "img__src": "/laptop.jpg",
//         "parent__link": "NETWORK",
//         "type": "link",
//         "other": false,
//         "topper": "Network Accessories"
//     },
//     {
//         "name": " Modular",
//         "link__name": " Modular",
//         "img__src": "/laptop.jpg",
//         "parent__link": "NETWORK",
//         "type": "link",
//         "other": false,
//         "topper": "Network Accessories"
//     },
//     {
//         "name": "Speaker",
//         "link__name": "Speaker",
//         "img__src": "/laptop.jpg",
//         "parent__link": "SOUND SYSTEM",
//         "type": "head",
//         "other": true,
//         "topper": "Speaker"
//     },
//     {
//         "name": " All Brand",
//         "link__name": " All Brand",
//         "img__src": "/laptop.jpg",
//         "parent__link": "SOUND SYSTEM",
//         "type": "link",
//         "other": false,
//         "topper": "Speaker"
//     },
//     {
//         "name": " F&D",
//         "link__name": " F&D",
//         "img__src": "/laptop.jpg",
//         "parent__link": "SOUND SYSTEM",
//         "type": "link",
//         "other": false,
//         "topper": "Speaker"
//     },
//     {
//         "name": " Xtreme",
//         "link__name": " Xtreme",
//         "img__src": "/laptop.jpg",
//         "parent__link": "SOUND SYSTEM",
//         "type": "link",
//         "other": false,
//         "topper": "Speaker"
//     },
//     {
//         "name": " Edifier",
//         "link__name": " Edifier",
//         "img__src": "/laptop.jpg",
//         "parent__link": "SOUND SYSTEM",
//         "type": "link",
//         "other": false,
//         "topper": "Speaker"
//     },
//     {
//         "name": " Havit",
//         "link__name": " Havit",
//         "img__src": "/laptop.jpg",
//         "parent__link": "SOUND SYSTEM",
//         "type": "link",
//         "other": false,
//         "topper": "Speaker"
//     },
//     {
//         "name": " Digital X",
//         "link__name": " Digital X",
//         "img__src": "/laptop.jpg",
//         "parent__link": "SOUND SYSTEM",
//         "type": "link",
//         "other": false,
//         "topper": "Speaker"
//     },
//     {
//         "name": " Golden Field",
//         "link__name": " Golden Field",
//         "img__src": "/laptop.jpg",
//         "parent__link": "SOUND SYSTEM",
//         "type": "link",
//         "other": false,
//         "topper": "Speaker"
//     },
//     {
//         "name": " Microlab",
//         "link__name": " Microlab",
//         "img__src": "/laptop.jpg",
//         "parent__link": "SOUND SYSTEM",
//         "type": "link",
//         "other": false,
//         "topper": "Speaker"
//     },
//     {
//         "name": " JBL",
//         "link__name": " JBL",
//         "img__src": "/laptop.jpg",
//         "parent__link": "SOUND SYSTEM",
//         "type": "link",
//         "other": false,
//         "topper": "Speaker"
//     },
//     {
//         "name": " Jabra",
//         "link__name": " Jabra",
//         "img__src": "/laptop.jpg",
//         "parent__link": "SOUND SYSTEM",
//         "type": "link",
//         "other": false,
//         "topper": "Speaker"
//     },
//     {
//         "name": " Altec Lansing",
//         "link__name": " Altec Lansing",
//         "img__src": "/laptop.jpg",
//         "parent__link": "SOUND SYSTEM",
//         "type": "link",
//         "other": false,
//         "topper": "Speaker"
//     },
//     {
//         "name": " Fantech",
//         "link__name": " Fantech",
//         "img__src": "/laptop.jpg",
//         "parent__link": "SOUND SYSTEM",
//         "type": "link",
//         "other": false,
//         "topper": "Speaker"
//     },
//     {
//         "name": " Grandstream",
//         "link__name": " Grandstream",
//         "img__src": "/laptop.jpg",
//         "parent__link": "SOUND SYSTEM",
//         "type": "link",
//         "other": false,
//         "topper": "Speaker"
//     },
//     {
//         "name": " Rapoo",
//         "link__name": " Rapoo",
//         "img__src": "/laptop.jpg",
//         "parent__link": "SOUND SYSTEM",
//         "type": "link",
//         "other": false,
//         "topper": "Speaker"
//     },
//     {
//         "name": " Creative",
//         "link__name": " Creative",
//         "img__src": "/laptop.jpg",
//         "parent__link": "SOUND SYSTEM",
//         "type": "link",
//         "other": false,
//         "topper": "Speaker"
//     },
//     {
//         "name": " Bose",
//         "link__name": " Bose",
//         "img__src": "/laptop.jpg",
//         "parent__link": "SOUND SYSTEM",
//         "type": "link",
//         "other": false,
//         "topper": "Speaker"
//     },
//     {
//         "name": " Silicon Power",
//         "link__name": " Silicon Power",
//         "img__src": "/laptop.jpg",
//         "parent__link": "SOUND SYSTEM",
//         "type": "link",
//         "other": false,
//         "topper": "Speaker"
//     },
//     {
//         "name": " Logitech",
//         "link__name": " Logitech",
//         "img__src": "/laptop.jpg",
//         "parent__link": "SOUND SYSTEM",
//         "type": "link",
//         "other": false,
//         "topper": "Speaker"
//     },
//     {
//         "name": " Polycom",
//         "link__name": " Polycom",
//         "img__src": "/laptop.jpg",
//         "parent__link": "SOUND SYSTEM",
//         "type": "link",
//         "other": false,
//         "topper": "Speaker"
//     },
//     {
//         "name": " Micropack",
//         "link__name": " Micropack",
//         "img__src": "/laptop.jpg",
//         "parent__link": "SOUND SYSTEM",
//         "type": "link",
//         "other": false,
//         "topper": "Speaker"
//     },
//     {
//         "name": " Google",
//         "link__name": " Google",
//         "img__src": "/laptop.jpg",
//         "parent__link": "SOUND SYSTEM",
//         "type": "link",
//         "other": false,
//         "topper": "Speaker"
//     },
//     {
//         "name": " Amazon",
//         "link__name": " Amazon",
//         "img__src": "/laptop.jpg",
//         "parent__link": "SOUND SYSTEM",
//         "type": "link",
//         "other": false,
//         "topper": "Speaker"
//     },
//     {
//         "name": " Redragon",
//         "link__name": " Redragon",
//         "img__src": "/laptop.jpg",
//         "parent__link": "SOUND SYSTEM",
//         "type": "link",
//         "other": false,
//         "topper": "Speaker"
//     },
//     {
//         "name": " Marvo",
//         "link__name": " Marvo",
//         "img__src": "/laptop.jpg",
//         "parent__link": "SOUND SYSTEM",
//         "type": "link",
//         "other": false,
//         "topper": "Speaker"
//     },
//     {
//         "name": "Home Theater Systems",
//         "link__name": "Home Theater Systems",
//         "img__src": "/laptop.jpg",
//         "parent__link": "SOUND SYSTEM",
//         "type": "head",
//         "other": true,
//         "topper": "Home Theater Systems"
//     },
//     {
//         "name": "PA System",
//         "link__name": "PA System",
//         "img__src": "/laptop.jpg",
//         "parent__link": "SOUND SYSTEM",
//         "type": "head",
//         "other": true,
//         "topper": "PA System"
//     },
//     {
//         "name": "Headphone",
//         "link__name": "Headphone",
//         "img__src": "/laptop.jpg",
//         "parent__link": "SOUND SYSTEM",
//         "type": "head",
//         "other": true,
//         "topper": "Headphone"
//     },
//     {
//         "name": "Ear Phone",
//         "link__name": "Ear Phone",
//         "img__src": "/laptop.jpg",
//         "parent__link": "SOUND SYSTEM",
//         "type": "head",
//         "other": true,
//         "topper": "Ear Phone"
//     },
//     {
//         "name": "Microphone",
//         "link__name": "Microphone",
//         "img__src": "/laptop.jpg",
//         "parent__link": "SOUND SYSTEM",
//         "type": "head",
//         "other": true,
//         "topper": "Microphone"
//     },
//     {
//         "name": "Sound Card",
//         "link__name": "Sound Card",
//         "img__src": "/laptop.jpg",
//         "parent__link": "SOUND SYSTEM",
//         "type": "head",
//         "other": true,
//         "topper": "Sound Card"
//     },
//     {
//         "name": "Voice Recorder",
//         "link__name": "Voice Recorder",
//         "img__src": "/laptop.jpg",
//         "parent__link": "SOUND SYSTEM",
//         "type": "head",
//         "other": true,
//         "topper": "Voice Recorder"
//     },
//     {
//         "name": "Radio",
//         "link__name": "Radio",
//         "img__src": "/laptop.jpg",
//         "parent__link": "SOUND SYSTEM",
//         "type": "head",
//         "other": true,
//         "topper": "Radio"
//     },
//     {
//         "name": "Musical Instrument",
//         "link__name": "Musical Instrument",
//         "img__src": "/laptop.jpg",
//         "parent__link": "SOUND SYSTEM",
//         "type": "head",
//         "other": true,
//         "topper": "Musical Instrument"
//     },
//     {
//         "name": "Money Counting Machine",
//         "link__name": "Money Counting Machine",
//         "img__src": "/laptop.jpg",
//         "parent__link": "OFFICE ITEMS",
//         "type": "head",
//         "other": true,
//         "topper": "Money Counting Machine"
//     },
//     {
//         "name": "Cash Register Machine",
//         "link__name": "Cash Register Machine",
//         "img__src": "/laptop.jpg",
//         "parent__link": "OFFICE ITEMS",
//         "type": "head",
//         "other": true,
//         "topper": "Cash Register Machine"
//     },
//     {
//         "name": "Paper Shredder",
//         "link__name": "Paper Shredder",
//         "img__src": "/laptop.jpg",
//         "parent__link": "OFFICE ITEMS",
//         "type": "head",
//         "other": true,
//         "topper": "Paper Shredder"
//     },
//     {
//         "name": "Telephone Set",
//         "link__name": "Telephone Set",
//         "img__src": "/laptop.jpg",
//         "parent__link": "OFFICE ITEMS",
//         "type": "head",
//         "other": true,
//         "topper": "Telephone Set"
//     },
//     {
//         "name": " Land Phone Set",
//         "link__name": " Land Phone Set",
//         "img__src": "/laptop.jpg",
//         "parent__link": "OFFICE ITEMS",
//         "type": "link",
//         "other": false,
//         "topper": "Telephone Set"
//     },
//     {
//         "name": " IP Phone Set",
//         "link__name": " IP Phone Set",
//         "img__src": "/laptop.jpg",
//         "parent__link": "OFFICE ITEMS",
//         "type": "link",
//         "other": false,
//         "topper": "Telephone Set"
//     },
//     {
//         "name": "Fax Machine",
//         "link__name": "Fax Machine",
//         "img__src": "/laptop.jpg",
//         "parent__link": "OFFICE ITEMS",
//         "type": "head",
//         "other": true,
//         "topper": "Fax Machine"
//     },
//     {
//         "name": "Calculator",
//         "link__name": "Calculator",
//         "img__src": "/laptop.jpg",
//         "parent__link": "OFFICE ITEMS",
//         "type": "head",
//         "other": true,
//         "topper": "Calculator"
//     },
//     {
//         "name": "Internal HDD",
//         "link__name": "Internal HDD",
//         "img__src": "/laptop.jpg",
//         "parent__link": "STORAGE",
//         "type": "head",
//         "other": true,
//         "topper": "Internal HDD"
//     },
//     {
//         "name": "Internal SSD",
//         "link__name": "Internal SSD",
//         "img__src": "/laptop.jpg",
//         "parent__link": "STORAGE",
//         "type": "head",
//         "other": true,
//         "topper": "Internal SSD"
//     },
//     {
//         "name": "Internal Server HDD",
//         "link__name": "Internal Server HDD",
//         "img__src": "/laptop.jpg",
//         "parent__link": "STORAGE",
//         "type": "head",
//         "other": true,
//         "topper": "Internal Server HDD"
//     },
//     {
//         "name": "External HDD",
//         "link__name": "External HDD",
//         "img__src": "/laptop.jpg",
//         "parent__link": "STORAGE",
//         "type": "head",
//         "other": true,
//         "topper": "External HDD"
//     },
//     {
//         "name": "External SSD",
//         "link__name": "External SSD",
//         "img__src": "/laptop.jpg",
//         "parent__link": "STORAGE",
//         "type": "head",
//         "other": true,
//         "topper": "External SSD"
//     },
//     {
//         "name": "Pen Drive",
//         "link__name": "Pen Drive",
//         "img__src": "/laptop.jpg",
//         "parent__link": "STORAGE",
//         "type": "head",
//         "other": true,
//         "topper": "Pen Drive"
//     },
//     {
//         "name": "Memory Card",
//         "link__name": "Memory Card",
//         "img__src": "/laptop.jpg",
//         "parent__link": "STORAGE",
//         "type": "head",
//         "other": true,
//         "topper": "Memory Card"
//     },
//     {
//         "name": "HDD Case",
//         "link__name": "HDD Case",
//         "img__src": "/laptop.jpg",
//         "parent__link": "STORAGE",
//         "type": "head",
//         "other": true,
//         "topper": "HDD Case"
//     },
//     {
//         "name": "Card Reader",
//         "link__name": "Card Reader",
//         "img__src": "/laptop.jpg",
//         "parent__link": "STORAGE",
//         "type": "head",
//         "other": true,
//         "topper": "Card Reader"
//     },
//     {
//         "name": "Cable",
//         "link__name": "Cable",
//         "img__src": "/laptop.jpg",
//         "parent__link": "ACCESSORIES",
//         "type": "head",
//         "other": true,
//         "topper": "Cable"
//     },
//     {
//         "name": " HDMI Cable",
//         "link__name": " HDMI Cable",
//         "img__src": "/laptop.jpg",
//         "parent__link": "ACCESSORIES",
//         "type": "link",
//         "other": false,
//         "topper": "Cable"
//     },
//     {
//         "name": " VGA Cable",
//         "link__name": " VGA Cable",
//         "img__src": "/laptop.jpg",
//         "parent__link": "ACCESSORIES",
//         "type": "link",
//         "other": false,
//         "topper": "Cable"
//     },
//     {
//         "name": " Lightning Cable",
//         "link__name": " Lightning Cable",
//         "img__src": "/laptop.jpg",
//         "parent__link": "ACCESSORIES",
//         "type": "link",
//         "other": false,
//         "topper": "Cable"
//     },
//     {
//         "name": " USB Cable",
//         "link__name": " USB Cable",
//         "img__src": "/laptop.jpg",
//         "parent__link": "ACCESSORIES",
//         "type": "link",
//         "other": false,
//         "topper": "Cable"
//     },
//     {
//         "name": " Audio Cable",
//         "link__name": " Audio Cable",
//         "img__src": "/laptop.jpg",
//         "parent__link": "ACCESSORIES",
//         "type": "link",
//         "other": false,
//         "topper": "Cable"
//     },
//     {
//         "name": " Sata Cable",
//         "link__name": " Sata Cable",
//         "img__src": "/laptop.jpg",
//         "parent__link": "ACCESSORIES",
//         "type": "link",
//         "other": false,
//         "topper": "Cable"
//     },
//     {
//         "name": " Display Port Cable",
//         "link__name": " Display Port Cable",
//         "img__src": "/laptop.jpg",
//         "parent__link": "ACCESSORIES",
//         "type": "link",
//         "other": false,
//         "topper": "Cable"
//     },
//     {
//         "name": "Converter",
//         "link__name": "Converter",
//         "img__src": "/laptop.jpg",
//         "parent__link": "ACCESSORIES",
//         "type": "head",
//         "other": true,
//         "topper": "Converter"
//     },
//     {
//         "name": " HDMI Converter",
//         "link__name": " HDMI Converter",
//         "img__src": "/laptop.jpg",
//         "parent__link": "ACCESSORIES",
//         "type": "link",
//         "other": false,
//         "topper": "Converter"
//     },
//     {
//         "name": " VGA Converter",
//         "link__name": " VGA Converter",
//         "img__src": "/laptop.jpg",
//         "parent__link": "ACCESSORIES",
//         "type": "link",
//         "other": false,
//         "topper": "Converter"
//     },
//     {
//         "name": " USB HUB",
//         "link__name": " USB HUB",
//         "img__src": "/laptop.jpg",
//         "parent__link": "ACCESSORIES",
//         "type": "link",
//         "other": false,
//         "topper": "Converter"
//     },
//     {
//         "name": " Audio Converter",
//         "link__name": " Audio Converter",
//         "img__src": "/laptop.jpg",
//         "parent__link": "ACCESSORIES",
//         "type": "link",
//         "other": false,
//         "topper": "Converter"
//     },
//     {
//         "name": " Bluetooth Adapter",
//         "link__name": " Bluetooth Adapter",
//         "img__src": "/laptop.jpg",
//         "parent__link": "ACCESSORIES",
//         "type": "link",
//         "other": false,
//         "topper": "Converter"
//     },
//     {
//         "name": " Type-C Converter",
//         "link__name": " Type-C Converter",
//         "img__src": "/laptop.jpg",
//         "parent__link": "ACCESSORIES",
//         "type": "link",
//         "other": false,
//         "topper": "Converter"
//     },
//     {
//         "name": " Lightning Converter",
//         "link__name": " Lightning Converter",
//         "img__src": "/laptop.jpg",
//         "parent__link": "ACCESSORIES",
//         "type": "link",
//         "other": false,
//         "topper": "Converter"
//     },
//     {
//         "name": " USB Converter",
//         "link__name": " USB Converter",
//         "img__src": "/laptop.jpg",
//         "parent__link": "ACCESSORIES",
//         "type": "link",
//         "other": false,
//         "topper": "Converter"
//     },
//     {
//         "name": " Display Port Converter",
//         "link__name": " Display Port Converter",
//         "img__src": "/laptop.jpg",
//         "parent__link": "ACCESSORIES",
//         "type": "link",
//         "other": false,
//         "topper": "Converter"
//     },
//     {
//         "name": " DVI Converter",
//         "link__name": " DVI Converter",
//         "img__src": "/laptop.jpg",
//         "parent__link": "ACCESSORIES",
//         "type": "link",
//         "other": false,
//         "topper": "Converter"
//     },
//     {
//         "name": "Electrical Power",
//         "link__name": "Electrical Power",
//         "img__src": "/laptop.jpg",
//         "parent__link": "ACCESSORIES",
//         "type": "head",
//         "other": true,
//         "topper": "Electrical Power"
//     },
//     {
//         "name": " Power Strip",
//         "link__name": " Power Strip",
//         "img__src": "/laptop.jpg",
//         "parent__link": "ACCESSORIES",
//         "type": "link",
//         "other": false,
//         "topper": "Electrical Power"
//     },
//     {
//         "name": " Power Adapter",
//         "link__name": " Power Adapter",
//         "img__src": "/laptop.jpg",
//         "parent__link": "ACCESSORIES",
//         "type": "link",
//         "other": false,
//         "topper": "Electrical Power"
//     },
//     {
//         "name": " Blower",
//         "link__name": " Blower",
//         "img__src": "/laptop.jpg",
//         "parent__link": "ACCESSORIES",
//         "type": "link",
//         "other": false,
//         "topper": "Electrical Power"
//     },
//     {
//         "name": " Power Cable",
//         "link__name": " Power Cable",
//         "img__src": "/laptop.jpg",
//         "parent__link": "ACCESSORIES",
//         "type": "link",
//         "other": false,
//         "topper": "Electrical Power"
//     },
//     {
//         "name": "Premium Accessories",
//         "link__name": "Premium Accessories",
//         "img__src": "/laptop.jpg",
//         "parent__link": "ACCESSORIES",
//         "type": "head",
//         "other": true,
//         "topper": "Premium Accessories"
//     },
//     {
//         "name": " Apple Accessories",
//         "link__name": " Apple Accessories",
//         "img__src": "/laptop.jpg",
//         "parent__link": "ACCESSORIES",
//         "type": "link",
//         "other": false,
//         "topper": "Premium Accessories"
//     },
//     {
//         "name": " Microsoft Accessories",
//         "link__name": " Microsoft Accessories",
//         "img__src": "/laptop.jpg",
//         "parent__link": "ACCESSORIES",
//         "type": "link",
//         "other": false,
//         "topper": "Premium Accessories"
//     },
//     {
//         "name": " Digital Pen",
//         "link__name": " Digital Pen",
//         "img__src": "/laptop.jpg",
//         "parent__link": "ACCESSORIES",
//         "type": "link",
//         "other": false,
//         "topper": "Premium Accessories"
//     },
//     {
//         "name": " Power & Charger",
//         "link__name": " Power & Charger",
//         "img__src": "/laptop.jpg",
//         "parent__link": "ACCESSORIES",
//         "type": "link",
//         "other": false,
//         "topper": "Premium Accessories"
//     },
//     {
//         "name": "Bag",
//         "link__name": "Bag",
//         "img__src": "/laptop.jpg",
//         "parent__link": "ACCESSORIES",
//         "type": "head",
//         "other": true,
//         "topper": "Bag"
//     },
//     {
//         "name": "Antivirus and Security",
//         "link__name": "Antivirus and Security",
//         "img__src": "/laptop.jpg",
//         "parent__link": "SOFTWARE",
//         "type": "head",
//         "other": true,
//         "topper": "Antivirus and Security"
//     },
//     {
//         "name": "Office Application",
//         "link__name": "Office Application",
//         "img__src": "/laptop.jpg",
//         "parent__link": "SOFTWARE",
//         "type": "head",
//         "other": true,
//         "topper": "Office Application"
//     },
//     {
//         "name": "Operating System and DB",
//         "link__name": "Operating System and DB",
//         "img__src": "/laptop.jpg",
//         "parent__link": "SOFTWARE",
//         "type": "head",
//         "other": true,
//         "topper": "Operating System and DB"
//     },
//     {
//         "name": "Graphics Design",
//         "link__name": "Graphics Design",
//         "img__src": "/laptop.jpg",
//         "parent__link": "SOFTWARE",
//         "type": "head",
//         "other": true,
//         "topper": "Graphics Design"
//     },
//     {
//         "name": "Engineering Design",
//         "link__name": "Engineering Design",
//         "img__src": "/laptop.jpg",
//         "parent__link": "SOFTWARE",
//         "type": "head",
//         "other": true,
//         "topper": "Engineering Design"
//     },
//     {
//         "name": "Bangla Typing Application",
//         "link__name": "Bangla Typing Application",
//         "img__src": "/laptop.jpg",
//         "parent__link": "SOFTWARE",
//         "type": "head",
//         "other": true,
//         "topper": "Bangla Typing Application"
//     },
//     {
//         "name": "Smartwatch",
//         "link__name": "Smartwatch",
//         "img__src": "/laptop.jpg",
//         "parent__link": "DAILY LIFE",
//         "type": "head",
//         "other": true,
//         "topper": "Smartwatch"
//     },
//     {
//         "name": " Apple",
//         "link__name": " Apple",
//         "img__src": "/laptop.jpg",
//         "parent__link": "DAILY LIFE",
//         "type": "link",
//         "other": false,
//         "topper": "Smartwatch"
//     },
//     {
//         "name": " Kieslect",
//         "link__name": " Kieslect",
//         "img__src": "/laptop.jpg",
//         "parent__link": "DAILY LIFE",
//         "type": "link",
//         "other": false,
//         "topper": "Smartwatch"
//     },
//     {
//         "name": " Havit",
//         "link__name": " Havit",
//         "img__src": "/laptop.jpg",
//         "parent__link": "DAILY LIFE",
//         "type": "link",
//         "other": false,
//         "topper": "Smartwatch"
//     },
//     {
//         "name": " Xiaomi",
//         "link__name": " Xiaomi",
//         "img__src": "/laptop.jpg",
//         "parent__link": "DAILY LIFE",
//         "type": "link",
//         "other": false,
//         "topper": "Smartwatch"
//     },
//     {
//         "name": "Sewing Machine",
//         "link__name": "Sewing Machine",
//         "img__src": "/laptop.jpg",
//         "parent__link": "DAILY LIFE",
//         "type": "head",
//         "other": true,
//         "topper": "Sewing Machine"
//     },
//     {
//         "name": "TV and Video Streaming",
//         "link__name": "TV and Video Streaming",
//         "img__src": "/laptop.jpg",
//         "parent__link": "DAILY LIFE",
//         "type": "head",
//         "other": true,
//         "topper": "TV and Video Streaming"
//     },
//     {
//         "name": " Smart TV",
//         "link__name": " Smart TV",
//         "img__src": "/laptop.jpg",
//         "parent__link": "DAILY LIFE",
//         "type": "link",
//         "other": false,
//         "topper": "TV and Video Streaming"
//     },
//     {
//         "name": " TV Streaming",
//         "link__name": " TV Streaming",
//         "img__src": "/laptop.jpg",
//         "parent__link": "DAILY LIFE",
//         "type": "link",
//         "other": false,
//         "topper": "TV and Video Streaming"
//     },
//     {
//         "name": " TV Card",
//         "link__name": " TV Card",
//         "img__src": "/laptop.jpg",
//         "parent__link": "DAILY LIFE",
//         "type": "link",
//         "other": false,
//         "topper": "TV and Video Streaming"
//     },
//     {
//         "name": " Game Streaming",
//         "link__name": " Game Streaming",
//         "img__src": "/laptop.jpg",
//         "parent__link": "DAILY LIFE",
//         "type": "link",
//         "other": false,
//         "topper": "TV and Video Streaming"
//     },
//     {
//         "name": "POS SYSTEM",
//         "link__name": "POS SYSTEM",
//         "img__src": "/laptop.jpg",
//         "parent__link": "POS SYSTEM",
//         "type": "link",
//         "other": false,
//         "topper": "TV and Video Streaming"
//     }
// ]
// let totalLinkedArray = [];

// let itemHeader  = [];
// items.forEach((info, index) => {
//     if(itemHeader.indexOf(info.parent__link) === -1){
//         itemHeader.push(info.parent__link);
//         totalLinkedArray.push({
//             header: info.parent__link,
//             img__src: '/laptop.jpg',
//             link__name: info.parent__link,
//             links: [
//                 info
//             ]
//         })
//     }else{
//         let index = itemHeader.indexOf(info.parent__link);
        
//         let {links} = totalLinkedArray[index];
//         let newLink = [...links];
//             newLink.push(info);
//             totalLinkedArray[index].links = newLink;
//     }
// }) 

// items to allNavLinksConverter end


/// link array to items converter start
// const AllDigitalNavLinks = [ 
//     {
//         "header": "LAPTOP",
//         "img__src": "/laptop.jpg",
//         "link__name": "LAPTOP",
//         "links": [
//             {
//                 "name": "All Laptop",
//                 "link__name": "All Laptop",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "LAPTOP",
//                 "type": "head",
//                 "other": true,
//                 "topper": "All Laptop"
//             },
//             {
//                 "name": " Apple",
//                 "link__name": " Apple",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "LAPTOP",
//                 "type": "link",
//                 "other": false,
//                 "topper": "All Laptop"
//             },
//             {
//                 "name": " Asus",
//                 "link__name": " Asus",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "LAPTOP",
//                 "type": "link",
//                 "other": false,
//                 "topper": "All Laptop"
//             },
//             {
//                 "name": " Acer",
//                 "link__name": " Acer",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "LAPTOP",
//                 "type": "link",
//                 "other": false,
//                 "topper": "All Laptop"
//             },
//             {
//                 "name": " Avita",
//                 "link__name": " Avita",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "LAPTOP",
//                 "type": "link",
//                 "other": false,
//                 "topper": "All Laptop"
//             },
//             {
//                 "name": " Dell",
//                 "link__name": " Dell",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "LAPTOP",
//                 "type": "link",
//                 "other": false,
//                 "topper": "All Laptop"
//             },
//             {
//                 "name": " Chuwi",
//                 "link__name": " Chuwi",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "LAPTOP",
//                 "type": "link",
//                 "other": false,
//                 "topper": "All Laptop"
//             },
//             {
//                 "name": " HP",
//                 "link__name": " HP",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "LAPTOP",
//                 "type": "link",
//                 "other": false,
//                 "topper": "All Laptop"
//             },
//             {
//                 "name": " Huawei",
//                 "link__name": " Huawei",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "LAPTOP",
//                 "type": "link",
//                 "other": false,
//                 "topper": "All Laptop"
//             },
//             {
//                 "name": " i-Life",
//                 "link__name": " i-Life",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "LAPTOP",
//                 "type": "link",
//                 "other": false,
//                 "topper": "All Laptop"
//             },
//             {
//                 "name": " Lenovo",
//                 "link__name": " Lenovo",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "LAPTOP",
//                 "type": "link",
//                 "other": false,
//                 "topper": "All Laptop"
//             },
//             {
//                 "name": " Microsoft",
//                 "link__name": " Microsoft",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "LAPTOP",
//                 "type": "link",
//                 "other": false,
//                 "topper": "All Laptop"
//             },
//             {
//                 "name": " MSI",
//                 "link__name": " MSI",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "LAPTOP",
//                 "type": "link",
//                 "other": false,
//                 "topper": "All Laptop"
//             },
//             {
//                 "name": " Nexstgo",
//                 "link__name": " Nexstgo",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "LAPTOP",
//                 "type": "link",
//                 "other": false,
//                 "topper": "All Laptop"
//             },
//             {
//                 "name": " Razer",
//                 "link__name": " Razer",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "LAPTOP",
//                 "type": "link",
//                 "other": false,
//                 "topper": "All Laptop"
//             },
//             {
//                 "name": " Gigabyte",
//                 "link__name": " Gigabyte",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "LAPTOP",
//                 "type": "link",
//                 "other": false,
//                 "topper": "All Laptop"
//             },
//             {
//                 "name": "Accessories",
//                 "link__name": "Accessories",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "LAPTOP",
//                 "type": "head",
//                 "other": true,
//                 "topper": "Accessories"
//             },
//             {
//                 "name": " Laptop Ram",
//                 "link__name": " Laptop Ram",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "LAPTOP",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Accessories"
//             },
//             {
//                 "name": " Laptop Cooler",
//                 "link__name": " Laptop Cooler",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "LAPTOP",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Accessories"
//             },
//             {
//                 "name": " Caddy",
//                 "link__name": " Caddy",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "LAPTOP",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Accessories"
//             },
//             {
//                 "name": " Laptop Bag",
//                 "link__name": " Laptop Bag",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "LAPTOP",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Accessories"
//             },
//             {
//                 "name": " Stand",
//                 "link__name": " Stand",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "LAPTOP",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Accessories"
//             },
//             {
//                 "name": " Battery",
//                 "link__name": " Battery",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "LAPTOP",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Accessories"
//             },
//             {
//                 "name": " Adapter",
//                 "link__name": " Adapter",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "LAPTOP",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Accessories"
//             }
//         ]
//     },
//     {
//         "header": "DESKTOP PC AND SERVER",
//         "img__src": "/laptop.jpg",
//         "link__name": "DESKTOP PC AND SERVER",
//         "links": [
//             {
//                 "name": "Desktop PC",
//                 "link__name": "Desktop PC",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "DESKTOP PC AND SERVER",
//                 "type": "head",
//                 "other": true,
//                 "topper": "Desktop PC"
//             },
//             {
//                 "name": " Brand Desktop PC",
//                 "link__name": " Brand Desktop PC",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "DESKTOP PC AND SERVER",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Desktop PC"
//             },
//             {
//                 "name": " All In One PC",
//                 "link__name": " All In One PC",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "DESKTOP PC AND SERVER",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Desktop PC"
//             },
//             {
//                 "name": " Mini PC",
//                 "link__name": " Mini PC",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "DESKTOP PC AND SERVER",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Desktop PC"
//             },
//             {
//                 "name": " Ryans PC",
//                 "link__name": " Ryans PC",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "DESKTOP PC AND SERVER",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Desktop PC"
//             },
//             {
//                 "name": "Desktop Component",
//                 "link__name": "Desktop Component",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "DESKTOP PC AND SERVER",
//                 "type": "head",
//                 "other": true,
//                 "topper": "Desktop Component"
//             },
//             {
//                 "name": " Processor",
//                 "link__name": " Processor",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "DESKTOP PC AND SERVER",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Desktop Component"
//             },
//             {
//                 "name": " Motherboard",
//                 "link__name": " Motherboard",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "DESKTOP PC AND SERVER",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Desktop Component"
//             },
//             {
//                 "name": " Desktop Ram",
//                 "link__name": " Desktop Ram",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "DESKTOP PC AND SERVER",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Desktop Component"
//             },
//             {
//                 "name": " Optical Device",
//                 "link__name": " Optical Device",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "DESKTOP PC AND SERVER",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Desktop Component"
//             },
//             {
//                 "name": " Graphics Card",
//                 "link__name": " Graphics Card",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "DESKTOP PC AND SERVER",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Desktop Component"
//             },
//             {
//                 "name": " Power Supply",
//                 "link__name": " Power Supply",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "DESKTOP PC AND SERVER",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Desktop Component"
//             },
//             {
//                 "name": " Casing",
//                 "link__name": " Casing",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "DESKTOP PC AND SERVER",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Desktop Component"
//             },
//             {
//                 "name": " Casing Fan",
//                 "link__name": " Casing Fan",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "DESKTOP PC AND SERVER",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Desktop Component"
//             },
//             {
//                 "name": " CPU Cooler",
//                 "link__name": " CPU Cooler",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "DESKTOP PC AND SERVER",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Desktop Component"
//             },
//             {
//                 "name": " Keyboard",
//                 "link__name": " Keyboard",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "DESKTOP PC AND SERVER",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Desktop Component"
//             },
//             {
//                 "name": " Mouse",
//                 "link__name": " Mouse",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "DESKTOP PC AND SERVER",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Desktop Component"
//             },
//             {
//                 "name": " Keyboard and Mouse Combo",
//                 "link__name": " Keyboard and Mouse Combo",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "DESKTOP PC AND SERVER",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Desktop Component"
//             },
//             {
//                 "name": " Mouse Pad",
//                 "link__name": " Mouse Pad",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "DESKTOP PC AND SERVER",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Desktop Component"
//             },
//             {
//                 "name": " UPS",
//                 "link__name": " UPS",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "DESKTOP PC AND SERVER",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Desktop Component"
//             },
//             {
//                 "name": "Server",
//                 "link__name": "Server",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "DESKTOP PC AND SERVER",
//                 "type": "head",
//                 "other": true,
//                 "topper": "Server"
//             },
//             {
//                 "name": " Rack",
//                 "link__name": " Rack",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "DESKTOP PC AND SERVER",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Server"
//             },
//             {
//                 "name": " Tower",
//                 "link__name": " Tower",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "DESKTOP PC AND SERVER",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Server"
//             },
//             {
//                 "name": "Server Component",
//                 "link__name": "Server Component",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "DESKTOP PC AND SERVER",
//                 "type": "head",
//                 "other": true,
//                 "topper": "Server Component"
//             },
//             {
//                 "name": " Server Cabinet",
//                 "link__name": " Server Cabinet",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "DESKTOP PC AND SERVER",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Server Component"
//             },
//             {
//                 "name": " Server Ram",
//                 "link__name": " Server Ram",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "DESKTOP PC AND SERVER",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Server Component"
//             },
//             {
//                 "name": "Desktop Accessories",
//                 "link__name": "Desktop Accessories",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "DESKTOP PC AND SERVER",
//                 "type": "head",
//                 "other": true,
//                 "topper": "Desktop Accessories"
//             },
//             {
//                 "name": " LED Strip",
//                 "link__name": " LED Strip",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "DESKTOP PC AND SERVER",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Desktop Accessories"
//             },
//             {
//                 "name": " Casing Accessories",
//                 "link__name": " Casing Accessories",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "DESKTOP PC AND SERVER",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Desktop Accessories"
//             },
//             {
//                 "name": " Side Panel",
//                 "link__name": " Side Panel",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "DESKTOP PC AND SERVER",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Desktop Accessories"
//             },
//             {
//                 "name": " Thermal Paste",
//                 "link__name": " Thermal Paste",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "DESKTOP PC AND SERVER",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Desktop Accessories"
//             }
//         ]
//     },
//     {
//         "header": "GAMING",
//         "img__src": "/laptop.jpg",
//         "link__name": "GAMING",
//         "links": [
//             {
//                 "name": "Gaming Component",
//                 "link__name": "Gaming Component",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "GAMING",
//                 "type": "head",
//                 "other": true,
//                 "topper": "Gaming Component"
//             },
//             {
//                 "name": " Gaming Console",
//                 "link__name": " Gaming Console",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "GAMING",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Gaming Component"
//             },
//             {
//                 "name": " Gaming Controller",
//                 "link__name": " Gaming Controller",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "GAMING",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Gaming Component"
//             },
//             {
//                 "name": " Capture Card",
//                 "link__name": " Capture Card",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "GAMING",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Gaming Component"
//             },
//             {
//                 "name": " Games",
//                 "link__name": " Games",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "GAMING",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Gaming Component"
//             },
//             {
//                 "name": " Gaming Chair",
//                 "link__name": " Gaming Chair",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "GAMING",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Gaming Component"
//             },
//             {
//                 "name": " Gaming Desk",
//                 "link__name": " Gaming Desk",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "GAMING",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Gaming Component"
//             },
//             {
//                 "name": "Gaming Laptop",
//                 "link__name": "Gaming Laptop",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "GAMING",
//                 "type": "head",
//                 "other": true,
//                 "topper": "Gaming Laptop"
//             },
//             {
//                 "name": "Gaming Desktop PC",
//                 "link__name": "Gaming Desktop PC",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "GAMING",
//                 "type": "head",
//                 "other": true,
//                 "topper": "Gaming Desktop PC"
//             },
//             {
//                 "name": " Ryans PC",
//                 "link__name": " Ryans PC",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "GAMING",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Gaming Desktop PC"
//             },
//             {
//                 "name": "Gaming Desktop Component",
//                 "link__name": "Gaming Desktop Component",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "GAMING",
//                 "type": "head",
//                 "other": true,
//                 "topper": "Gaming Desktop Component"
//             },
//             {
//                 "name": " Motherboard",
//                 "link__name": " Motherboard",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "GAMING",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Gaming Desktop Component"
//             },
//             {
//                 "name": " Desktop Ram",
//                 "link__name": " Desktop Ram",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "GAMING",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Gaming Desktop Component"
//             },
//             {
//                 "name": " Graphics Card",
//                 "link__name": " Graphics Card",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "GAMING",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Gaming Desktop Component"
//             },
//             {
//                 "name": " Power Supply",
//                 "link__name": " Power Supply",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "GAMING",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Gaming Desktop Component"
//             },
//             {
//                 "name": " Casing",
//                 "link__name": " Casing",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "GAMING",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Gaming Desktop Component"
//             },
//             {
//                 "name": " CPU Cooler",
//                 "link__name": " CPU Cooler",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "GAMING",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Gaming Desktop Component"
//             },
//             {
//                 "name": " Keyboard",
//                 "link__name": " Keyboard",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "GAMING",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Gaming Desktop Component"
//             },
//             {
//                 "name": " Mouse",
//                 "link__name": " Mouse",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "GAMING",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Gaming Desktop Component"
//             },
//             {
//                 "name": " Mouse Pad",
//                 "link__name": " Mouse Pad",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "GAMING",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Gaming Desktop Component"
//             },
//             {
//                 "name": " LED Strip",
//                 "link__name": " LED Strip",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "GAMING",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Gaming Desktop Component"
//             },
//             {
//                 "name": "Gaming Monitor",
//                 "link__name": "Gaming Monitor",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "GAMING",
//                 "type": "head",
//                 "other": true,
//                 "topper": "Gaming Monitor"
//             },
//             {
//                 "name": "Sound System",
//                 "link__name": "Sound System",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "GAMING",
//                 "type": "head",
//                 "other": true,
//                 "topper": "Sound System"
//             },
//             {
//                 "name": " Speaker",
//                 "link__name": " Speaker",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "GAMING",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Sound System"
//             },
//             {
//                 "name": " Headphone",
//                 "link__name": " Headphone",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "GAMING",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Sound System"
//             },
//             {
//                 "name": " Microphone",
//                 "link__name": " Microphone",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "GAMING",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Sound System"
//             },
//             {
//                 "name": " Earphone",
//                 "link__name": " Earphone",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "GAMING",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Sound System"
//             },
//             {
//                 "name": "Network Router",
//                 "link__name": "Network Router",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "GAMING",
//                 "type": "head",
//                 "other": true,
//                 "topper": "Network Router"
//             }
//         ]
//     },
//     {
//         "header": "MONITOR",
//         "img__src": "/laptop.jpg",
//         "link__name": "MONITOR",
//         "links": [
//             {
//                 "name": "All Monitor",
//                 "link__name": "All Monitor",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "MONITOR",
//                 "type": "head",
//                 "other": true,
//                 "topper": "All Monitor"
//             },
//             {
//                 "name": " Asus",
//                 "link__name": " Asus",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "MONITOR",
//                 "type": "link",
//                 "other": false,
//                 "topper": "All Monitor"
//             },
//             {
//                 "name": " Aoc",
//                 "link__name": " Aoc",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "MONITOR",
//                 "type": "link",
//                 "other": false,
//                 "topper": "All Monitor"
//             },
//             {
//                 "name": " Acer",
//                 "link__name": " Acer",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "MONITOR",
//                 "type": "link",
//                 "other": false,
//                 "topper": "All Monitor"
//             },
//             {
//                 "name": " Benq",
//                 "link__name": " Benq",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "MONITOR",
//                 "type": "link",
//                 "other": false,
//                 "topper": "All Monitor"
//             },
//             {
//                 "name": " Dell",
//                 "link__name": " Dell",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "MONITOR",
//                 "type": "link",
//                 "other": false,
//                 "topper": "All Monitor"
//             },
//             {
//                 "name": " Gigabyte",
//                 "link__name": " Gigabyte",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "MONITOR",
//                 "type": "link",
//                 "other": false,
//                 "topper": "All Monitor"
//             },
//             {
//                 "name": " HP",
//                 "link__name": " HP",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "MONITOR",
//                 "type": "link",
//                 "other": false,
//                 "topper": "All Monitor"
//             },
//             {
//                 "name": " Xiaomi",
//                 "link__name": " Xiaomi",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "MONITOR",
//                 "type": "link",
//                 "other": false,
//                 "topper": "All Monitor"
//             },
//             {
//                 "name": " Gamemax",
//                 "link__name": " Gamemax",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "MONITOR",
//                 "type": "link",
//                 "other": false,
//                 "topper": "All Monitor"
//             },
//             {
//                 "name": " LG",
//                 "link__name": " LG",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "MONITOR",
//                 "type": "link",
//                 "other": false,
//                 "topper": "All Monitor"
//             },
//             {
//                 "name": " Lenovo",
//                 "link__name": " Lenovo",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "MONITOR",
//                 "type": "link",
//                 "other": false,
//                 "topper": "All Monitor"
//             },
//             {
//                 "name": " MSI",
//                 "link__name": " MSI",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "MONITOR",
//                 "type": "link",
//                 "other": false,
//                 "topper": "All Monitor"
//             },
//             {
//                 "name": " Philips",
//                 "link__name": " Philips",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "MONITOR",
//                 "type": "link",
//                 "other": false,
//                 "topper": "All Monitor"
//             },
//             {
//                 "name": " Samsung",
//                 "link__name": " Samsung",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "MONITOR",
//                 "type": "link",
//                 "other": false,
//                 "topper": "All Monitor"
//             },
//             {
//                 "name": " Viewsonic",
//                 "link__name": " Viewsonic",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "MONITOR",
//                 "type": "link",
//                 "other": false,
//                 "topper": "All Monitor"
//             },
//             {
//                 "name": " Huawei",
//                 "link__name": " Huawei",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "MONITOR",
//                 "type": "link",
//                 "other": false,
//                 "topper": "All Monitor"
//             },
//             {
//                 "name": " Fantech",
//                 "link__name": " Fantech",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "MONITOR",
//                 "type": "link",
//                 "other": false,
//                 "topper": "All Monitor"
//             },
//             {
//                 "name": " Corsair",
//                 "link__name": " Corsair",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "MONITOR",
//                 "type": "link",
//                 "other": false,
//                 "topper": "All Monitor"
//             },
//             {
//                 "name": " Hikvision",
//                 "link__name": " Hikvision",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "MONITOR",
//                 "type": "link",
//                 "other": false,
//                 "topper": "All Monitor"
//             },
//             {
//                 "name": " INNOVTECH",
//                 "link__name": " INNOVTECH",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "MONITOR",
//                 "type": "link",
//                 "other": false,
//                 "topper": "All Monitor"
//             },
//             {
//                 "name": " Razer",
//                 "link__name": " Razer",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "MONITOR",
//                 "type": "link",
//                 "other": false,
//                 "topper": "All Monitor"
//             },
//             {
//                 "name": "Monitor Accessories",
//                 "link__name": "Monitor Accessories",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "MONITOR",
//                 "type": "head",
//                 "other": true,
//                 "topper": "Monitor Accessories"
//             },
//             {
//                 "name": " Monitor Mounts and Brackets",
//                 "link__name": " Monitor Mounts and Brackets",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "MONITOR",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Monitor Accessories"
//             }
//         ]
//     },
//     {
//         "header": "TABLET",
//         "img__src": "/laptop.jpg",
//         "link__name": "TABLET",
//         "links": [
//             {
//                 "name": "Regular Tablet",
//                 "link__name": "Regular Tablet",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "TABLET",
//                 "type": "head",
//                 "other": true,
//                 "topper": "Regular Tablet"
//             },
//             {
//                 "name": " All Brands",
//                 "link__name": " All Brands",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "TABLET",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Regular Tablet"
//             },
//             {
//                 "name": " Amazon",
//                 "link__name": " Amazon",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "TABLET",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Regular Tablet"
//             },
//             {
//                 "name": " Lenovo",
//                 "link__name": " Lenovo",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "TABLET",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Regular Tablet"
//             },
//             {
//                 "name": " Samsung",
//                 "link__name": " Samsung",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "TABLET",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Regular Tablet"
//             },
//             {
//                 "name": " Huawei",
//                 "link__name": " Huawei",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "TABLET",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Regular Tablet"
//             },
//             {
//                 "name": "Apple Tablet",
//                 "link__name": "Apple Tablet",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "TABLET",
//                 "type": "head",
//                 "other": true,
//                 "topper": "Apple Tablet"
//             },
//             {
//                 "name": " iPad",
//                 "link__name": " iPad",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "TABLET",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Apple Tablet"
//             },
//             {
//                 "name": "E-Reader Tablet",
//                 "link__name": "E-Reader Tablet",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "TABLET",
//                 "type": "head",
//                 "other": true,
//                 "topper": "E-Reader Tablet"
//             },
//             {
//                 "name": " Amazon",
//                 "link__name": " Amazon",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "TABLET",
//                 "type": "link",
//                 "other": false,
//                 "topper": "E-Reader Tablet"
//             },
//             {
//                 "name": "Kids Tablet",
//                 "link__name": "Kids Tablet",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "TABLET",
//                 "type": "head",
//                 "other": true,
//                 "topper": "Kids Tablet"
//             },
//             {
//                 "name": "Graphics Tablet",
//                 "link__name": "Graphics Tablet",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "TABLET",
//                 "type": "head",
//                 "other": true,
//                 "topper": "Graphics Tablet"
//             },
//             {
//                 "name": " All Brands",
//                 "link__name": " All Brands",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "TABLET",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Graphics Tablet"
//             },
//             {
//                 "name": " Wacom",
//                 "link__name": " Wacom",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "TABLET",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Graphics Tablet"
//             },
//             {
//                 "name": " XP-PEN",
//                 "link__name": " XP-PEN",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "TABLET",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Graphics Tablet"
//             },
//             {
//                 "name": " Xiaomi",
//                 "link__name": " Xiaomi",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "TABLET",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Graphics Tablet"
//             },
//             {
//                 "name": "Mobile and Tablet Accessories",
//                 "link__name": "Mobile and Tablet Accessories",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "TABLET",
//                 "type": "head",
//                 "other": true,
//                 "topper": "Mobile and Tablet Accessories"
//             },
//             {
//                 "name": " Power Bank",
//                 "link__name": " Power Bank",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "TABLET",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Mobile and Tablet Accessories"
//             },
//             {
//                 "name": " Car Charger",
//                 "link__name": " Car Charger",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "TABLET",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Mobile and Tablet Accessories"
//             },
//             {
//                 "name": " Wireless Charger",
//                 "link__name": " Wireless Charger",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "TABLET",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Mobile and Tablet Accessories"
//             },
//             {
//                 "name": " Wall Charger",
//                 "link__name": " Wall Charger",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "TABLET",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Mobile and Tablet Accessories"
//             },
//             {
//                 "name": " Cable Organizer",
//                 "link__name": " Cable Organizer",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "TABLET",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Mobile and Tablet Accessories"
//             },
//             {
//                 "name": " Phone Holder",
//                 "link__name": " Phone Holder",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "TABLET",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Mobile and Tablet Accessories"
//             },
//             {
//                 "name": " Screen Cleaner",
//                 "link__name": " Screen Cleaner",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "TABLET",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Mobile and Tablet Accessories"
//             }
//         ]
//     },
//     {
//         "header": "PRINTER",
//         "img__src": "/laptop.jpg",
//         "link__name": "PRINTER",
//         "links": [
//             {
//                 "name": "All Laser and INK Printer",
//                 "link__name": "All Laser and INK Printer",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "PRINTER",
//                 "type": "head",
//                 "other": true,
//                 "topper": "All Laser and INK Printer"
//             },
//             {
//                 "name": " Laser Printer",
//                 "link__name": " Laser Printer",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "PRINTER",
//                 "type": "link",
//                 "other": false,
//                 "topper": "All Laser and INK Printer"
//             },
//             {
//                 "name": " Ink Printer",
//                 "link__name": " Ink Printer",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "PRINTER",
//                 "type": "link",
//                 "other": false,
//                 "topper": "All Laser and INK Printer"
//             },
//             {
//                 "name": "Label Printer",
//                 "link__name": "Label Printer",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "PRINTER",
//                 "type": "head",
//                 "other": true,
//                 "topper": "Label Printer"
//             },
//             {
//                 "name": "Card Printer",
//                 "link__name": "Card Printer",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "PRINTER",
//                 "type": "head",
//                 "other": true,
//                 "topper": "Card Printer"
//             },
//             {
//                 "name": "Dot Matrix Printer",
//                 "link__name": "Dot Matrix Printer",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "PRINTER",
//                 "type": "head",
//                 "other": true,
//                 "topper": "Dot Matrix Printer"
//             },
//             {
//                 "name": "POS Printer",
//                 "link__name": "POS Printer",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "PRINTER",
//                 "type": "head",
//                 "other": true,
//                 "topper": "POS Printer"
//             },
//             {
//                 "name": "Large Format Printer",
//                 "link__name": "Large Format Printer",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "PRINTER",
//                 "type": "head",
//                 "other": true,
//                 "topper": "Large Format Printer"
//             },
//             {
//                 "name": "Printer Paper",
//                 "link__name": "Printer Paper",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "PRINTER",
//                 "type": "head",
//                 "other": true,
//                 "topper": "Printer Paper"
//             },
//             {
//                 "name": "Consumable",
//                 "link__name": "Consumable",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "PRINTER",
//                 "type": "head",
//                 "other": true,
//                 "topper": "Consumable"
//             },
//             {
//                 "name": " Toner",
//                 "link__name": " Toner",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "PRINTER",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Consumable"
//             },
//             {
//                 "name": " Cartridge",
//                 "link__name": " Cartridge",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "PRINTER",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Consumable"
//             },
//             {
//                 "name": " Ribbon",
//                 "link__name": " Ribbon",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "PRINTER",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Consumable"
//             },
//             {
//                 "name": " Refill",
//                 "link__name": " Refill",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "PRINTER",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Consumable"
//             },
//             {
//                 "name": " Drum Unit",
//                 "link__name": " Drum Unit",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "PRINTER",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Consumable"
//             },
//             {
//                 "name": " Print Head",
//                 "link__name": " Print Head",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "PRINTER",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Consumable"
//             },
//             {
//                 "name": " Accessories",
//                 "link__name": " Accessories",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "PRINTER",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Consumable"
//             }
//         ]
//     },
//     {
//         "header": "SCANNER",
//         "img__src": "/laptop.jpg",
//         "link__name": "SCANNER",
//         "links": [
//             {
//                 "name": "Flatbed Scanner",
//                 "link__name": "Flatbed Scanner",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "SCANNER",
//                 "type": "head",
//                 "other": true,
//                 "topper": "Flatbed Scanner"
//             },
//             {
//                 "name": " Canon",
//                 "link__name": " Canon",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "SCANNER",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Flatbed Scanner"
//             },
//             {
//                 "name": " Epson",
//                 "link__name": " Epson",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "SCANNER",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Flatbed Scanner"
//             },
//             {
//                 "name": " HP",
//                 "link__name": " HP",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "SCANNER",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Flatbed Scanner"
//             },
//             {
//                 "name": " Plustek",
//                 "link__name": " Plustek",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "SCANNER",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Flatbed Scanner"
//             },
//             {
//                 "name": " Avision",
//                 "link__name": " Avision",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "SCANNER",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Flatbed Scanner"
//             },
//             {
//                 "name": "Sheetfed and Flatbed Scanner",
//                 "link__name": "Sheetfed and Flatbed Scanner",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "SCANNER",
//                 "type": "head",
//                 "other": true,
//                 "topper": "Sheetfed and Flatbed Scanner"
//             },
//             {
//                 "name": " Canon",
//                 "link__name": " Canon",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "SCANNER",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Sheetfed and Flatbed Scanner"
//             },
//             {
//                 "name": " Epson",
//                 "link__name": " Epson",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "SCANNER",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Sheetfed and Flatbed Scanner"
//             },
//             {
//                 "name": " HP",
//                 "link__name": " HP",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "SCANNER",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Sheetfed and Flatbed Scanner"
//             },
//             {
//                 "name": " Plustek",
//                 "link__name": " Plustek",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "SCANNER",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Sheetfed and Flatbed Scanner"
//             },
//             {
//                 "name": " Brother",
//                 "link__name": " Brother",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "SCANNER",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Sheetfed and Flatbed Scanner"
//             },
//             {
//                 "name": "Barcode Scanner",
//                 "link__name": "Barcode Scanner",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "SCANNER",
//                 "type": "head",
//                 "other": true,
//                 "topper": "Barcode Scanner"
//             },
//             {
//                 "name": " Zebex",
//                 "link__name": " Zebex",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "SCANNER",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Barcode Scanner"
//             },
//             {
//                 "name": " Sewoo",
//                 "link__name": " Sewoo",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "SCANNER",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Barcode Scanner"
//             },
//             {
//                 "name": " Honeywell",
//                 "link__name": " Honeywell",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "SCANNER",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Barcode Scanner"
//             },
//             {
//                 "name": " Rongta",
//                 "link__name": " Rongta",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "SCANNER",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Barcode Scanner"
//             },
//             {
//                 "name": " Zebra",
//                 "link__name": " Zebra",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "SCANNER",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Barcode Scanner"
//             },
//             {
//                 "name": "Document and Book Scanner",
//                 "link__name": "Document and Book Scanner",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "SCANNER",
//                 "type": "head",
//                 "other": true,
//                 "topper": "Document and Book Scanner"
//             },
//             {
//                 "name": " CZUR",
//                 "link__name": " CZUR",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "SCANNER",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Document and Book Scanner"
//             },
//             {
//                 "name": "Portable Scanner",
//                 "link__name": "Portable Scanner",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "SCANNER",
//                 "type": "head",
//                 "other": true,
//                 "topper": "Portable Scanner"
//             },
//             {
//                 "name": " Plustek",
//                 "link__name": " Plustek",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "SCANNER",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Portable Scanner"
//             },
//             {
//                 "name": "Cheque Scanner",
//                 "link__name": "Cheque Scanner",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "SCANNER",
//                 "type": "head",
//                 "other": true,
//                 "topper": "Cheque Scanner"
//             },
//             {
//                 "name": " Canon",
//                 "link__name": " Canon",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "SCANNER",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Cheque Scanner"
//             }
//         ]
//     },
//     {
//         "header": "PHOTOCOPIER",
//         "img__src": "/laptop.jpg",
//         "link__name": "PHOTOCOPIER",
//         "links": [
//             {
//                 "name": "All Photocopier",
//                 "link__name": "All Photocopier",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "PHOTOCOPIER",
//                 "type": "head",
//                 "other": true,
//                 "topper": "All Photocopier"
//             },
//             {
//                 "name": " Canon",
//                 "link__name": " Canon",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "PHOTOCOPIER",
//                 "type": "link",
//                 "other": false,
//                 "topper": "All Photocopier"
//             },
//             {
//                 "name": " HP",
//                 "link__name": " HP",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "PHOTOCOPIER",
//                 "type": "link",
//                 "other": false,
//                 "topper": "All Photocopier"
//             },
//             {
//                 "name": " Ricoh",
//                 "link__name": " Ricoh",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "PHOTOCOPIER",
//                 "type": "link",
//                 "other": false,
//                 "topper": "All Photocopier"
//             },
//             {
//                 "name": " Sharp",
//                 "link__name": " Sharp",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "PHOTOCOPIER",
//                 "type": "link",
//                 "other": false,
//                 "topper": "All Photocopier"
//             },
//             {
//                 "name": " Toshiba",
//                 "link__name": " Toshiba",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "PHOTOCOPIER",
//                 "type": "link",
//                 "other": false,
//                 "topper": "All Photocopier"
//             },
//             {
//                 "name": "Photocopier Accessories",
//                 "link__name": "Photocopier Accessories",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "PHOTOCOPIER",
//                 "type": "head",
//                 "other": true,
//                 "topper": "Photocopier Accessories"
//             }
//         ]
//     },
//     {
//         "header": "PROJECTOR",
//         "img__src": "/laptop.jpg",
//         "link__name": "PROJECTOR",
//         "links": [
//             {
//                 "name": "All Projector",
//                 "link__name": "All Projector",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "PROJECTOR",
//                 "type": "head",
//                 "other": true,
//                 "topper": "All Projector"
//             },
//             {
//                 "name": " Maxell",
//                 "link__name": " Maxell",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "PROJECTOR",
//                 "type": "link",
//                 "other": false,
//                 "topper": "All Projector"
//             },
//             {
//                 "name": " Benq",
//                 "link__name": " Benq",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "PROJECTOR",
//                 "type": "link",
//                 "other": false,
//                 "topper": "All Projector"
//             },
//             {
//                 "name": " Optoma",
//                 "link__name": " Optoma",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "PROJECTOR",
//                 "type": "link",
//                 "other": false,
//                 "topper": "All Projector"
//             },
//             {
//                 "name": " ViewSonic",
//                 "link__name": " ViewSonic",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "PROJECTOR",
//                 "type": "link",
//                 "other": false,
//                 "topper": "All Projector"
//             },
//             {
//                 "name": " Micropack",
//                 "link__name": " Micropack",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "PROJECTOR",
//                 "type": "link",
//                 "other": false,
//                 "topper": "All Projector"
//             },
//             {
//                 "name": " Asus",
//                 "link__name": " Asus",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "PROJECTOR",
//                 "type": "link",
//                 "other": false,
//                 "topper": "All Projector"
//             },
//             {
//                 "name": " Epson",
//                 "link__name": " Epson",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "PROJECTOR",
//                 "type": "link",
//                 "other": false,
//                 "topper": "All Projector"
//             },
//             {
//                 "name": " Vivitek",
//                 "link__name": " Vivitek",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "PROJECTOR",
//                 "type": "link",
//                 "other": false,
//                 "topper": "All Projector"
//             },
//             {
//                 "name": " Casio",
//                 "link__name": " Casio",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "PROJECTOR",
//                 "type": "link",
//                 "other": false,
//                 "topper": "All Projector"
//             },
//             {
//                 "name": "Projector Screen",
//                 "link__name": "Projector Screen",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "PROJECTOR",
//                 "type": "head",
//                 "other": true,
//                 "topper": "Projector Screen"
//             },
//             {
//                 "name": "Digital Display",
//                 "link__name": "Digital Display",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "PROJECTOR",
//                 "type": "head",
//                 "other": true,
//                 "topper": "Digital Display"
//             },
//             {
//                 "name": " Interactive Panel",
//                 "link__name": " Interactive Panel",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "PROJECTOR",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Digital Display"
//             },
//             {
//                 "name": " Digital Signage",
//                 "link__name": " Digital Signage",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "PROJECTOR",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Digital Display"
//             },
//             {
//                 "name": "Presenter",
//                 "link__name": "Presenter",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "PROJECTOR",
//                 "type": "head",
//                 "other": true,
//                 "topper": "Presenter"
//             },
//             {
//                 "name": "Ceiling Mount kit",
//                 "link__name": "Ceiling Mount kit",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "PROJECTOR",
//                 "type": "head",
//                 "other": true,
//                 "topper": "Ceiling Mount kit"
//             },
//             {
//                 "name": "Projector  Accessories",
//                 "link__name": "Projector  Accessories",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "PROJECTOR",
//                 "type": "head",
//                 "other": true,
//                 "topper": "Projector  Accessories"
//             }
//         ]
//     },
//     {
//         "header": "CAMERA",
//         "img__src": "/laptop.jpg",
//         "link__name": "CAMERA",
//         "links": [
//             {
//                 "name": "Digital SLR Camera",
//                 "link__name": "Digital SLR Camera",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "CAMERA",
//                 "type": "head",
//                 "other": true,
//                 "topper": "Digital SLR Camera"
//             },
//             {
//                 "name": " DSLR Camera",
//                 "link__name": " DSLR Camera",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "CAMERA",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Digital SLR Camera"
//             },
//             {
//                 "name": " Mirrorless Camera",
//                 "link__name": " Mirrorless Camera",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "CAMERA",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Digital SLR Camera"
//             },
//             {
//                 "name": " DSLR Camera Lens",
//                 "link__name": " DSLR Camera Lens",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "CAMERA",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Digital SLR Camera"
//             },
//             {
//                 "name": " DSLR Camera Accessories",
//                 "link__name": " DSLR Camera Accessories",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "CAMERA",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Digital SLR Camera"
//             },
//             {
//                 "name": "Digital Compact Camera",
//                 "link__name": "Digital Compact Camera",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "CAMERA",
//                 "type": "head",
//                 "other": true,
//                 "topper": "Digital Compact Camera"
//             },
//             {
//                 "name": " Compact Camera",
//                 "link__name": " Compact Camera",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "CAMERA",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Digital Compact Camera"
//             },
//             {
//                 "name": " Handy Camera",
//                 "link__name": " Handy Camera",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "CAMERA",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Digital Compact Camera"
//             },
//             {
//                 "name": " Action Camera",
//                 "link__name": " Action Camera",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "CAMERA",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Digital Compact Camera"
//             },
//             {
//                 "name": " Compact Camera Accessories",
//                 "link__name": " Compact Camera Accessories",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "CAMERA",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Digital Compact Camera"
//             },
//             {
//                 "name": "Video Camera",
//                 "link__name": "Video Camera",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "CAMERA",
//                 "type": "head",
//                 "other": true,
//                 "topper": "Video Camera"
//             },
//             {
//                 "name": "Webcam",
//                 "link__name": "Webcam",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "CAMERA",
//                 "type": "head",
//                 "other": true,
//                 "topper": "Webcam"
//             },
//             {
//                 "name": "Drone",
//                 "link__name": "Drone",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "CAMERA",
//                 "type": "head",
//                 "other": true,
//                 "topper": "Drone"
//             }
//         ]
//     },
//     {
//         "header": "SECURITY SYSTEM",
//         "img__src": "/laptop.jpg",
//         "link__name": "SECURITY SYSTEM",
//         "links": [
//             {
//                 "name": "CC Camera",
//                 "link__name": "CC Camera",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "SECURITY SYSTEM",
//                 "type": "head",
//                 "other": true,
//                 "topper": "CC Camera"
//             },
//             {
//                 "name": "IP Camera",
//                 "link__name": "IP Camera",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "SECURITY SYSTEM",
//                 "type": "head",
//                 "other": true,
//                 "topper": "IP Camera"
//             },
//             {
//                 "name": "Wireless Camera",
//                 "link__name": "Wireless Camera",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "SECURITY SYSTEM",
//                 "type": "head",
//                 "other": true,
//                 "topper": "Wireless Camera"
//             },
//             {
//                 "name": "DVR",
//                 "link__name": "DVR",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "SECURITY SYSTEM",
//                 "type": "head",
//                 "other": true,
//                 "topper": "DVR"
//             },
//             {
//                 "name": "NVR",
//                 "link__name": "NVR",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "SECURITY SYSTEM",
//                 "type": "head",
//                 "other": true,
//                 "topper": "NVR"
//             },
//             {
//                 "name": "XVR",
//                 "link__name": "XVR",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "SECURITY SYSTEM",
//                 "type": "head",
//                 "other": true,
//                 "topper": "XVR"
//             },
//             {
//                 "name": "CC/IP Camera Accessories",
//                 "link__name": "CC/IP Camera Accessories",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "SECURITY SYSTEM",
//                 "type": "head",
//                 "other": true,
//                 "topper": "CC/IP Camera Accessories"
//             },
//             {
//                 "name": "Smart Lock, Door Bell and Video Door Phone",
//                 "link__name": "Smart Lock, Door Bell and Video Door Phone",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "SECURITY SYSTEM",
//                 "type": "head",
//                 "other": true,
//                 "topper": "Smart Lock, Door Bell and Video Door Phone"
//             },
//             {
//                 "name": "Time Attendance System",
//                 "link__name": "Time Attendance System",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "SECURITY SYSTEM",
//                 "type": "head",
//                 "other": true,
//                 "topper": "Time Attendance System"
//             },
//             {
//                 "name": " Access Control",
//                 "link__name": " Access Control",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "SECURITY SYSTEM",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Time Attendance System"
//             },
//             {
//                 "name": " Access Control Accessories",
//                 "link__name": " Access Control Accessories",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "SECURITY SYSTEM",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Time Attendance System"
//             }
//         ]
//     },
//     {
//         "header": "NETWORK",
//         "img__src": "/laptop.jpg",
//         "link__name": "NETWORK",
//         "links": [
//             {
//                 "name": "Network Router",
//                 "link__name": "Network Router",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "NETWORK",
//                 "type": "head",
//                 "other": true,
//                 "topper": "Network Router"
//             },
//             {
//                 "name": "Access Point",
//                 "link__name": "Access Point",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "NETWORK",
//                 "type": "head",
//                 "other": true,
//                 "topper": "Access Point"
//             },
//             {
//                 "name": "Range Extender",
//                 "link__name": "Range Extender",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "NETWORK",
//                 "type": "head",
//                 "other": true,
//                 "topper": "Range Extender"
//             },
//             {
//                 "name": "Network Switch",
//                 "link__name": "Network Switch",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "NETWORK",
//                 "type": "head",
//                 "other": true,
//                 "topper": "Network Switch"
//             },
//             {
//                 "name": "Lan Card",
//                 "link__name": "Lan Card",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "NETWORK",
//                 "type": "head",
//                 "other": true,
//                 "topper": "Lan Card"
//             },
//             {
//                 "name": "Network Cable",
//                 "link__name": "Network Cable",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "NETWORK",
//                 "type": "head",
//                 "other": true,
//                 "topper": "Network Cable"
//             },
//             {
//                 "name": "Optical Line Termination (OLT)",
//                 "link__name": "Optical Line Termination (OLT)",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "NETWORK",
//                 "type": "head",
//                 "other": true,
//                 "topper": "Optical Line Termination (OLT)"
//             },
//             {
//                 "name": "Optical Network Unit (ONU)",
//                 "link__name": "Optical Network Unit (ONU)",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "NETWORK",
//                 "type": "head",
//                 "other": true,
//                 "topper": "Optical Network Unit (ONU)"
//             },
//             {
//                 "name": "Network Storage",
//                 "link__name": "Network Storage",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "NETWORK",
//                 "type": "head",
//                 "other": true,
//                 "topper": "Network Storage"
//             },
//             {
//                 "name": "Edge Modem",
//                 "link__name": "Edge Modem",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "NETWORK",
//                 "type": "head",
//                 "other": true,
//                 "topper": "Edge Modem"
//             },
//             {
//                 "name": "Network Accessories",
//                 "link__name": "Network Accessories",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "NETWORK",
//                 "type": "head",
//                 "other": true,
//                 "topper": "Network Accessories"
//             },
//             {
//                 "name": " Connector",
//                 "link__name": " Connector",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "NETWORK",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Network Accessories"
//             },
//             {
//                 "name": " Face Plate",
//                 "link__name": " Face Plate",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "NETWORK",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Network Accessories"
//             },
//             {
//                 "name": " Cable Lan",
//                 "link__name": " Cable Lan",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "NETWORK",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Network Accessories"
//             },
//             {
//                 "name": " Crimping Tool",
//                 "link__name": " Crimping Tool",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "NETWORK",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Network Accessories"
//             },
//             {
//                 "name": " Patch Cord",
//                 "link__name": " Patch Cord",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "NETWORK",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Network Accessories"
//             },
//             {
//                 "name": " Management Cable",
//                 "link__name": " Management Cable",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "NETWORK",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Network Accessories"
//             },
//             {
//                 "name": " Patch Panel",
//                 "link__name": " Patch Panel",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "NETWORK",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Network Accessories"
//             },
//             {
//                 "name": " Modular",
//                 "link__name": " Modular",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "NETWORK",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Network Accessories"
//             }
//         ]
//     },
//     {
//         "header": "SOUND SYSTEM",
//         "img__src": "/laptop.jpg",
//         "link__name": "SOUND SYSTEM",
//         "links": [
//             {
//                 "name": "Speaker",
//                 "link__name": "Speaker",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "SOUND SYSTEM",
//                 "type": "head",
//                 "other": true,
//                 "topper": "Speaker"
//             },
//             {
//                 "name": " All Brand",
//                 "link__name": " All Brand",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "SOUND SYSTEM",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Speaker"
//             },
//             {
//                 "name": " F&D",
//                 "link__name": " F&D",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "SOUND SYSTEM",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Speaker"
//             },
//             {
//                 "name": " Xtreme",
//                 "link__name": " Xtreme",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "SOUND SYSTEM",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Speaker"
//             },
//             {
//                 "name": " Edifier",
//                 "link__name": " Edifier",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "SOUND SYSTEM",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Speaker"
//             },
//             {
//                 "name": " Havit",
//                 "link__name": " Havit",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "SOUND SYSTEM",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Speaker"
//             },
//             {
//                 "name": " Digital X",
//                 "link__name": " Digital X",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "SOUND SYSTEM",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Speaker"
//             },
//             {
//                 "name": " Golden Field",
//                 "link__name": " Golden Field",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "SOUND SYSTEM",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Speaker"
//             },
//             {
//                 "name": " Microlab",
//                 "link__name": " Microlab",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "SOUND SYSTEM",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Speaker"
//             },
//             {
//                 "name": " JBL",
//                 "link__name": " JBL",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "SOUND SYSTEM",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Speaker"
//             },
//             {
//                 "name": " Jabra",
//                 "link__name": " Jabra",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "SOUND SYSTEM",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Speaker"
//             },
//             {
//                 "name": " Altec Lansing",
//                 "link__name": " Altec Lansing",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "SOUND SYSTEM",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Speaker"
//             },
//             {
//                 "name": " Fantech",
//                 "link__name": " Fantech",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "SOUND SYSTEM",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Speaker"
//             },
//             {
//                 "name": " Grandstream",
//                 "link__name": " Grandstream",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "SOUND SYSTEM",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Speaker"
//             },
//             {
//                 "name": " Rapoo",
//                 "link__name": " Rapoo",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "SOUND SYSTEM",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Speaker"
//             },
//             {
//                 "name": " Creative",
//                 "link__name": " Creative",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "SOUND SYSTEM",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Speaker"
//             },
//             {
//                 "name": " Bose",
//                 "link__name": " Bose",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "SOUND SYSTEM",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Speaker"
//             },
//             {
//                 "name": " Silicon Power",
//                 "link__name": " Silicon Power",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "SOUND SYSTEM",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Speaker"
//             },
//             {
//                 "name": " Logitech",
//                 "link__name": " Logitech",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "SOUND SYSTEM",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Speaker"
//             },
//             {
//                 "name": " Polycom",
//                 "link__name": " Polycom",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "SOUND SYSTEM",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Speaker"
//             },
//             {
//                 "name": " Micropack",
//                 "link__name": " Micropack",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "SOUND SYSTEM",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Speaker"
//             },
//             {
//                 "name": " Google",
//                 "link__name": " Google",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "SOUND SYSTEM",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Speaker"
//             },
//             {
//                 "name": " Amazon",
//                 "link__name": " Amazon",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "SOUND SYSTEM",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Speaker"
//             },
//             {
//                 "name": " Redragon",
//                 "link__name": " Redragon",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "SOUND SYSTEM",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Speaker"
//             },
//             {
//                 "name": " Marvo",
//                 "link__name": " Marvo",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "SOUND SYSTEM",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Speaker"
//             },
//             {
//                 "name": "Home Theater Systems",
//                 "link__name": "Home Theater Systems",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "SOUND SYSTEM",
//                 "type": "head",
//                 "other": true,
//                 "topper": "Home Theater Systems"
//             },
//             {
//                 "name": "PA System",
//                 "link__name": "PA System",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "SOUND SYSTEM",
//                 "type": "head",
//                 "other": true,
//                 "topper": "PA System"
//             },
//             {
//                 "name": "Headphone",
//                 "link__name": "Headphone",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "SOUND SYSTEM",
//                 "type": "head",
//                 "other": true,
//                 "topper": "Headphone"
//             },
//             {
//                 "name": "Ear Phone",
//                 "link__name": "Ear Phone",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "SOUND SYSTEM",
//                 "type": "head",
//                 "other": true,
//                 "topper": "Ear Phone"
//             },
//             {
//                 "name": "Microphone",
//                 "link__name": "Microphone",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "SOUND SYSTEM",
//                 "type": "head",
//                 "other": true,
//                 "topper": "Microphone"
//             },
//             {
//                 "name": "Sound Card",
//                 "link__name": "Sound Card",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "SOUND SYSTEM",
//                 "type": "head",
//                 "other": true,
//                 "topper": "Sound Card"
//             },
//             {
//                 "name": "Voice Recorder",
//                 "link__name": "Voice Recorder",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "SOUND SYSTEM",
//                 "type": "head",
//                 "other": true,
//                 "topper": "Voice Recorder"
//             },
//             {
//                 "name": "Radio",
//                 "link__name": "Radio",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "SOUND SYSTEM",
//                 "type": "head",
//                 "other": true,
//                 "topper": "Radio"
//             },
//             {
//                 "name": "Musical Instrument",
//                 "link__name": "Musical Instrument",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "SOUND SYSTEM",
//                 "type": "head",
//                 "other": true,
//                 "topper": "Musical Instrument"
//             }
//         ]
//     },
//     {
//         "header": "OFFICE ITEMS",
//         "img__src": "/laptop.jpg",
//         "link__name": "OFFICE ITEMS",
//         "links": [
//             {
//                 "name": "Money Counting Machine",
//                 "link__name": "Money Counting Machine",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "OFFICE ITEMS",
//                 "type": "head",
//                 "other": true,
//                 "topper": "Money Counting Machine"
//             },
//             {
//                 "name": "Cash Register Machine",
//                 "link__name": "Cash Register Machine",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "OFFICE ITEMS",
//                 "type": "head",
//                 "other": true,
//                 "topper": "Cash Register Machine"
//             },
//             {
//                 "name": "Paper Shredder",
//                 "link__name": "Paper Shredder",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "OFFICE ITEMS",
//                 "type": "head",
//                 "other": true,
//                 "topper": "Paper Shredder"
//             },
//             {
//                 "name": "Telephone Set",
//                 "link__name": "Telephone Set",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "OFFICE ITEMS",
//                 "type": "head",
//                 "other": true,
//                 "topper": "Telephone Set"
//             },
//             {
//                 "name": " Land Phone Set",
//                 "link__name": " Land Phone Set",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "OFFICE ITEMS",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Telephone Set"
//             },
//             {
//                 "name": " IP Phone Set",
//                 "link__name": " IP Phone Set",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "OFFICE ITEMS",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Telephone Set"
//             },
//             {
//                 "name": "Fax Machine",
//                 "link__name": "Fax Machine",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "OFFICE ITEMS",
//                 "type": "head",
//                 "other": true,
//                 "topper": "Fax Machine"
//             },
//             {
//                 "name": "Calculator",
//                 "link__name": "Calculator",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "OFFICE ITEMS",
//                 "type": "head",
//                 "other": true,
//                 "topper": "Calculator"
//             }
//         ]
//     },
//     {
//         "header": "STORAGE",
//         "img__src": "/laptop.jpg",
//         "link__name": "STORAGE",
//         "links": [
//             {
//                 "name": "Internal HDD",
//                 "link__name": "Internal HDD",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "STORAGE",
//                 "type": "head",
//                 "other": true,
//                 "topper": "Internal HDD"
//             },
//             {
//                 "name": "Internal SSD",
//                 "link__name": "Internal SSD",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "STORAGE",
//                 "type": "head",
//                 "other": true,
//                 "topper": "Internal SSD"
//             },
//             {
//                 "name": "Internal Server HDD",
//                 "link__name": "Internal Server HDD",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "STORAGE",
//                 "type": "head",
//                 "other": true,
//                 "topper": "Internal Server HDD"
//             },
//             {
//                 "name": "External HDD",
//                 "link__name": "External HDD",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "STORAGE",
//                 "type": "head",
//                 "other": true,
//                 "topper": "External HDD"
//             },
//             {
//                 "name": "External SSD",
//                 "link__name": "External SSD",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "STORAGE",
//                 "type": "head",
//                 "other": true,
//                 "topper": "External SSD"
//             },
//             {
//                 "name": "Pen Drive",
//                 "link__name": "Pen Drive",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "STORAGE",
//                 "type": "head",
//                 "other": true,
//                 "topper": "Pen Drive"
//             },
//             {
//                 "name": "Memory Card",
//                 "link__name": "Memory Card",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "STORAGE",
//                 "type": "head",
//                 "other": true,
//                 "topper": "Memory Card"
//             },
//             {
//                 "name": "HDD Case",
//                 "link__name": "HDD Case",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "STORAGE",
//                 "type": "head",
//                 "other": true,
//                 "topper": "HDD Case"
//             },
//             {
//                 "name": "Card Reader",
//                 "link__name": "Card Reader",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "STORAGE",
//                 "type": "head",
//                 "other": true,
//                 "topper": "Card Reader"
//             }
//         ]
//     },
//     {
//         "header": "ACCESSORIES",
//         "img__src": "/laptop.jpg",
//         "link__name": "ACCESSORIES",
//         "links": [
//             {
//                 "name": "Cable",
//                 "link__name": "Cable",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "ACCESSORIES",
//                 "type": "head",
//                 "other": true,
//                 "topper": "Cable"
//             },
//             {
//                 "name": " HDMI Cable",
//                 "link__name": " HDMI Cable",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "ACCESSORIES",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Cable"
//             },
//             {
//                 "name": " VGA Cable",
//                 "link__name": " VGA Cable",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "ACCESSORIES",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Cable"
//             },
//             {
//                 "name": " Lightning Cable",
//                 "link__name": " Lightning Cable",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "ACCESSORIES",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Cable"
//             },
//             {
//                 "name": " USB Cable",
//                 "link__name": " USB Cable",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "ACCESSORIES",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Cable"
//             },
//             {
//                 "name": " Audio Cable",
//                 "link__name": " Audio Cable",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "ACCESSORIES",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Cable"
//             },
//             {
//                 "name": " Sata Cable",
//                 "link__name": " Sata Cable",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "ACCESSORIES",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Cable"
//             },
//             {
//                 "name": " Display Port Cable",
//                 "link__name": " Display Port Cable",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "ACCESSORIES",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Cable"
//             },
//             {
//                 "name": "Converter",
//                 "link__name": "Converter",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "ACCESSORIES",
//                 "type": "head",
//                 "other": true,
//                 "topper": "Converter"
//             },
//             {
//                 "name": " HDMI Converter",
//                 "link__name": " HDMI Converter",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "ACCESSORIES",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Converter"
//             },
//             {
//                 "name": " VGA Converter",
//                 "link__name": " VGA Converter",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "ACCESSORIES",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Converter"
//             },
//             {
//                 "name": " USB HUB",
//                 "link__name": " USB HUB",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "ACCESSORIES",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Converter"
//             },
//             {
//                 "name": " Audio Converter",
//                 "link__name": " Audio Converter",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "ACCESSORIES",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Converter"
//             },
//             {
//                 "name": " Bluetooth Adapter",
//                 "link__name": " Bluetooth Adapter",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "ACCESSORIES",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Converter"
//             },
//             {
//                 "name": " Type-C Converter",
//                 "link__name": " Type-C Converter",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "ACCESSORIES",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Converter"
//             },
//             {
//                 "name": " Lightning Converter",
//                 "link__name": " Lightning Converter",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "ACCESSORIES",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Converter"
//             },
//             {
//                 "name": " USB Converter",
//                 "link__name": " USB Converter",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "ACCESSORIES",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Converter"
//             },
//             {
//                 "name": " Display Port Converter",
//                 "link__name": " Display Port Converter",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "ACCESSORIES",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Converter"
//             },
//             {
//                 "name": " DVI Converter",
//                 "link__name": " DVI Converter",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "ACCESSORIES",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Converter"
//             },
//             {
//                 "name": "Electrical Power",
//                 "link__name": "Electrical Power",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "ACCESSORIES",
//                 "type": "head",
//                 "other": true,
//                 "topper": "Electrical Power"
//             },
//             {
//                 "name": " Power Strip",
//                 "link__name": " Power Strip",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "ACCESSORIES",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Electrical Power"
//             },
//             {
//                 "name": " Power Adapter",
//                 "link__name": " Power Adapter",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "ACCESSORIES",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Electrical Power"
//             },
//             {
//                 "name": " Blower",
//                 "link__name": " Blower",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "ACCESSORIES",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Electrical Power"
//             },
//             {
//                 "name": " Power Cable",
//                 "link__name": " Power Cable",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "ACCESSORIES",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Electrical Power"
//             },
//             {
//                 "name": "Premium Accessories",
//                 "link__name": "Premium Accessories",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "ACCESSORIES",
//                 "type": "head",
//                 "other": true,
//                 "topper": "Premium Accessories"
//             },
//             {
//                 "name": " Apple Accessories",
//                 "link__name": " Apple Accessories",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "ACCESSORIES",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Premium Accessories"
//             },
//             {
//                 "name": " Microsoft Accessories",
//                 "link__name": " Microsoft Accessories",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "ACCESSORIES",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Premium Accessories"
//             },
//             {
//                 "name": " Digital Pen",
//                 "link__name": " Digital Pen",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "ACCESSORIES",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Premium Accessories"
//             },
//             {
//                 "name": " Power & Charger",
//                 "link__name": " Power & Charger",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "ACCESSORIES",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Premium Accessories"
//             },
//             {
//                 "name": "Bag",
//                 "link__name": "Bag",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "ACCESSORIES",
//                 "type": "head",
//                 "other": true,
//                 "topper": "Bag"
//             }
//         ]
//     },
//     {
//         "header": "SOFTWARE",
//         "img__src": "/laptop.jpg",
//         "link__name": "SOFTWARE",
//         "links": [
//             {
//                 "name": "Antivirus and Security",
//                 "link__name": "Antivirus and Security",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "SOFTWARE",
//                 "type": "head",
//                 "other": true,
//                 "topper": "Antivirus and Security"
//             },
//             {
//                 "name": "Office Application",
//                 "link__name": "Office Application",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "SOFTWARE",
//                 "type": "head",
//                 "other": true,
//                 "topper": "Office Application"
//             },
//             {
//                 "name": "Operating System and DB",
//                 "link__name": "Operating System and DB",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "SOFTWARE",
//                 "type": "head",
//                 "other": true,
//                 "topper": "Operating System and DB"
//             },
//             {
//                 "name": "Graphics Design",
//                 "link__name": "Graphics Design",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "SOFTWARE",
//                 "type": "head",
//                 "other": true,
//                 "topper": "Graphics Design"
//             },
//             {
//                 "name": "Engineering Design",
//                 "link__name": "Engineering Design",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "SOFTWARE",
//                 "type": "head",
//                 "other": true,
//                 "topper": "Engineering Design"
//             },
//             {
//                 "name": "Bangla Typing Application",
//                 "link__name": "Bangla Typing Application",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "SOFTWARE",
//                 "type": "head",
//                 "other": true,
//                 "topper": "Bangla Typing Application"
//             }
//         ]
//     },
//     {
//         "header": "DAILY LIFE",
//         "img__src": "/laptop.jpg",
//         "link__name": "DAILY LIFE",
//         "links": [
//             {
//                 "name": "Smartwatch",
//                 "link__name": "Smartwatch",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "DAILY LIFE",
//                 "type": "head",
//                 "other": true,
//                 "topper": "Smartwatch"
//             },
//             {
//                 "name": " Apple",
//                 "link__name": " Apple",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "DAILY LIFE",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Smartwatch"
//             },
//             {
//                 "name": " Kieslect",
//                 "link__name": " Kieslect",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "DAILY LIFE",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Smartwatch"
//             },
//             {
//                 "name": " Havit",
//                 "link__name": " Havit",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "DAILY LIFE",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Smartwatch"
//             },
//             {
//                 "name": " Xiaomi",
//                 "link__name": " Xiaomi",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "DAILY LIFE",
//                 "type": "link",
//                 "other": false,
//                 "topper": "Smartwatch"
//             },
//             {
//                 "name": "Sewing Machine",
//                 "link__name": "Sewing Machine",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "DAILY LIFE",
//                 "type": "head",
//                 "other": true,
//                 "topper": "Sewing Machine"
//             },
//             {
//                 "name": "TV and Video Streaming",
//                 "link__name": "TV and Video Streaming",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "DAILY LIFE",
//                 "type": "head",
//                 "other": true,
//                 "topper": "TV and Video Streaming"
//             },
//             {
//                 "name": " Smart TV",
//                 "link__name": " Smart TV",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "DAILY LIFE",
//                 "type": "link",
//                 "other": false,
//                 "topper": "TV and Video Streaming"
//             },
//             {
//                 "name": " TV Streaming",
//                 "link__name": " TV Streaming",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "DAILY LIFE",
//                 "type": "link",
//                 "other": false,
//                 "topper": "TV and Video Streaming"
//             },
//             {
//                 "name": " TV Card",
//                 "link__name": " TV Card",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "DAILY LIFE",
//                 "type": "link",
//                 "other": false,
//                 "topper": "TV and Video Streaming"
//             },
//             {
//                 "name": " Game Streaming",
//                 "link__name": " Game Streaming",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "DAILY LIFE",
//                 "type": "link",
//                 "other": false,
//                 "topper": "TV and Video Streaming"
//             }
//         ]
//     },
//     {
//         "header": "POS SYSTEM",
//         "img__src": "/laptop.jpg",
//         "link__name": "POS SYSTEM",
//         "links": [
//             {
//                 "name": "POS SYSTEM",
//                 "link__name": "POS SYSTEM",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "POS SYSTEM",
//                 "type": "link",
//                 "other": false,
//                 "topper": "TV and Video Streaming"
//             }
//         ]
//     }
// ]
// let items = [];

// AllDigitalNavLinks.forEach((info, index) => {
//     info.links.forEach((info, index) => {
//         items.push(info)
//     })
// })

/// link array to items converter end
