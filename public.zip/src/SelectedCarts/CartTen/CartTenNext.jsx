import { faCartShopping } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import React from 'react';
import { images } from '../../../Images';

const CartTenNext = () => {
    return (
        <div className='cart__ten__container__nxt'>
                <div className="image__container">
                    <img src={"/CartImages/"+images[Math.ceil(Math.random()*11)]} alt="" />
                </div>
                <div className="info__container">
                    <p className="price">$ 300.00</p>
                    <button><FontAwesomeIcon icon={faCartShopping}/></button>
                </div>
        </div>
    );
};

export default CartTenNext;