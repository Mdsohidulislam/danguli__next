import { faCartShopping, faHeart, faScaleBalanced } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import React from 'react';
import { images } from '../../../Images';
const CartOneDemoNext = () => { 
    
    return (
        <div className='main__cart__container__long__product__next'>
            <div className="container">
                <div className="image__container">  
                <img src={"/CartImages/"+images[Math.ceil(Math.random()*11)]} alt='product'/>
                </div>
                <div className="title__container">
                        <div className="left__container">
                            <p>⭐⭐⭐⭐⭐</p>
                        </div>
                        <div className="right__container">
                            <p>৳ <span> 1000.00</span></p>
                        </div>
                </div>
                <div className="inf__body">
                    <div className="intro__container">
                        <p className='title'>TP-Link L920-5 Multi-Colour Smart Wi-Fi Light Strip 5m and</p> 
                        <p className='brand'>Lenovo</p>
                    </div>
                    <div className="button__container">
                        <button ><FontAwesomeIcon icon={faCartShopping}/></button>
                        <button ><FontAwesomeIcon icon={faHeart}/></button>
                        <button ><FontAwesomeIcon icon={faScaleBalanced}/></button> 
                    </div>
                </div>
            </div>
        </div>
    );
};

export default CartOneDemoNext;