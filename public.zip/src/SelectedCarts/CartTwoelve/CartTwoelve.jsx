import { images } from '../../Images';

const CartTwoelve = () => {
    return (
        <div className='cart__twoelve__container'> 
            <div className="image__container">
                <img src={"/CartImages/"+images[Math.ceil(Math.random()*11)]} alt="" />
                
            </div>
            <div className="info__container"> 
                <p className="product__title">HP</p>
                <div className="price">$ 100.00</div>
                <hr className="middle" /> 
                <p className="product__uses">HP Enterprise M554dn Single Function Color Laser Printer</p>
                
            </div>
        </div>
    );
};

export default CartTwoelve;