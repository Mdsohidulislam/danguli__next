import { faCartShopping, faHeart, faMagnifyingGlass } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import React from 'react';
import { images } from '../../../Images';

const CartTwoelveNext = () => {
    return (
        <div className='cart__twoelve__container__next'> 
            <div className="image__container">
                <img src={"/CartImages/"+images[Math.ceil(Math.random()*11)]} alt="" />
                <div className="button__container">
                <button><FontAwesomeIcon icon={faCartShopping}/></button>
                <button><FontAwesomeIcon icon={faHeart}/></button>
                <button><FontAwesomeIcon icon={faMagnifyingGlass}/></button> 
            </div>
            </div>
            <div className="info__container"> 
                <p className="product__title">HP</p>
                <div className="price">$ 100.00</div>
                <hr className="middle" /> 
                <p className="product__uses">HP Enterprise M554dn Single Function Color Laser Printer</p>
                
            </div>
        </div>
    );
};

export default CartTwoelveNext;