import CartChowddo from "../CartChowddo/CartChowddo";
import CartEight from "../CartEight/CartEight";
import CartElevenDemo from "../CartEleven/CartElevenDemo";
import CartFive from "../CartFive/CartFive";
import CartFour from "../CartFour/CartFour";
import CartNine from "../CartNine/CartNine";
import CartOneDemo from "../CartOne/CartOneDemo";
import CartTen from "../CartTen/CartTen";
import CartThero from "../CartThero/CartThero";
import CartTwo from "../CartTwo/CartTwo";
import CartTwoelve from "../CartTwoelve/CartTwoelve";

function CartShow () {

    const numbers = [0,1,3,4,5]
    return (
      <div className="view__carts__container">  
    
        <div className='cartRowContainer'>
          <div className='title__container'>
            <h1>Demo Shopping Cart 4</h1>
          </div>
          <div className='cart__container'> 
            <CartChowddo/>
            <CartChowddo/>
            <CartChowddo/>
            <CartChowddo/>
            <CartChowddo/>
          </div>
        </div> 
        <div className='cartRowContainer'>
          <div className='title__container'>
            <h1>Demo Shopping Cart 6</h1>
          </div>
          <div className='cart__container'> 
            <CartEight/>
            <CartEight/>
            <CartEight/>
            <CartEight/>
            <CartEight/>
          </div>
        </div> 
        <div className='cartRowContainer'>
          <div className='title__container'>
            <h1>Demo Shopping Cart 8</h1>
          </div>
          <div className='cart__container'> 
            <CartElevenDemo/>
            <CartElevenDemo/>
            <CartElevenDemo/>
            <CartElevenDemo/>
            <CartElevenDemo/>
          </div>
        </div> 
        <div className='cartRowContainer'>
          <div className='title__container'>
            <h1>Demo Shopping Cart 10</h1>
          </div> 
          <div className='cart__container'> 
              {
                numbers.map((info, index) => {
                  return <CartFive key={index} param={index}/>
                })
              }
          </div>
        </div> 
        <div className='cartRowContainer'>
          <div className='title__container'>
            <h1>Demo Shopping Cart 12</h1>
          </div>
          <div className='cart__container'> 
          {
              numbers.map((info, index) => {
                      return <CartFour key={index+ Math.random()*20} param={index+ Math.random()*20}/>
                    })
              }
          </div>
        </div> 
        <div className='cartRowContainer'>
          <div className='title__container'>
            <h1>Demo Shopping Cart 14</h1>
          </div>
          <div className='cart__container'> 
                <CartNine/>
                <CartNine/>
                <CartNine/>
                <CartNine/>
                <CartNine/>
          </div>
        </div> 
        <div className='cartRowContainer'>
          <div className='title__container'>
            <h1>Demo Shopping Cart 16</h1>
          </div>
          <div className='cart__container'> 
                <CartOneDemo/>
                <CartOneDemo/>
                <CartOneDemo/>
                <CartOneDemo/>
                <CartOneDemo/>
          </div>
        </div>  
        <div className='cartRowContainer'>
          <div className='title__container'>
            <h1>Demo Shopping Cart 21</h1>
          </div>
          <div className='cart__container'>  
            <CartTen/>
            <CartTen/>
            <CartTen/>
            <CartTen/>
            <CartTen/>
          </div>
        </div> 
        <div className='cartRowContainer'>
          <div className='title__container'>
            <h1>Demo Shopping Cart 23</h1>
          </div>
          <div className='cart__container'>  
                <CartThero/>
                <CartThero/>
                <CartThero/>
                <CartThero/>
                <CartThero/>
          </div>
        </div>  
        <div className='cartRowContainer'>
          <div className='title__container'>
            <h1>Demo Shopping Cart 26</h1>
          </div>
          <div className='cart__container'> 
                <CartTwo/>
                <CartTwo/>
                <CartTwo/>
                <CartTwo/>
                <CartTwo/>
          </div>
        </div> 
        <div className='cartRowContainer'>
          <div className='title__container'>
            <h1>Demo Shopping Cart 28</h1>
          </div>
          <div className='cart__container'>  
                <CartTwoelve/>
                <CartTwoelve/>
                <CartTwoelve/>
                <CartTwoelve/>
                <CartTwoelve/>
          </div>
        </div> 
      </div>
    );
  }
  
  export default CartShow;