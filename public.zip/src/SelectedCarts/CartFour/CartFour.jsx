import { faCartShopping, faCircleInfo, faHeart, faMagnifyingGlass, faXmark } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { images } from '../../Images';

const CartFour = ({param}) => {

    const handleOpen = () => {
        let element = document.getElementById('one' + param);
        element.classList.toggle('active__four__cart');
        
    }

    const  handleAdd = () => {
        document.getElementById('added'+param).classList.toggle('active')
        setTimeout(()=>{
            document.getElementById('added'+param).classList.toggle('active')
        },1000)
    }
    
    return (
        <div className='cart__four__container'>
            <div className="details__cart__area" id={'one'+param}>
            <p className='brand'>Appollo</p>
                <p className='productDetails'>Customize your Blue 24-inch iMac with apple M! chip</p>
                <p className="review">⭐⭐⭐⭐⭐</p>
                <div className="price__container">
                    <p className="prev__price">$ 222000</p>
                    <p className="current__price">$ 200000</p>
                </div>

                <div className="button__container">
                    <button><FontAwesomeIcon icon={faCartShopping}/></button>
                    <button><FontAwesomeIcon icon={faHeart}/></button>
                    <button><FontAwesomeIcon icon={faMagnifyingGlass}/></button> 
                </div>
                <button className='toggle__button__close' onClick={handleOpen}><FontAwesomeIcon icon={faXmark}/> </button>
                <button className='toggle__button__open' onClick={handleOpen}><FontAwesomeIcon icon={faCircleInfo}/></button>
            </div>
            <div className="image__container">
                <img src={"/CartImages/"+images[Math.ceil(Math.random()*11)]} alt="" />
            </div>
            <div className="info__container" id={'added' + param}>
                <div className="visible">
                    <div className="left__container">
                        <p className='bag__name'>LOTTO</p>
                        <p className="bag__price">$ 900</p>
                        
                    </div>
                    <div className="right__container" onClick={handleAdd}> 
                    <FontAwesomeIcon icon={faCartShopping}/>
                    </div>
                </div>
                <div className="hidden">
                    <div className="right__container" onClick={handleAdd}> 
                    <FontAwesomeIcon icon={faXmark}/>
                    </div>
                    <div className="left__container">
                            <p className='bag__name'>LOTTO</p>
                            <p className="added__message">Added to your cart</p>
                            
                    </div>
                </div>
            </div>
        </div>
    );
};

export default CartFour;

// ❌