import { useContext, useEffect, useState } from 'react';
import {
  Route, Switch
} from "react-router-dom";
import CartPage from './Components/CartPage/CartPage';
import Footer from './Components/Footer/Footer';
import FooterBanner from './Components/FooterBanner/FooterBanner';
import HelpFooter from './Components/FooterBanner/HelpFooter';
import ImageMagnifier from './Components/ImageZoom/ImageMagnifier';
import MultipleImageUpload from './Components/MultipleImageUpload/MultipleImageUpload';
import ParentProduct from './Components/ParentProduct/ParentProduct';
import { ProductDetails } from './Components/ProductDetails/ProductDetails';
import ProductTopHeader from './Components/ProductTopHeader/ProductTopHeader';
import CartBox from './Components/SideBar/CartBox';
import TopNavbar from './Components/TopNavbar/TopNavbar';
import TopSmallNavbar from './Components/TopNavbar/TopSmallNavbar';
import UserExpectation from './Components/UserExpectation/UserExpectation';
import UserGuideInput from './Components/UserGuideOption/UserGuideInput';
import UserGuideOption from './Components/UserGuideOption/UserGuideOption';
import { ChildProductsViews } from './Components/Views/ChildProductsViews/ChildProductViews';
import { ParentFatherProductsViews } from './Components/Views/ParentFatherProductsViews/ParentFatherProductsViews';
import { ParentProductsViews } from './Components/Views/ParentProductsViews/ParentProductsViews';

import BrandsCategories from './Components/BrandsCategories/BrandsCategories';
import Carousell from './Components/Carousel/Carousel';
import FeaturedCategories from './Components/FeaturedCategories/FeaturedCategories';
import HelpAnywhere from './Components/HelpAnywhere/HelpAnywhere';
import BestRated from './Components/HomePagerSliders/BestRated';
import EverydayEssentials from './Components/HomePagerSliders/EverydayEssentials';
import FeaturedProducts from './Components/HomePagerSliders/FeaturedProducts';
import HighLightOfTheWeek from './Components/HomePagerSliders/HighLightOfTheWeek';
import PreOrder from './Components/HomePagerSliders/PreOrder';
import RecentlyAdded from './Components/HomePagerSliders/RecentlyAdded';
import Recommended from './Components/HomePagerSliders/Recommended';
import UpgradeYourGamingStation from './Components/HomePagerSliders/UpgradeYourGamingStation';
import HomeImageGridView from './Components/ImageGrid/HomeImageGridView';
import MoreSave from './Components/MoreSave/MoreSave';
import OwenerFeatures from './Components/OwenerFeatures/OwenerFeatures';
import PrintHomeBanner from './Components/PrintHomeBanner/PrintHomeBanner';
import TechSuccess from './Components/TechSuccess/TechSuccess';

import axios from 'axios';
import { uid } from 'uid';
import InnovatedGadget from './Components/HomePagerSliders/InnovatedGadget';
import QuickView from './Components/QuickView/QuickView';
import AllBrandViews from './Components/Views/AllBrandViews/AllBrandViews';
import AllCategoriesViews from './Components/Views/AllCategoryViews/AllCategoryViews';
import BrandViews from './Components/Views/BrandViews/BrandViews';
import CategoryViews from './Components/Views/CategoryViews/CategoryViews';
import AllOfferViews from './Components/Views/OfferViews/AllOfferViews';
import OfferViews from './Components/Views/OfferViews/OfferViews';
import WishList from './Components/WishList/WishList';
import { danguliContext } from './DanguliContext';
import CartShow from './SelectedCarts/CartShow/CartShow';
import { serverHelper } from './UTILS/ServerUtils';
import { utilsHelper } from './UTILS/utils';
const DanguliRouter = () => {
    const {showOption,  showUpdateInput,   updateInfos, topCategoryCollection, setTopCategoryCollection} = useContext(danguliContext);
    const [mostPopularProducts, setMostPopularProducts] = useState([]);
    const [newArrivalProducts, setNewArrivalProducts] = useState([]);
    const [recommendedProducts, setRecommendedProducts]  = useState([]);
    const [everydayEssentials, setEverydayEssentials] = useState([])
    const [upgradeYourGamingStation, setUpgradeYourGamingStation] = useState([])
    const [freeShipping, setFreeShipping] = useState([])
    const [recommended, setRecommended] = useState([])
    const [recentlyAdded, setRecentlyAdded] = useState([]);
    const [high__light__of__the__week, setHigh__light__of__the__week] = useState([]);
    const [preOrder, setPreOrder] = useState([]);
    const [bestRated, setBestRated] = useState([]);
    const [flashSale, setFlashSale] = useState([]);
    const [featuredProducts, setFeaturedProducts] = useState([]);
    const [innovatedGadget, setInnovatedGadget] = useState([]);

  

  useEffect(()=>{
    getAllRMN();
    getOrSetUserId();
    getAllOfferProducts();
  },[])   
  const getOrSetUserId = () => {
    let user__id  = localStorage.getItem('user__key');
    if(user__id){ 
    }else{
      localStorage.setItem('user__key', utilsHelper.timeManagements.momentTimeMaker()+uid(15))
    let user__id  = localStorage.getItem('user__key');
      console.log({user__id});
    }
  }
  
  const getAllOfferProducts = () => {
    axios.get('http://localhost:3009/getSingleOfferCategoryData')
    .then(res =>{
      if(res.data.status__code === 200){
        // let suffleArray = res.data.product.sort(()=> Math.random() - 0.5)
        // setEverydayEssentials(suffleArray)
        console.log(res);
      }
    }).catch(err => {
      console.log(err.message);
    }) 
  }
    const getAllRMN = () => {
      serverHelper.getAllCollectionForRecommendedNewMost().then(res  =>  {
          let { recommended , newArrivals , mostPopular} = res; 
          // setRecommendedProducts(recommended);
          // setNewArrivalProducts(newArrivals);
          // setMostPopularProducts(mostPopular);
      }).catch(err => {
          console.log(err.message);
      })
  }
    return (
            <Switch>
              <Route path='/cart'> 
              <TopNavbar/>
              <TopSmallNavbar/>
                  <CartBox/>
                  <CartPage/>  
                  <FooterBanner/>
                  <HelpFooter/>
              </Route> 
              <Route path='/upload'>
                <MultipleImageUpload/>
              </Route>
              <Route path='/userGuide'> 
                  <UserGuideOption/>
                  <UserGuideInput/>
              </Route> 
              <Route path='/wishlist'>     
                <TopSmallNavbar/>
                <TopNavbar/>
                <CartBox/>
                <WishList/> 
                <FooterBanner/>
                <HelpFooter/>    
                <Footer/>
              </Route> 
              <Route path='/category/:link__name/:parent/:other/:subCategory'>
                  <CartBox/>
                  <UserExpectation/> 
                  <HelpFooter/> 
              </Route> 
              
              <Route path='/childProducts'>
              {showUpdateInput? <UserGuideInput infos={updateInfos}/> : ""}
              {showOption? <UserGuideOption infos={updateInfos}/> :  ""}
                <CartBox/>
                <ChildProductsViews/> 
              </Route> 
              <Route path='/server'>
                  <h1>Hello world</h1>
              </Route> 
              <Route path='/parentProducts'>  
              {showUpdateInput? <UserGuideInput infos={updateInfos}/> : ""}
              {showOption? <UserGuideOption infos={updateInfos}/> :  ""}
                <CartBox/>
                <ParentProductsViews/> 
              </Route>     
              
              <Route path='/allProducts'>  
              {showUpdateInput? <UserGuideInput infos={updateInfos}/> : ""}
              {showOption? <UserGuideOption infos={updateInfos}/> :  ""}
                <CartBox/>
                <ParentFatherProductsViews/> 
              </Route> 
              <Route path='/product/details/:url'>
                  <TopSmallNavbar/>
                  <TopNavbar/>
                  <CartBox/>
                  {/*<CheckDetails/>*/} 
                  <ProductDetails/>
                  <div style={{height:'4000px'}}></div>
                  <FooterBanner/>
                  <HelpFooter/>
              </Route>
              <Route exact path='/newImageMagnifier'>
                  <ImageMagnifier/>
              </Route>
              <Route exact path='/'>   
              <TopSmallNavbar/>
              <TopNavbar/>
              <CartBox/>    
              <div>    
            <div className='final__landing__page__container__with__production'>
                <Carousell/>  
                {upgradeYourGamingStation.length ? <UpgradeYourGamingStation products={upgradeYourGamingStation}/> : ''}

                <FeaturedCategories/> 
                {everydayEssentials.length ? <EverydayEssentials products={everydayEssentials}/> : ''}


                <BrandsCategories/>  
                {recentlyAdded.length ? <RecentlyAdded products={recentlyAdded}/> : ''}

                <OwenerFeatures/>
                {high__light__of__the__week.length ? <HighLightOfTheWeek products={high__light__of__the__week}/> : ''}
                {recommended.length ? <Recommended products={recommended}/> : ''}
                <MoreSave/> 
                {preOrder.length ? <PreOrder products={preOrder}/> : ''}

                <TechSuccess/> 
                {bestRated.length ? <BestRated products={bestRated}/> : ''}

                <HelpAnywhere/>  

                <PrintHomeBanner/> 

                {featuredProducts.length ? <FeaturedProducts products={featuredProducts}/> : ''}

                <HomeImageGridView/> 
                {innovatedGadget.length ? <InnovatedGadget products={innovatedGadget}/> : ''}

            </div> 
            <FooterBanner/>
            <HelpFooter/>
            <Footer/>
        </div>
            </Route>
            <Route exact path='/allCarts'>   
                <CartShow/>
            </Route> 
            
            <Route exact path='/quickView'>   
                <QuickView/>
            </Route> 
            <Route exact path='/allBrands'>   
                <AllBrandViews/>
            </Route> 
            <Route exact path='/allOffers'>   
                <AllOfferViews/>
            </Route>
            <Route exact path='/allCategories'>   
                <AllCategoriesViews/>
            </Route>
            <Route exact path='/allBrands/:brand'>   
                <BrandViews/>
            </Route> 
            <Route exact path='/allOffers/:offer'>   
                <OfferViews/>
            </Route> 
            <Route exact path='/allCategories/:category'>   
                <CategoryViews/>
            </Route>
            <Route exact path='/:urls'>  
                <ImageMagnifier/> 
            </Route>
            
            <Route path='/productTopHeader'>  
                <ProductTopHeader/>
            </Route>
            <Route exact path='/parent'>
            <TopSmallNavbar/>
            <TopNavbar/>
              <ParentProduct/>
            </Route> 
          </Switch> 
    );
};

export default DanguliRouter; 