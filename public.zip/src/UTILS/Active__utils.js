
const active__utils = {}

active__utils.active__cart = () => {
    document.getElementById('my__side__small__cart').classList.toggle('active');
    document.querySelector('body').classList.toggle('active')
}


export default active__utils;

