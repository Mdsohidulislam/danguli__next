 
    let product = []; 
    let brandCollection = [];
    let brandIdCollection = []; 
    let typeCollection = [];
    let typeIdCollection = [];

    result.forEach((newInfo) => {
        let info = {...newInfo};
        info.infos = bufferDataConverter(newInfo.infos);  
            product.push(info); 
            
            if(brandCollection.indexOf(info.class) === -1){
                brandCollection.push(info.class);
                brandIdCollection.push([info]);
            }else{
                let brandIndex = brandCollection.indexOf(info.class);
                    brandIdCollection[brandIndex].push(info)
            } 

    })  
    let brandDataset = []; 
    brandCollection.forEach((info, index) => {
        brandDataset.push([info, brandIdCollection[index]])
    }) 

    res.status(200).send({ product, brandDataset ,status__code: 200});
 