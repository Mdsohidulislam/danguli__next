// let allLinks =[ 
//     {
//         "header": "LAPTOP",
//         "img__src": "/laptop.jpg",
//         "link__name": "LAPTOP",
//         "links": [
//             {
//                 "name": "All Laptop",
//                 "link__name": "Laptop",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "LAPTOP",
//                 "type": "head",
//                 "other": false
//             },
//             {
//                 "name": "Apple",
//                 "link__name": "Apple",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "LAPTOP",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Asus",
//                 "link__name": "Asus",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "LAPTOP",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Acer",
//                 "link__name": "Acer",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "LAPTOP",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Avita",
//                 "link__name": "Avita",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "LAPTOP",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Dell",
//                 "link__name": "Dell",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "LAPTOP",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Chuwi",
//                 "link__name": "Chuwi",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "LAPTOP",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "HP",
//                 "link__name": "HP",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "LAPTOP",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Huawei",
//                 "link__name": "Huawei",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "LAPTOP",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "i-Life",
//                 "link__name": "i-Life",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "LAPTOP",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Lenovo",
//                 "link__name": "Lenovo",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "LAPTOP",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Microsoft",
//                 "link__name": "Microsoft",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "LAPTOP",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "MSI",
//                 "link__name": "MSI",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "LAPTOP",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Nexstgo",
//                 "link__name": "Nexstgo",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "LAPTOP",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Razer",
//                 "link__name": "Razer",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "LAPTOP",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Gigabyte",
//                 "link__name": "Gigabyte",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "LAPTOP",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Accessories",
//                 "link__name": "Accessories",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Accessories",
//                 "type": "head",
//                 "other": true
//             },
//             {
//                 "name": "Laptop Ram",
//                 "link__name": "Laptop Ram",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "LAPTOP",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Laptop Cooler",
//                 "link__name": "Laptop Cooler",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "LAPTOP",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Caddy",
//                 "link__name": "Caddy",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "LAPTOP",
//                 "type": "link",
//                 "other": "edit"
//             },
//             {
//                 "name": "Laptop Bag",
//                 "link__name": "Bags",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "LAPTOP",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Stand",
//                 "link__name": "Laptop Stand",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "LAPTOP",
//                 "type": "link",
//                 "other": "edit"
//             },
//             {
//                 "name": "Battery",
//                 "link__name": "Battery",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "LAPTOP",
//                 "type": "link",
//                 "other": "edit"
//             },
//             {
//                 "name": "Adapter",
//                 "link__name": "Laptop Adapter",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "LAPTOP",
//                 "type": "link",
//                 "other": false
//             }
//         ]
//     },
//     {
//         "header": "DESKTOP PC AND SERVER",
//         "img__src": "/laptop.jpg",
//         "link__name": "Brand PC",
//         "links": [
//             {
//                 "name": "Desktop PC",
//                 "link__name": "Brand PC Mini PC All in All",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Brand PC",
//                 "type": "head",
//                 "other": true
//             },
//             {
//                 "name": "Brand Desktop PC",
//                 "link__name": "Brand PC",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Brand PC",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "All In One PC",
//                 "link__name": "All in One",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "All in One",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Mini PC",
//                 "link__name": "Mini PC",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Mini PC",
//                 "type": "link",
//                 "other": 'edit'
//             },
//             {
//                 "name": "Danguli PC",
//                 "link__name": "Ryans",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Desktop",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Desktop Component",
//                 "link__name": "Desktop Component",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "______________",
//                 "type": "head",
//                 "other": true
//             },
//             {
//                 "name": "Processor",
//                 "link__name": "Processor",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Processor",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Motherboard",
//                 "link__name": "Motherboard",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Motherboard",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Desktop Ram",
//                 "link__name": "Desktop Ram",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Desktop Ram",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Optical Device",
//                 "link__name": "Optical Device",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Optical Device",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Graphics Card",
//                 "link__name": "Graphics Card",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Graphics Card",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Power Supply",
//                 "link__name": "Power Supply",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Power Supply",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Casing",
//                 "link__name": "Casing",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Casing",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Casing Fan and Accessories",
//                 "link__name": "Casing Fan and Accessories",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Casing Fan and Accessories",
//                 "type": "link",
//                 "other": "edit"
//             },
//             {
//                 "name": "CPU Cooler",
//                 "link__name": "CPU Cooler",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "CPU Cooler",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Keyboard",
//                 "link__name": "Keyboard",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Keyboard",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Mouse",
//                 "link__name": "Mouse",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Mouse",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Keyboard and Mouse Combo",
//                 "link__name": "Keyboard & Mouse",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Keyboard & Mouse",
//                 "type": "link",
//                 "other": "edit"
//             },
//             {
//                 "name": "Mouse Pad",
//                 "link__name": "Mouse Pad",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Mouse Pad",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "UPS",
//                 "link__name": "UPS",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "UPS",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Server",
//                 "link__name": "Server",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Server",
//                 "type": "head",
//                 "other": false
//             },
//             {
//                 "name": "Rack",
//                 "link__name": "Rack",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Rack",
//                 "type": "link",
//                 "other": 'edit'
//             },
//             {
//                 "name": "Tower",
//                 "link__name": "Tower",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Tower",
//                 "type": "link",
//                 "other": 'edit'
//             },
//             {
//                 "name": "Server Component",
//                 "link__name": "Server Component",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "______________",
//                 "type": "head",
//                 "other": true
//             },
//             {
//                 "name": "Server Cabinet",
//                 "link__name": "Server Cabinet",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Server Cabinet",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Server Ram",
//                 "link__name": "Server Ram",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Server Ram",
//                 "type": "link",
//                 "other": "edit"
//             },
//             {
//                 "name": "Desktop Accessories",
//                 "link__name": "Desktop Accessories",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "______________",
//                 "type": "head",
//                 "other": true
//             },
//             {
//                 "name": "LED Strip",
//                 "link__name": "Casing Fan and Accessories",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Casing Fan and Accessories",
//                 "type": "link",
//                 "other": 'edit'
//             },
//             {
//                 "name": "Casing Accessories",
//                 "link__name": "Casing Accessories",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Casing Accessories",
//                 "type": "link",
//                 "other": 'edit'
//             },
//             {
//                 "name": "Side Panel",
//                 "link__name": "Side Panel",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Side Panel",
//                 "type": "link",
//                 "other": 'edit'
//             },
//             {
//                 "name": "Thermal Paste",
//                 "link__name": "Thermal Paste",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Thermal Paste",
//                 "type": "link",
//                 "other": 'edit'
//             }
//         ]
//     },
//     {
//         "header": "GAMING",
//         "img__src": "/laptop.jpg",
//         "link__name": "GAMING",
//         "links": [
//             {
//                 "name": "Gaming Component",
//                 "link__name": "Gaming Component",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "__________",
//                 "type": "head",
//                 "other": true
//             },
//             {
//                 "name": "Gaming Console",
//                 "link__name": "Gaming Console",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Gaming Console",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Gaming Controller",
//                 "link__name": "Gaming Controller",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Gaming Controller",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Capture Card",
//                 "link__name": "Capture Card",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Capture Card",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Games",
//                 "link__name": "Game ",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Game ",
//                 "type": "link",
//                 "other": 'edit'
//             },
//             {
//                 "name": "Gaming Chair",
//                 "link__name": "Gaming Chair",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Gaming Chair",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Gaming Desk",
//                 "link__name": "Gaming Desk",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Gaming Desk",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Gaming Laptop",
//                 "link__name": "Gaming Laptop",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Gaming Laptop",
//                 "type": "link",
//                 "other": 'edit'
//             },
//             {
//                 "name": "Gaming Desktop PC",
//                 "link__name": "Gaming Desktop PC",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Gaming Desktop PC",
//                 "type": "head",
//                 "other": true
//             },
//             {
//                 "name": "Danguli PC",
//                 "link__name": "Ryans",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Desktop",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Gaming Desktop Component",
//                 "link__name": "Gaming Desktop Component",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "__________",
//                 "type": "head",
//                 "other": true
//             },
//             {
//                 "name": "Motherboard",
//                 "link__name": "Motherboard",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Motherboard",
//                 "type": "link",
//                 "other": "edit"
//             },
//             {
//                 "name": "Desktop Ram",
//                 "link__name": "Desktop Ram",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Desktop Ram",
//                 "type": "link",
//                 "other": "edit"
//             },
//             {
//                 "name": "Graphics Card",
//                 "link__name": "Graphics Card",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Graphics Card",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Power Supply",
//                 "link__name": "Power Supply",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Power Supply",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Casing",
//                 "link__name": "Casing",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Casing",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "CPU Cooler",
//                 "link__name": "CPU Cooler",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "CPU Cooler",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Keyboard",
//                 "link__name": "Keyboard",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Keyboard",
//                 "type": "link",
//                 "other": 'edit'
//             },
//             {
//                 "name": "Mouse",
//                 "link__name": "Mouse",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Mouse",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Mouse Pad",
//                 "link__name": "Mouse Pad",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Mouse Pad",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "LED Strip",
//                 "link__name": "Casing Fan and Accessories",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Casing Fan and Accessories",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Gaming Monitor",
//                 "link__name": "Gaming Monitor",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Gaming Monitor",
//                 "type": "link",
//                 "other": 'edit'
//             },
//             {
//                 "name": "Sound System",
//                 "link__name": "Sound System",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Speaker",
//                 "type": "head",
//                 "other": true
//             },
//             {
//                 "name": "Speaker",
//                 "link__name": "Speaker",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Speaker",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Headphone",
//                 "link__name": "Headphone",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Headphone",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Microphone",
//                 "link__name": "Headphone",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Headphone",
//                 "type": "link",
//                 "other": 'edit'
//             },
//             {
//                 "name": "Earphone",
//                 "link__name": "Ear Phone",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Ear Phone",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Network Router",
//                 "link__name": "Network Router",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Network Router",
//                 "type": "head",
//                 "other": false
//             }
//         ]
//     },
//     {
//         "header": "MONITOR",
//         "img__src": "/laptop.jpg",
//         "link__name": "MONITOR",
//         "links": [
//             {
//                 "name": "All Monitor",
//                 "link__name": "Monitor",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Monitor",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Asus",
//                 "link__name": "Asus",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Monitor",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Aoc",
//                 "link__name": "Aoc",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Monitor",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Acer",
//                 "link__name": "Acer",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Monitor",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Benq",
//                 "link__name": "Benq",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Monitor",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Dell",
//                 "link__name": "Dell",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Monitor",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Gigabyte",
//                 "link__name": "Gigabyte",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Monitor",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "HP",
//                 "link__name": "HP",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Monitor",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Xiaomi",
//                 "link__name": "Xiaomi",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Monitor",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Gamemax",
//                 "link__name": "Gamemax",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Monitor",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "LG",
//                 "link__name": "LG",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Monitor",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Lenovo",
//                 "link__name": "Lenovo",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Monitor",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "MSI",
//                 "link__name": "MSI",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Monitor",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Philips",
//                 "link__name": "Philips",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Monitor",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Samsung",
//                 "link__name": "Samsung",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Monitor",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Viewsonic",
//                 "link__name": "Viewsonic",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Monitor",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Huawei",
//                 "link__name": "Huawei",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Monitor",
//                 "type": "link",
//                 "other": false
//             }, 
//             {
//                 "name": "Fantech",
//                 "link__name": "Fantech",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Monitor",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Corsair",
//                 "link__name": "Corsair",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Monitor",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Hikvision",
//                 "link__name": "Hikvision",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Monitor",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "INNOVTECH",
//                 "link__name": "INNOVTECH",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Monitor",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Razer",
//                 "link__name": "Razer",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Monitor",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Monitor Accessories",
//                 "link__name": "Monitor Accessories",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Monitor",
//                 "type": "head",
//                 "other": "edit"
//             },
//             {
//                 "name": "Monitor Mounts and Brackets",
//                 "link__name": "Monitor Accessories",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Monitor Accessories",
//                 "type": "link",
//                 "other": "edit"
//             }
//         ]
//     },
//     {
//         "header": "TABLET",
//         "img__src": "/laptop.jpg",
//         "link__name": "TABLET",
//         "links": [
//             {
//                 "name": "Regular Tablet",
//                 "link__name": "Regular Tablet",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "TABLET",
//                 "type": "head",
//                 "other": true
//             },
//             {
//                 "name": "All Brands",
//                 "link__name": "Tablet",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Tablet",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Amazon",
//                 "link__name": "Amazon",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Tablet",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Samsung",
//                 "link__name": "Samsung",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Tablet",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Huawei",
//                 "link__name": "Huawei",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Tablet",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Apple Tablet",
//                 "link__name": "Apple Tablet",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "TABLET",
//                 "type": "head",
//                 "other": true
//             },
//             {
//                 "name": "iPad",
//                 "link__name": "iPad",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "iPad",
//                 "type": "link",
//                 "other": false
//             },  
//             {
//                 "name": "E Reader Tablet",
//                 "link__name": "Smart Input Device",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Smart Input Device",
//                 "type": "link",
//                 "other": "edit"
//             },
//             {
//                 "name": "Kids Tablet",
//                 "link__name": "Smart Input Device",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Smart Input Device",
//                 "type": "link",
//                 "other": "edit"
//             },
//             {
//                 "name": "Graphics Tablet",
//                 "link__name": "Smart Input Device",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Smart Input Device",
//                 "type": "head",
//                 "other": true
//             },
//             {
//                 "name": "All Brands",
//                 "link__name": "Smart Input Device",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Smart Input Device",
//                 "type": "link",
//                 "other": "edit"
//             },
//             {
//                 "name": "Wacom",
//                 "link__name": "Wacom",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Smart Input Device",
//                 "type": "link",
//                 "other": "edit"
//             },
//             {
//                 "name": "XP-PEN",
//                 "link__name": "XP-PEN",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Smart Input Device",
//                 "type": "link",
//                 "other": "edit"
//             },
//             {
//                 "name": "Xiaomi",
//                 "link__name": "Xiaomi",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Smart Input Device",
//                 "type": "link",
//                 "other": "edit"
//             },
//             {
//                 "name": "Mobile and Tablet Accessories",
//                 "link__name": "Mobile and Tablet Accessories",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "TABLET",
//                 "type": "head",
//                 "other": true
//             },
//             {
//                 "name": "power bank",
//                 "link__name": "Charger",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "TABLET",
//                 "type": "link",
//                 "other": 'edit'
//             }, 
//             {
//                 "name": "Power Bank",
//                 "link__name": "Power Bank",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Power Bank",
//                 "type": "link",
//                 "other": "edit"
//             },
//             {
//                 "name": "Car Charger",
//                 "link__name": "Car Charger",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "TABLET",
//                 "type": "link",
//                 "other": "edit"
//             },
            
//             {
//                 "name": "Wireless Charger",
//                 "link__name": "Car Charger",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "TABLET",
//                 "type": "link",
//                 "other": "edit"
//             },
//             {
//                 "name": "Wall Charger",
//                 "link__name": "Wall Charger",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "TABLET",
//                 "type": "link",
//                 "other": 'edit'
//             },
//             {
//                 "name": "Cable Organizer",
//                 "link__name": "Cable Organizer",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "TABLET",
//                 "type": "link",
//                 "other": "edit"
//             },
//             {
//                 "name": "Phone Holder",
//                 "link__name": "Phone Holder",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "TABLET",
//                 "type": "link",
//                 "other": "edit"
//             },
//             {
//                 "name": "Screen Cleaner",
//                 "link__name": "Screen Cleaner",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "TABLET",
//                 "type": "link",
//                 "other": "edit"
//             }
//         ]
//     },
//     {
//         "header": "PRINTER",
//         "img__src": "/laptop.jpg",
//         "link__name": "PRINTER",
//         "links": [
//             {
//                 "name": "All Laser and INK Printer",
//                 "link__name": "Printer",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Printer",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Laser Printer",
//                 "link__name": "Laser Printer",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Laser Printer",
//                 "type": "link",
//                 "other": "edit"
//             },
//             {
//                 "name": "Ink Printer",
//                 "link__name": "Ink Printer",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Ink Printer",
//                 "type": "link",
//                 "other": "edit"
//             },
//             {
//                 "name": "Label Printer",
//                 "link__name": "Label Printer",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Label Printer",
//                 "type": "link",
//                 "other": "edit"
//             },
//             {
//                 "name": "Card Printer",
//                 "link__name": "Card Printer",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Card Printer",
//                 "type": "lilnk",
//                 "other": 'edit'
//             },
//             {
//                 "name": "Dot Matrix Printer",
//                 "link__name": "Matrix Printer",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Matrix Printer",
//                 "type": "link",
//                 "other": 'edit'
//             },
//             {
//                 "name": "POS Printer",
//                 "link__name": "POS Printer",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "POS Printer",
//                 "type": "link",
//                 "other": 'edit'
//             },
//             {
//                 "name": "Large Format Printer",
//                 "link__name": "Large Printer",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Large Printer",
//                 "type": "link",
//                 "other": 'edit'
//             },
//             {
//                 "name": "Printer Paper",
//                 "link__name": "Printer Paper",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Printer Paper",
//                 "type": "link",
//                 "other": 'edit'
//             },
//             {
//                 "name": "Consumable",
//                 "link__name": "Consumable",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Printer",
//                 "type": "head",
//                 "other": true
//             },
//             {
//                 "name": "Toner",
//                 "link__name": "Toner",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Toner",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Cartridge",
//                 "link__name": "Cartridge",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Cartridge",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Ribbon",
//                 "link__name": "Ribbon",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Ribbon",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Refill",
//                 "link__name": "Refill",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Refill",
//                 "type": "link",
//                 "other": 'edit'
//             },
//             {
//                 "name": "Drum Unit",
//                 "link__name": "Drum Unit",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Drum Unit",
//                 "type": "link",
//                 "other": 'edit'
//             },
//             {
//                 "name": "Print Head",
//                 "link__name": "Printer Head",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Printer Head",
//                 "type": "link",
//                 "other": 'edit'
//             },
//             {
//                 "name": "Accessories",
//                 "link__name": "Accessories",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Accessories",
//                 "type": "link",
//                 "other": "edit"
//             }
//         ]
//     },
//     {
//         "header": "SCANNER",
//         "img__src": "/laptop.jpg",
//         "link__name": "SCANNER",
//         "links": [
//             {
//                 "name": "Flatbed Scanner",
//                 "link__name": "Canon",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "SCANNER",
//                 "type": "link",
//                 "other": "edit"
//             },
//             {
//                 "name": "Sheetfed and Flatbed Scanner",
//                 "link__name": "Canon",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "SCANNER",
//                 "type": "link",
//                 "other": "edit"
//             },
//             {
//                 "name": "All Scanner",
//                 "link__name": "Scanner",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Scanner",
//                 "type": "head",
//                 "other": false
//             },
//             {
//                 "name": "Canon",
//                 "link__name": "Canon",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "SCANNER",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Epson",
//                 "link__name": "Epson",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "SCANNER",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "HP",
//                 "link__name": "HP",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "SCANNER",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Plustek",
//                 "link__name": "Plustek",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "SCANNER",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Avision",
//                 "link__name": "Avision",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "SCANNER",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Sheet-fed Scanner",
//                 "link__name": "Sheet-fed Scannerr",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Sheet-fed Scanner",
//                 "type": "link",
//                 "other": 'edit'
//             },  
//             {
//                 "name": "Barcode Scanner",
//                 "link__name": "Barcode Scanner",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Barcode Scanner",
//                 "type": "link",
//                 "other": 'edit'
//             }, 
//             {
//                 "name": "Document and Book Scanner",
//                 "link__name": "Document Scanner",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Document Scanner",
//                 "type": "link",
//                 "other": 'edit'
//             }, 
//             {
//                 "name": "Portable Scanner",
//                 "link__name": "Portable Scanner",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Portable Scanne",
//                 "type": "link",
//                 "other": 'edit'
//             }, 
//             {
//                 "name": "Cheque Scanner",
//                 "link__name": "Cheque Scanner",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Cheque Scanner",
//                 "type": "link",
//                 "other": 'edit'
//             }
//         ]
//     },
//     {
//         "header": "PHOTOCOPIER",
//         "img__src": "/laptop.jpg",
//         "link__name": "PHOTOCOPIER",
//         "links": [
//             {
//                 "name": "All Photocopier",
//                 "link__name": "Photocopier",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "PHOTOCOPIER",
//                 "type": "head",
//                 "other": false
//             },
//             {
//                 "name": "Canon",
//                 "link__name": "Canon",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "PHOTOCOPIER",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "HP",
//                 "link__name": "HP",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "PHOTOCOPIER",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Ricoh",
//                 "link__name": "Ricoh",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "PHOTOCOPIER",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Sharp",
//                 "link__name": "Sharp",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "PHOTOCOPIER",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Toshiba",
//                 "link__name": "Toshiba",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "PHOTOCOPIER",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "photocopier accessories",
//                 "link__name": "Toshiba",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "PHOTOCOPIER",
//                 "type": "link",
//                 "other":  'edit'
//             }
//         ]
//     },
//     {
//         "header": "PROJECTOR",
//         "img__src": "/laptop.jpg",
//         "link__name": "PROJECTOR",
//         "links": [
//             {
//                 "name": "All Projector",
//                 "link__name": "Projector",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "PROJECTOR",
//                 "type": "head",
//                 "other": false
//             },
//             {
//                 "name": "Maxell",
//                 "link__name": "Maxell",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "PROJECTOR",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Benq",
//                 "link__name": "Benq",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "PROJECTOR",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Optoma",
//                 "link__name": "Optoma",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "PROJECTOR",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "ViewSonic",
//                 "link__name": "ViewSonic",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "PROJECTOR",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Micropack",
//                 "link__name": "Micropack",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "PROJECTOR",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Asus",
//                 "link__name": "Asus",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "PROJECTOR",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Epson",
//                 "link__name": "Epson",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "PROJECTOR",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Vivitek",
//                 "link__name": "Vivitek",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "PROJECTOR",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Casio",
//                 "link__name": "Casio",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "PROJECTOR",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Projector Screen",
//                 "link__name": "Projector Screen",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Projector Screen",
//                 "type": "link",
//                 "other": 'edit'
//             },
//             {
//                 "name": "Digital Display",
//                 "link__name": "Digital Display",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Digital Display",
//                 "type": "link",
//                 "other": 'edit'
//             },
//             {
//                 "name": "Interactive Panel",
//                 "link__name": "Interactive Panel",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Interactive Panel",
//                 "type": "link",
//                 "other": 'edit'
//             },
//             {
//                 "name": "Digital Signage",
//                 "link__name": "Digital Signage",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Digital Signage",
//                 "type": "link",
//                 "other": 'edit',
                
//             },
//             {
//                 "name": "Presenter",
//                 "link__name": "Presenter",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Presenter",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Ceiling Mount kit",
//                 "link__name": "Mount kit",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Mount kit",
//                 "type": "link",
//                 "other": 'edit'
//             },
//         ]
//     },
//     {
//         "header": "CAMERA",
//         "img__src": "/laptop.jpg",
//         "link__name": "CAMERA",
//         "links": [
//             {
//                 "name": "Digital SLR Camera",
//                 "link__name": "Digital SLR Camera",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Digital SLR Camera",
//                 "type": "link",
//                 "other": 'edit'
//             },
//             {
//                 "name": "DSLR Camera",
//                 "link__name": "SLR Camera",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "SLR Camera",
//                 "type": "link",
//                 "other": 'edit'
//             },
//             {
//                 "name": "Mirrorless Camera",
//                 "link__name": "Mirrorless Camera",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Mirrorless Camera",
//                 "type": "link",
//                 "other": 'edit'
//             },
//             {
//                 "name": "DSLR Camera Lens",
//                 "link__name": "Camera Lens",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Camera Lens",
//                 "type": "link",
//                 "other": 'edit'
//             },
//             {
//                 "name": "DSLR Camera Accessories",
//                 "link__name": "Camera Accessories",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Camera Accessories",
//                 "type": "link",
//                 "other": 'edit'
//             },
//             {
//                 "name": "Digital Compact Camera",
//                 "link__name": "Camera Digital",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Camera Digital",
//                 "type": "link",
//                 "other": 'edit'
//             },
//             {
//                 "name": "Compact Camera",
//                 "link__name": "Camera Digital",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Camera Digital",
//                 "type": "link",
//                 "other": 'edit'
//             },
//             {
//                 "name": "Handy Camera",
//                 "link__name": "Handy Camera",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Handy Camera",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Action Camera",
//                 "link__name": "Action Camera",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Action Camera",
//                 "type": "link",
//                 "other": 'edit'
//             },
//             {
//                 "name": "Compact Camera Accessories",
//                 "link__name": "Camera Accessories",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Camera Accessories",
//                 "type": "link",
//                 "other": 'edit'
//             },
//             {
//                 "name": "Video Camera",
//                 "link__name": "Video Camera",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Video Camera",
//                 "type": "link",
//                 "other": 'edit'
//             },
//             {
//                 "name": "Webcam",
//                 "link__name": "Webcam",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Webcam",
//                 "type": "head",
//                 "other": 'edit'
//             },
//             {
//                 "name": "Drone",
//                 "link__name": "Drone",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Drone",
//                 "type": "link",
//                 "other": false
//             }
//         ]
//     },
//     {
//         "header": "SECURITY SYSTEM",
//         "img__src": "/laptop.jpg",
//         "link__name": "SECURITY SYSTEM",
//         "links": [
//             {
//                 "name": "CC Camera",
//                 "link__name": "CC Camera",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "CC Camera",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "IP Camera",
//                 "link__name": "IP Camera",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "IP Camera",
//                 "type": "head",
//                 "other": 'edit'
//             },
//             {
//                 "name": "Wireless Camera",
//                 "link__name": "wi-fi Camera",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "wi-fi Camera",
//                 "type": "link",
//                 "other": 'edit'
//             },
//             {
//                 "name": "DVR",
//                 "link__name": "DVR",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "DVR",
//                 "type": "link",
//                 "other": 'edit'
//             },
//             {
//                 "name": "NVR",
//                 "link__name": "NVR",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "NVR",
//                 "type": "link",
//                 "other": 'edit'
//             },
//             {
//                 "name": "XVR",
//                 "link__name": "XVR",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "XVR",
//                 "type": "link",
//                 "other": 'edti'
//             },
//             {
//                 "name": "CC/IP Camera Accessories",
//                 "link__name": "CC Camera Accessories",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "CC Camera Accessories",
//                 "type": "link",
//                 "other": 'edit'
//             },
//             {
//                 "name": "Smart Lock, Door Bell and Video Door Phone",
//                 "link__name": "Smart Door Bell",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Smart Door Bell",
//                 "type": "link",
//                 "other": 'edit'
//             },
//             {
//                 "name": "Time Attendance System",
//                 "link__name": "Time Attendance System",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "SECURITY SYSTEM",
//                 "type": "head",
//                 "other": true
//             },
//             {
//                 "name": "Access Control",
//                 "link__name": "Access Control",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Access Control",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Access Control Accessories",
//                 "link__name": "Access Control",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Access Control",
//                 "type": "link",
//                 "other": 'edit'
//             }, 
//             {
//                 "name": "Access Control Software",
//                 "link__name": "Access Control Software",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Access Control Software",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Entrance Control",
//                 "link__name": "Entrance Control",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Entrance Control",
//                 "type": "link",
//                 "other": 'edit'
//             }
//         ]
//     },
//     {
//         "header": "NETWORK",
//         "img__src": "/laptop.jpg",
//         "link__name": "NETWORK",
//         "links": [
//             {
//                 "name": "Network Router",
//                 "link__name": "Network Router",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Network Router",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Access Point",
//                 "link__name": "Access Point",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Access Point",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Range Extender",
//                 "link__name": "Range Extender",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Range Extender",
//                 "type": "link",
//                 "other": 'edit'
//             },
//             {
//                 "name": "Network Switch",
//                 "link__name": "Network Switch",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Network Switch",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Lan Card",
//                 "link__name": "Lan Card",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Lan Card",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Network Cable",
//                 "link__name": "Network Cable",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Network Cable",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Optical Line Termination (OLT)",
//                 "link__name": "OLT",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "OLT",
//                 "type": "link",
//                 "other": 'edit'
//             },
//             {
//                 "name": "Optical Network Unit (ONU)",
//                 "link__name": "ONU",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "ONU",
//                 "type": "link",
//                 "other": 'edit'
//             },
//             {
//                 "name": "Network Storage",
//                 "link__name": "Network Storage",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Network Storage",
//                 "type": "head",
//                 "other": false
//             },
//             {
//                 "name": "Edge Modem",
//                 "link__name": "Edge Modem",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Edge Modem",
//                 "type": "head",
//                 "other": false
//             },
//             {
//                 "name": "Network Accessories",
//                 "link__name": "Network Accessories",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "NETWORK",
//                 "type": "head",
//                 "other": true
//             },
//             {
//                 "name": "Connector",
//                 "link__name": "Connector",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Connector",
//                 "type": "link",
//                 "other": 'edit'
//             },
//             {
//                 "name": "Face Plate",
//                 "link__name": "Face Plate",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Face Plate",
//                 "type": "link",
//                 "other": 'edit'
//             },
//             {
//                 "name": "Cable Lan",
//                 "link__name": "Cable Lan",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Cable Lan",
//                 "type": "link",
//                 "other": 'edit'
//             },
//             {
//                 "name": "Cutting/Stripping/Crimping",
//                 "link__name": "Crimping",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Crimping",
//                 "type": "link",
//                 "other": 'edit'
//             },
//             {
//                 "name": "Patch Cord",
//                 "link__name": "Patch Cord",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Patch Cord",
//                 "type": "link",
//                 "other": 'edit'
//             },
//             {
//                 "name": "Management Cable",
//                 "link__name": "Management Cable",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Management Cable",
//                 "type": "link",
//                 "other": 'edit'
//             },
//             {
//                 "name": "Patch Panel",
//                 "link__name": "Patch Panel",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Patch Panel",
//                 "type": "link",
//                 "other": 'edit'
//             },
//             {
//                 "name": "Modular",
//                 "link__name": "Modul",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Modul",
//                 "type": "link",
//                 "other": 'edit'
//             }
//         ]
//     },
//     {
//         "header": "SOUND SYSTEM",
//         "img__src": "/laptop.jpg",
//         "link__name": "SOUND SYSTEM",
//         "links": [
//             {
//                 "name": "Speaker",
//                 "link__name": "Speaker",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Speaker",
//                 "type": "head",
//                 "other": true
//             },
//             {
//                 "name": "All Brand",
//                 "link__name": "Speaker",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Speaker",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "F&D",
//                 "link__name": "F&D",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Speaker",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Xtreme",
//                 "link__name": "Xtreme",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Speaker",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Edifier",
//                 "link__name": "Edifier",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Speaker",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Havit",
//                 "link__name": "Havit",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Speaker",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Digital X",
//                 "link__name": "Digital X",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Speaker",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Golden Field",
//                 "link__name": "Golden Field",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Speaker",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Microlab",
//                 "link__name": "Microlab",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Speaker",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "JBL",
//                 "link__name": "JBL",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Speaker",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Jabra",
//                 "link__name": "Jabra",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Speaker",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Altec Lansing",
//                 "link__name": "Altec Lansing",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Speaker",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Fantech",
//                 "link__name": "Fantech",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Speaker",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Grandstream",
//                 "link__name": "Grandstream",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Speaker",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Rapoo",
//                 "link__name": "Rapoo",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Speaker",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Creative",
//                 "link__name": "Creative",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Speaker",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Bose",
//                 "link__name": "Bose",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Speaker",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Silicon Power",
//                 "link__name": "Silicon Power",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Speaker",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Logitech",
//                 "link__name": "Logitech",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Speaker",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Polycom",
//                 "link__name": "Polycom",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Speaker",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Micropack",
//                 "link__name": "Micropack",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Speaker",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Google",
//                 "link__name": "Google",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Speaker",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Amazon",
//                 "link__name": "Amazon",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Speaker",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Redragon",
//                 "link__name": "Redragon",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Speaker",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Marvo",
//                 "link__name": "Marvo",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Speaker",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Home Theater Systems",
//                 "link__name": "Sound Bar",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Sound Bar",
//                 "type": "link",
//                 "other": 'edit'
//             }, 
//             {
//                 "name": "Headphone",
//                 "link__name": "Headphone",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Headphone",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Ear Phone",
//                 "link__name": "Ear Phone",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Ear Phone",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Microphone",
//                 "link__name": "Microphone",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Microphone",
//                 "type": "link",
//                 "other": 'edit'
//             },
//             {
//                 "name": "Sound Card",
//                 "link__name": "Sound Card",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Sound Card",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Voice Recorder",
//                 "link__name": "Voice Recorder",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Voice Recorder",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Radio",
//                 "link__name": "Radio",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Radio",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Musical Instrument",
//                 "link__name": "Musical Instrument",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Musical Instrument",
//                 "type": "link",
//                 "other": false
//             }
//         ]
//     },
//     {
//         "header": "OFFICE ITEMS",
//         "img__src": "/laptop.jpg",
//         "link__name": "OFFICE ITEMS",
//         "links": [
//             {
//                 "name": "Money Counting Machine",
//                 "link__name": "Money Counting",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Money Counting",
//                 "type": "head",
//                 "other": true
//             },
//             {
//                 "name": "Cash Register Machine",
//                 "link__name": "Cash Register Machine",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Cash Register Machine",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Paper Shredder",
//                 "link__name": "Paper Shredder",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Paper Shredder",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Telephone Set",
//                 "link__name": "Telephone Set",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "OFFICE ITEMS",
//                 "type": "head",
//                 "other": true
//             },
//             {
//                 "name": "All Phone Set",
//                 "link__name": "Phone Set",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Phone Set",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "IP Phone Set",
//                 "link__name": "IP Phone",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "IP Phone",
//                 "type": "link",
//                 "other": 2
//             },
//             {
//                 "name": "Land Phone Set",
//                 "link__name": "Phone Set",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Phone Set",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Fax Machine",
//                 "link__name": "Fax Machine",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Fax Machine",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Calculator",
//                 "link__name": "Calculator",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Calculator",
//                 "type": "link",
//                 "other": false
//             }
//         ]
//     },
//     {
//         "header": "STORAGE",
//         "img__src": "/laptop.jpg",
//         "link__name": "STORAGE",
//         "links": [
//             {
//                 "name": "All HDD",
//                 "link__name": "Hard Drive",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Hard Drive",
//                 "type": "link",
//                 "other": 2
//             },
//             {
//                 "name": "Internal Hard Drive",
//                 "link__name": "Internal Hard Drive",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Internal Hard Drive",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "External Hard Drive",
//                 "link__name": "External Hard Drive",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "External Hard Drive",
//                 "type": "head",
//                 "other": false
//             },
//             {
//                 "name": "All SSD",
//                 "link__name": "SSD",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "SSD",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Internal SSD",
//                 "link__name": "Internal SSD",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Internal SSD",
//                 "type": "link",
//                 "other": 'edit'
//             },
//             {
//                 "name": "External SSD",
//                 "link__name": "External SSD",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "External SSD",
//                 "type": "link",
//                 "other": 'edit'
//             },
//             {
//                 "name": "Server HDD",
//                 "link__name": "Server HDD",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Server HDD",
//                 "type": "link",
//                 "other": 'edit'
//             },
//             {
//                 "name": "Pen Drive",
//                 "link__name": "Pen Drive",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Pen Drive",
//                 "type": "head",
//                 "other": false
//             },
//             {
//                 "name": "Memory Card",
//                 "link__name": "Memory Card",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Memory Card",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "HDD Case",
//                 "link__name": "HDD Case",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "HDD Case",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Card Reader",
//                 "link__name": "Card Reader",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Card Reader",
//                 "type": "link",
//                 "other": false
//             }
//         ]
//     },
//     {
//         "header": "ACCESSORIES",
//         "img__src": "/laptop.jpg",
//         "link__name": "ACCESSORIES",
//         "links": [
//             {
//                 "name": "Cable",
//                 "link__name": "Cable",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Cable",
//                 "type": "head",
//                 "other": true
//             },
//             {
//                 "name": "All Cable",
//                 "link__name": "Cable",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Cable",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "HDMI Cable",
//                 "link__name": "HDMI Cable",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "HDMI Cable",
//                 "type": "link",
//                 "other": 'edit'
//             },
//             {
//                 "name": "VGA Cable",
//                 "link__name": "VGA Cable",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "VGA Cable",
//                 "type": "link",
//                 "other": 'edit'
//             },
//             {
//                 "name": "Lightning Cable",
//                 "link__name": "Lightning Cable",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Lightning Cable",
//                 "type": "link",
//                 "other": 'edit'
//             },
//             {
//                 "name": "USB Cable",
//                 "link__name": "USB Cable",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "USB Cable",
//                 "type": "link",
//                 "other": 'edit'
//             },
//             {
//                 "name": "Audio Cable",
//                 "link__name": "Audio Cable",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Audio Cable",
//                 "type": "link",
//                 "other": 'edit'
//             },
//             {
//                 "name": "Sata Cable",
//                 "link__name": "Sata Cable",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Sata Cable",
//                 "type": "link",
//                 "other": 'edit'
//             },
//             {
//                 "name": "Port Cable",
//                 "link__name": "Port Cable",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Port Cable",
//                 "type": "link",
//                 "other": 'edit'
//             },
//             {
//                 "name": "Converter",
//                 "link__name": "Converter",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "ACCESSORIES",
//                 "type": "head",
//                 "other": true
//             },
//             {
//                 "name": "All Converter",
//                 "link__name": "Converter",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Converter",
//                 "type": "link",
//                 "other": false
//             }, 
//             {
//                 "name": "HDMI Converter",
//                 "link__name": "HDMI Converter",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "HDMI Converter",
//                 "type": "link",
//                 "other": 'edit'
//             },
//             {
//                 "name": "VGA Converter",
//                 "link__name": "VGA Converter",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "VGA Converter",
//                 "type": "link",
//                 "other": 'edit'
//             },
//             {
//                 "name": "USB HUB",
//                 "link__name": "USB HUB",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "USB HUB",
//                 "type": "link",
//                 "other": 'edit'
//             },
//             {
//                 "name": "Audio Converter",
//                 "link__name": "Audio Converter",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Audio Converter",
//                 "type": "link",
//                 "other": 'edit'
//             },
//             {
//                 "name": "Bluetooth Adapter",
//                 "link__name": "Bluetooth Adapter",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Bluetooth Adapter",
//                 "type": "link",
//                 "other": 'edit'
//             },
//             {
//                 "name": "Type-C Converter",
//                 "link__name": "Type-C Converter",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Type-C Converter",
//                 "type": "link",
//                 "other": 'edit'
//             },
//             {
//                 "name": "Lightning Converter",
//                 "link__name": "Lightning Converter",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Lightning Converter",
//                 "type": "link",
//                 "other": 'edit'
//             },
//             {
//                 "name": "USB Converter",
//                 "link__name": "USB Converter",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "USB Converter",
//                 "type": "link",
//                 "other": 'edit'
//             },
//             {
//                 "name": "Display Port Converter",
//                 "link__name": "Port Converter",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Port Converter",
//                 "type": "link",
//                 "other": 'edit'
//             },
//             {
//                 "name": "DVI Converter",
//                 "link__name": "DVI Converter",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "DVI Converter",
//                 "type": "link",
//                 "other": 'edit'
//             },
//             {
//                 "name": "Electrical Power",
//                 "link__name": "Electrical Power",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "ACCESSORIES",
//                 "type": "head",
//                 "other": true
//             },
//             {
//                 "name": "Power Strip",
//                 "link__name": "PowerStrip",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "PowerStrip",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Power Adapter",
//                 "link__name": "Power Adapter",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Power Adapter",
//                 "type": "link",
//                 "other": 'edit'
//             },
//             {
//                 "name": "Blower",
//                 "link__name": "Blower",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Blower",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Power Cable",
//                 "link__name": "Power Cable",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Power Cable",
//                 "type": "link",
//                 "other": 'edit'
//             },
//             {
//                 "name": "Premium Accessories",
//                 "link__name": "Premium Accessories",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "ACCESSORIES",
//                 "type": "head",
//                 "other": true
//             },
//             {
//                 "name": "Apple Accessories",
//                 "link__name": "Smart Input Device",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Smart Input Device",
//                 "type": "link",
//                 "other": 'edit'
//             },
//             {
//                 "name": "Microsoft Accessories",
//                 "link__name": "Smart Input Device",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Smart Input Device",
//                 "type": "link",
//                 "other": 'edit'
//             },
//             {
//                 "name": "Digital Pen",
//                 "link__name": "Digital Pen",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Digital Pen",
//                 "type": "link",
//                 "other": 'edit'
//             },
//             {
//                 "name": "Power & Charger",
//                 "link__name": "Charger",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Charger",
//                 "type": "link",
//                 "other": 'edit'
//             },
//             {
//                 "name": "Bag",
//                 "link__name": "Bags",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Bags",
//                 "type": "link",
//                 "other": false
//             }
//         ]
//     },
//     {
//         "header": "SOFTWARE",
//         "img__src": "/laptop.jpg",
//         "link__name": "SOFTWARE",
//         "links": [
//             {
//                 "name": "Antivirus & Security",
//                 "link__name": "Antivirus",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Antivirus",
//                 "type": "link",
//                 "other": false
//             }, 
//             {
//                 "name": "Office Application",
//                 "link__name": "Office Application",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "SOFTWARE",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Operating System and DB",
//                 "link__name": "OS and DB",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "OS and DB",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Graphics Design",
//                 "link__name": "Graphics Design",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "SOFTWARE",
//                 "type": "head",
//                 "other": true
//             },
//             {
//                 "name": "Engineering Design",
//                 "link__name": "Engineering Design",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "SOFTWARE",
//                 "type": "head",
//                 "other": true
//             },
//             {
//                 "name": "Bangla Typing Application",
//                 "link__name": "Bangla Typing Application",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "SOFTWARE",
//                 "type": "head",
//                 "other": true
//             }
//         ]
//     },
//     {
//         "header": "DAILY LIFE",
//         "img__src": "/laptop.jpg",
//         "link__name": "DAILY LIFE",
//         "links": [
//             {
//                 "name": "Smartwatch",
//                 "link__name": "Smartwatch",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Smartwatch",
//                 "type": "head",
//                 "other": true
//             },
//             {
//                 "name": "All Smartwatch",
//                 "link__name": "Smartwatch",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Smartwatch",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Apple",
//                 "link__name": "Apple",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Smartwatch",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Kieslect",
//                 "link__name": "Kieslect",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Smartwatch",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Havit",
//                 "link__name": "Havit",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Smartwatch",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Xiaomi",
//                 "link__name": "Xiaomi",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Smartwatch",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "Sewing Machine",
//                 "link__name": "Sewing Machine",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Sewing Machine",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "TV and Video Streaming",
//                 "link__name": "TV and Video Streaming",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "DAILY LIFE",
//                 "type": "head",
//                 "other": true
//             },
//             {
//                 "name": "Smart TV",
//                 "link__name": "Smart TV",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Smart TV",
//                 "type": "link",
//                 "other": false
//             },
//             {
//                 "name": "TV Streaming",
//                 "link__name": "TV Streaming",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "DAILY LIFE",
//                 "type": "head",
//                 "other": true
//             },
//             {
//                 "name": "TV Card",
//                 "link__name": "TV Card",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "DAILY LIFE",
//                 "type": "head",
//                 "other": true
//             },
//             {
//                 "name": "Game Streaming",
//                 "link__name": "Capture Card",
//                 "img__src": "/laptop.jpg",
//                 "parent__link": "Capture Card",
//                 "type": "link",
//                 "other": 2
//             }
//         ]
//     }
    
// ]


// import axios from 'axios';
// import { default as React, default as React, useContext, useState } from 'react';
// import { danguliContext } from './App';
// import { errId } from './data/first__1000';
// import { momentTimeMaker, serverProductConverter, serverProductHtmlTextConverter, stringConverter, stringMacker } from './utils';

// const Server = () => {
//     const [products, setProducts] = useState([]);
//     const [productsDetails, setProductsDetails] = useState([]);
//     const [productSpecifications, setProductSpecifications]  = useState([]);
    
//     const [str ,setStr]  = useState('')

//     const handleGetProductData = (collection) => {

//         axios.get('http://localhost:3009/getAllCollection',{headers:{collection: collection}})
//         .then(res => { 
//             let server__data = res.data.result;
//             if(res.data.status__code === 200 && server__data.length){
//                 const customize__server__data = []; 
//                 server__data.forEach((info)=>{ 
                    
//                     let data = stringConverter(info.infos)
//                     let result = serverProductConverter(data);
//                     let {product, overview}  = result;
//                     product.overview = overview; 
//                     customize__server__data.push(product)
//                 })  
//                 setProducts(customize__server__data); 
//                 console.log(customize__server__data);
//             }
//         }).catch(err =>  {
//             console.log(err.message);
//         })
//     } 

//     const handleGetDetailsData = (collection) => {
//         axios.get('http://localhost:3009/getAllCollection',{headers:{collection: collection}})
//         .then(res => { 
//             let server__data = res.data.result;
//             if(res.data.status__code === 200 && server__data.length){
//                 const customize__server__data = []; 
//                 server__data.forEach((info)=>{ 
                    
//                     let data = stringConverter(info.details) 
//                     info.details = serverProductHtmlTextConverter(stringConverter(info.details))
//                     customize__server__data.push(info);
//                 })  
//                 setProductsDetails(customize__server__data);  
//                 console.log(customize__server__data);
//             }
//         }).catch(err =>  {
//             console.log(err.message);
//         })
//     }  
    
//     const handleGetSpecificationsData = (collection) => {
//         axios.get('http://localhost:3009/getAllCollection',{headers:{collection: collection}})
//         .then(res => { 
//             let server__data = res.data.result;
//             if(res.data.status__code === 200 && server__data.length){
//                 const customize__server__data = []; 
//                 // server__data.forEach((info, index)=>{  
//                 //     console.log(index);
//                 //     let data = JSON.parse(specificationsConverter(stringConverter(info.specifications)) || [])  

//                 //     console.log(index, data);
//                 //     // customize__server__data.push(info)
//                 // })      
//                 console.log(server__data[1220]);
//                 setProductsDetails(customize__server__data);  
//                 console.log(customize__server__data);
//             }
//         }).catch(err =>  {
//             console.log(err.message);
//         })
//     }  

//     return (
//         <div>
//             <h1>Hello world</h1>
//             <button onClick={()=> handleGetProductData('product')}>Handle Get Product Data Data</button>   
//             <button onClick={()=> handleGetDetailsData('details')}>Handle Get details Data Data</button>   
//             <button onClick={()=> handleGetSpecificationsData('specifications')}>Handle Get details Data Data</button>   
//             {productsDetails.length ? <div dangerouslySetInnerHTML={{__html: productsDetails[Math.floor(Math.random() * productsDetails.length -1)].details}}></div> : ""}
//         </div>
//     );
// };

// export default Server;







// const Server = () => {
    
//     const {customize__server__data} = useContext(danguliContext);
//     let errID = errId;
//     let count = 6098; // 3483 // 6010  // 6098
//     const faildProduct  = [];

//     const handleStartSubmit = () => { 

//         handleGetData(customize__server__data[count])
//         document.getElementById('server__insert__result').innerHTML = count;
//         count++;
//     }

//     const handleGetData = (result) =>  { 
//             axios.get(result.details__url)
//             .then(res => { 
//                 if(res.data){  
//                     let productData = res.data; 
//                     let startCutStr = 'Overview</p>'
//                     let startCutStrLen = 'Overview</p>'.length;
//                     let endCutStr = '<div class="row-detail-action">'  
            
//                     let overviewData = productData.slice(productData.indexOf(startCutStr)+startCutStrLen, productData.indexOf(endCutStr));  
                    
                    
//                     let showOf = document.getElementById('server__result');
//                     showOf.innerHTML = res.data;
//                     showOf.style.display = 'none';
                    
//                     let images = document.querySelectorAll('#productGallery > .elevatezoom-gallery');
//                     let zoomImages = [];
//                     images.forEach(info =>  {
//                         zoomImages.push(info.dataset.zoomImage);
//                     })


//                     let headerMother  = document.querySelectorAll('.specs-wrapper > .row > .col-sm-12');
//                     let totalSpecifications = []
//                     headerMother.forEach(info =>  {
//                         let newInfo = {}
//                         let infos = [];
                    
//                         let title = info.querySelector('.group');
//                         if(title){
//                             newInfo.title = title.innerText
//                         let tableRows = info.querySelectorAll('.specs-item-wrapper > .row');
//                             tableRows.forEach(info => {
//                                 let data = {};
//                                 let headText = info.querySelector('.attribute_set').innerHTML;
//                                 let text = info.querySelector('.col-md-10').innerHTML;
//                                 data.title = headText;
//                                 data.info = text; 
//                                 infos.push(data);
//                             })  
//                         }else{
                    
//                             newInfo.title = 'General'; 
                        
//                             let tableRows = info.querySelectorAll('.specs-item-wrapper > .row');
//                                 tableRows.forEach(info => {
//                                     let data = {};
//                                     let headText = info.querySelector('.attribute_set').innerHTML;
//                                     let text = info.querySelector('.col-md-10').innerHTML;
//                                     data.title = headText;
//                                     data.info = text; 
//                                     infos.push(data);
//                                 })
                                
//                         }
                            
//                             newInfo.infos = infos;
//                         totalSpecifications.push(newInfo);
                    
//                     })

//                     let data = document.getElementById('description');
//                     let newData = data.innerHTML 
                    
//                     let productDetails = {
//                         images: zoomImages,
//                         specification: totalSpecifications,
//                         overview: overviewData,
//                         details: newData, 
//                         product: result
//                     } 
//                     handlePostData(productDetails) 
//                 }
//             }).catch(err => { 
//                 console.log(err.message);
//                 faildProduct.push(result.product__id);
//                 console.log(faildProduct);
//                 handleStartSubmit();
//             }) 
//     }

//     const handlePostData = (data, ) =>{
//         let {images, specification, overview, details, product} = data;
//             product.images = images;
//             product.overview = overview;

//             handlePostProduct(product, specification, details);
//     }

//     const handlePostProduct = (postItem, specification, details) => {
//         postItem.stock= true;
//         postItem.quantity = 10;
//         let postInfo = {}; 
//         postInfo.product__id = postItem
//         .product__id;
//         postInfo.category = postItem.category;
//         postInfo.collection = postItem.collection;
//         postInfo.post__time = momentTimeMaker(); 
//         postInfo.infos = stringMacker(JSON.stringify(postItem));
        

//         axios.post('http://localhost:3009/productUpload', postInfo)
//         .then(res => {
//             if(res.data.status__code === 200){
//                 handlePostSpecification(postItem
//                     .product__id, specification, details)
//             }
//         }).catch(err => {
//             console.log(err.message);
//         })
//     }

//     const handlePostSpecification = (ID, specification, details) => {
//         let postInfo = {};  
//         postInfo.product__id = ID;
//         postInfo.post__time = momentTimeMaker();
//         postInfo.specifications = stringMacker(JSON.stringify(specification));

//         axios.post('http://localhost:3009/specificationsUpload', postInfo)
//         .then(res => {
//             if(res.data.status__code === 200){
//                 handlePostDetails(ID, details)
//             }
//         }).catch(err => {
//             console.log(err.message);
//         })
//     }

//     const handlePostDetails = (id, details) => {
//         let postInfo = {};
//         postInfo.product__id = id;
//         postInfo.post__time = momentTimeMaker();
//         postInfo.details = stringMacker(JSON.stringify(details));

//         axios.post('http://localhost:3009/detailsUpload', postInfo)
//         .then(res => {
//             if(res.data.status__code === 200){ 
//                 handleStartSubmit();
//             }
//         }).catch(err => {
//             console.log(err.message);
//         })
//     }

//     return (
//         <div className='server__upload__container'>
//             <div>
//                 <div id='server__result'/>
//                 <h1>Hello world</h1>
//                 <h1><span id='server__insert__result'></span> customize__server__data out of  {customize__server__data.length}</h1>
//                 <button onClick={handleStartSubmit}>Start Upload</button>
//             </div>
//             <div> 
//             </div>
//         </div>
//     );
// };

// export default Server;

