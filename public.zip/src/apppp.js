// import React from 'react';
// import { ContextProvider } from './DanguliContext';
// import DanguliRouter from './DanguliRouter';


// const App = () => {
    
//     return (
//         <div>
//             <ContextProvider>
//                 <DanguliRouter/>
//             </ContextProvider>
//         </div>
//     );
// };

// export default App;


import BrandsCategories from './Components/BrandsCategories/BrandsCategories';
import Carousell from './Components/Carousel/Carousel';
import CartTen from './Components/Carts/CartTen/CartTen';
import FeaturedCategories from './Components/FeaturedCategories/FeaturedCategories';
import Footer from './Components/Footer/Footer';
import FooterBanner from './Components/FooterBanner/FooterBanner';
import HelpFooter from './Components/FooterBanner/HelpFooter';
import HelpAnywhere from './Components/HelpAnywhere/HelpAnywhere';
import BestRated from './Components/HomePagerSliders/BestRated';
import EverydayEssentials from './Components/HomePagerSliders/EverydayEssentials';
import FeaturedProducts from './Components/HomePagerSliders/FeaturedProducts';
import HighLightOfTheWeek from './Components/HomePagerSliders/HighLightOfTheWeek';
import PreOrder from './Components/HomePagerSliders/PreOrder';
import RecentlyAdded from './Components/HomePagerSliders/RecentlyAdded';
import Recommended from './Components/HomePagerSliders/Recommended';
import UpgradeYourGamingStation from './Components/HomePagerSliders/UpgradeYourGamingStation';
import HomeImageGridView from './Components/ImageGrid/HomeImageGridView';
import MoreSave from './Components/MoreSave/MoreSave';
import OwenerFeatures from './Components/OwenerFeatures/OwenerFeatures';
import PrintHomeBanner from './Components/PrintHomeBanner/PrintHomeBanner';
import TechSuccess from './Components/TechSuccess/TechSuccess';

const App = () => {
    return (
        <div>      
            <CartTen/>
            <div className='final__landing__page__container__with__production'>
                <Carousell/>
                <UpgradeYourGamingStation/>
                <EverydayEssentials/>
                <FeaturedCategories/>
                <Recommended/>
                <BrandsCategories/> 
                <RecentlyAdded/>
                <OwenerFeatures/>
                <HighLightOfTheWeek/>
                <MoreSave/>
                <PreOrder/>
                <TechSuccess/>
                <BestRated/>
                <HelpAnywhere/>
                <PrintHomeBanner/>
                <FeaturedProducts/>
                <HomeImageGridView/>
            </div> 
            <FooterBanner/>
            <HelpFooter/>
            <Footer/>
        </div>
    );
};

export default App;


// todo  best cart 26 === 28 === 23 === 21 === 16 === 14 === 12 === 10 === 8 === 6 === 4 ==== 