let navLinks = [ 
    {
        "header": "LAPTOP",
        "img__src": "/laptop.jpg",
        "link__name": "LAPTOP",
        "links": [

            {
                "category": "Laptop",
                "link__name": "Laptop",
                "img__src": "/laptop.jpg",
                "parent": "LAPTOP",
                "type": "head",
                "other": true,
                "subCategory": "All Laptop"
            },
            {
                "category": "All Laptop",
                "link__name": "All Laptop",
                "img__src": "/laptop.jpg",
                "parent": "LAPTOP",
                "type": "link",
                "other": 2,
                "subCategory": "All Laptop"
            },
            {
                "category": " Apple",
                "link__name": " Apple",
                "img__src": "/laptop.jpg",
                "parent": "LAPTOP",
                "type": "link",
                "other": 4,
                "subCategory": "All Laptop"
            },
            {
                "category": " Asus",
                "link__name": " Asus",
                "img__src": "/laptop.jpg",
                "parent": "LAPTOP",
                "type": "link",
                "other": 4,
                "subCategory": "All Laptop"
            },
            {
                "category": " Acer",
                "link__name": " Acer",
                "img__src": "/laptop.jpg",
                "parent": "LAPTOP",
                "type": "link",
                "other": 4,
                "subCategory": "All Laptop"
            },
            {
                "category": " Avita",
                "link__name": " Avita",
                "img__src": "/laptop.jpg",
                "parent": "LAPTOP",
                "type": "link",
                "other": 4,
                "subCategory": "All Laptop"
            },
            {
                "category": " Dell",
                "link__name": " Dell",
                "img__src": "/laptop.jpg",
                "parent": "LAPTOP",
                "type": "link",
                "other": 4,
                "subCategory": "All Laptop"
            },
            {
                "category": " Chuwi",
                "link__name": " Chuwi",
                "img__src": "/laptop.jpg",
                "parent": "LAPTOP",
                "type": "link",
                "other": 4,
                "subCategory": "All Laptop"
            },
            {
                "category": " HP",
                "link__name": " HP",
                "img__src": "/laptop.jpg",
                "parent": "LAPTOP",
                "type": "link",
                "other": 4,
                "subCategory": "All Laptop"
            },
            {
                "category": " Huawei",
                "link__name": " Huawei",
                "img__src": "/laptop.jpg",
                "parent": "LAPTOP",
                "type": "link",
                "other": 4,
                "subCategory": "All Laptop"
            },
            {
                "category": " i-Life",
                "link__name": " i-Life",
                "img__src": "/laptop.jpg",
                "parent": "LAPTOP",
                "type": "link",
                "other": 4,
                "subCategory": "All Laptop"
            },
            {
                "category": " Lenovo",
                "link__name": " Lenovo",
                "img__src": "/laptop.jpg",
                "parent": "LAPTOP",
                "type": "link",
                "other": 4,
                "subCategory": "All Laptop"
            },
            {
                "category": " Microsoft",
                "link__name": " Microsoft",
                "img__src": "/laptop.jpg",
                "parent": "LAPTOP",
                "type": "link",
                "other": 4,
                "subCategory": "All Laptop"
            },
            {
                "category": " MSI",
                "link__name": " MSI",
                "img__src": "/laptop.jpg",
                "parent": "LAPTOP",
                "type": "link",
                "other": 4,
                "subCategory": "All Laptop"
            },
            {
                "category": " Nexstgo",
                "link__name": " Nexstgo",
                "img__src": "/laptop.jpg",
                "parent": "LAPTOP",
                "type": "link",
                "other": 4,
                "subCategory": "All Laptop"
            },
            {
                "category": " Razer",
                "link__name": " Razer",
                "img__src": "/laptop.jpg",
                "parent": "LAPTOP",
                "type": "link",
                "other": 4,
                "subCategory": "All Laptop"
            },
            {
                "category": " Gigabyte",
                "link__name": " Gigabyte",
                "img__src": "/laptop.jpg",
                "parent": "LAPTOP",
                "type": "link",
                "other": 4,
                "subCategory": "All Laptop"
            },
            {
                "category": "Accessories",
                "link__name": "Accessories",
                "img__src": "/laptop.jpg",
                "parent": "LAPTOP",
                "type": "head",
                "other": true,
                "subCategory": "Accessories"
            },
            {
                "category": "All Accessories",
                "link__name": "Accessories",
                "img__src": "/laptop.jpg",
                "parent": "LAPTOP",
                "type": "link",
                "other": 2,
                "subCategory": "Accessories"
            },
            {
                "category": " Laptop Ram",
                "link__name": " Laptop Ram",
                "img__src": "/laptop.jpg",
                "parent": "LAPTOP",
                "type": "link",
                "other": 4,
                "subCategory": "Accessories"
            },
            {
                "category": " Laptop Cooler",
                "link__name": " Laptop Cooler",
                "img__src": "/laptop.jpg",
                "parent": "LAPTOP",
                "type": "link",
                "other": 4,
                "subCategory": "Accessories"
            },
            {
                "category": " Caddy",
                "link__name": " Caddy",
                "img__src": "/laptop.jpg",
                "parent": "LAPTOP",
                "type": "link",
                "other": 4,
                "subCategory": "Accessories"
            },
            {
                "category": " Laptop Bag",
                "link__name": " Laptop Bag",
                "img__src": "/laptop.jpg",
                "parent": "LAPTOP",
                "type": "link",
                "other": 4,
                "subCategory": "Accessories"
            },
            {
                "category": " Stand",
                "link__name": " Stand",
                "img__src": "/laptop.jpg",
                "parent": "LAPTOP",
                "type": "link",
                "other": 4,
                "subCategory": "Accessories"
            },
            {
                "category": " Battery",
                "link__name": " Battery",
                "img__src": "/laptop.jpg",
                "parent": "LAPTOP",
                "type": "link",
                "other": 4,
                "subCategory": "Accessories"
            },
            {
                "category": " Adapter",
                "link__name": " Adapter",
                "img__src": "/laptop.jpg",
                "parent": "LAPTOP",
                "type": "link",
                "other": 4,
                "subCategory": "Accessories"
            }
        ]
    },
    {
        "header": "DESKTOP PC AND SERVER",
        "img__src": "/laptop.jpg",
        "link__name": "DESKTOP PC AND SERVER",
        "links": [
             
            {
                "category": "Desktop PC",
                "link__name": "Desktop PC",
                "img__src": "/laptop.jpg",
                "parent": "DESKTOP PC AND SERVER",
                "type": "head",
                "other": true,
                "subCategory": "Desktop PC"
            },
            {
                "category": "All Desktop PC",
                "link__name": "Desktop PC",
                "img__src": "/laptop.jpg",
                "parent": "DESKTOP PC AND SERVER",
                "type": "link",
                "other": 2,
                "subCategory": "Desktop PC"
            },
            {
                "category": " Brand Desktop PC",
                "link__name": " Brand Desktop PC",
                "img__src": "/laptop.jpg",
                "parent": "DESKTOP PC AND SERVER",
                "type": "link",
                "other": 4,
                "subCategory": "Desktop PC"
            },
            {
                "category": " All In One PC",
                "link__name": " All In One PC",
                "img__src": "/laptop.jpg",
                "parent": "DESKTOP PC AND SERVER",
                "type": "link",
                "other": 4,
                "subCategory": "Desktop PC"
            },
            {
                "category": " Mini PC",
                "link__name": " Mini PC",
                "img__src": "/laptop.jpg",
                "parent": "DESKTOP PC AND SERVER",
                "type": "link",
                "other": 4,
                "subCategory": "Desktop PC"
            },
            {
                "category": " Ryans PC",
                "link__name": " Ryans PC",
                "img__src": "/laptop.jpg",
                "parent": "DESKTOP PC AND SERVER",
                "type": "link",
                "other": 4,
                "subCategory": "Desktop PC"
            },
            {
                "category": "Desktop Component",
                "link__name": "Desktop Component",
                "img__src": "/laptop.jpg",
                "parent": "DESKTOP PC AND SERVER",
                "type": "head",
                "other": true,
                "subCategory": "Desktop Component"
            },
            {
                "category": "All Desktop Component",
                "link__name": "Desktop Component",
                "img__src": "/laptop.jpg",
                "parent": "DESKTOP PC AND SERVER",
                "type": "link",
                "other": 2,
                "subCategory": "Desktop Component"
            },
            {
                "category": " Processor",
                "link__name": " Processor",
                "img__src": "/laptop.jpg",
                "parent": "DESKTOP PC AND SERVER",
                "type": "link",
                "other": 4,
                "subCategory": "Desktop Component"
            },
            {
                "category": " Motherboard",
                "link__name": " Motherboard",
                "img__src": "/laptop.jpg",
                "parent": "DESKTOP PC AND SERVER",
                "type": "link",
                "other": 4,
                "subCategory": "Desktop Component"
            },
            {
                "category": " Desktop Ram",
                "link__name": " Desktop Ram",
                "img__src": "/laptop.jpg",
                "parent": "DESKTOP PC AND SERVER",
                "type": "link",
                "other": 4,
                "subCategory": "Desktop Component"
            },
            {
                "category": " Optical Device",
                "link__name": " Optical Device",
                "img__src": "/laptop.jpg",
                "parent": "DESKTOP PC AND SERVER",
                "type": "link",
                "other": 4,
                "subCategory": "Desktop Component"
            },
            {
                "category": " Graphics Card",
                "link__name": " Graphics Card",
                "img__src": "/laptop.jpg",
                "parent": "DESKTOP PC AND SERVER",
                "type": "link",
                "other": 4,
                "subCategory": "Desktop Component"
            },
            {
                "category": " Power Supply",
                "link__name": " Power Supply",
                "img__src": "/laptop.jpg",
                "parent": "DESKTOP PC AND SERVER",
                "type": "link",
                "other": 4,
                "subCategory": "Desktop Component"
            },
            {
                "category": " Casing",
                "link__name": " Casing",
                "img__src": "/laptop.jpg",
                "parent": "DESKTOP PC AND SERVER",
                "type": "link",
                "other": 4,
                "subCategory": "Desktop Component"
            },
            {
                "category": " Casing Fan",
                "link__name": " Casing Fan",
                "img__src": "/laptop.jpg",
                "parent": "DESKTOP PC AND SERVER",
                "type": "link",
                "other": 4,
                "subCategory": "Desktop Component"
            },
            {
                "category": " CPU Cooler",
                "link__name": " CPU Cooler",
                "img__src": "/laptop.jpg",
                "parent": "DESKTOP PC AND SERVER",
                "type": "link",
                "other": 4,
                "subCategory": "Desktop Component"
            },
            {
                "category": " Keyboard",
                "link__name": " Keyboard",
                "img__src": "/laptop.jpg",
                "parent": "DESKTOP PC AND SERVER",
                "type": "link",
                "other": 4,
                "subCategory": "Desktop Component"
            },
            {
                "category": " Mouse",
                "link__name": " Mouse",
                "img__src": "/laptop.jpg",
                "parent": "DESKTOP PC AND SERVER",
                "type": "link",
                "other": 4,
                "subCategory": "Desktop Component"
            },
            {
                "category": " Keyboard and Mouse Combo",
                "link__name": " Keyboard and Mouse Combo",
                "img__src": "/laptop.jpg",
                "parent": "DESKTOP PC AND SERVER",
                "type": "link",
                "other": 4,
                "subCategory": "Desktop Component"
            },
            {
                "category": " Mouse Pad",
                "link__name": " Mouse Pad",
                "img__src": "/laptop.jpg",
                "parent": "DESKTOP PC AND SERVER",
                "type": "link",
                "other": 4,
                "subCategory": "Desktop Component"
            },
            {
                "category": " UPS",
                "link__name": " UPS",
                "img__src": "/laptop.jpg",
                "parent": "DESKTOP PC AND SERVER",
                "type": "link",
                "other": 4,
                "subCategory": "Desktop Component"
            },
            {
                "category": "Server",
                "link__name": "Server",
                "img__src": "/laptop.jpg",
                "parent": "DESKTOP PC AND SERVER",
                "type": "head",
                "other": true,
                "subCategory": "Server"
            },
            {
                "category": "All Server  Items",
                "link__name": "Server",
                "img__src": "/laptop.jpg",
                "parent": "DESKTOP PC AND SERVER",
                "type": "link",
                "other": 2,
                "subCategory": "Server"
            },
            {
                "category": " Rack",
                "link__name": " Rack",
                "img__src": "/laptop.jpg",
                "parent": "DESKTOP PC AND SERVER",
                "type": "link",
                "other": 4,
                "subCategory": "Server"
            },
            {
                "category": " Tower",
                "link__name": " Tower",
                "img__src": "/laptop.jpg",
                "parent": "DESKTOP PC AND SERVER",
                "type": "link",
                "other": 4,
                "subCategory": "Server"
            },
            {
                "category": "Server Component",
                "link__name": "Server Component",
                "img__src": "/laptop.jpg",
                "parent": "DESKTOP PC AND SERVER",
                "type": "head",
                "other": true,
                "subCategory": "Server Component"
            },
            {
                "category": "All Server Component",
                "link__name": "Server Component",
                "img__src": "/laptop.jpg",
                "parent": "DESKTOP PC AND SERVER",
                "type": "link",
                "other": 2,
                "subCategory": "Server Component"
            },
            {
                "category": " Server Cabinet",
                "link__name": " Server Cabinet",
                "img__src": "/laptop.jpg",
                "parent": "DESKTOP PC AND SERVER",
                "type": "link",
                "other": 4,
                "subCategory": "Server Component"
            },
            {
                "category": " Server Ram",
                "link__name": " Server Ram",
                "img__src": "/laptop.jpg",
                "parent": "DESKTOP PC AND SERVER",
                "type": "link",
                "other": 4,
                "subCategory": "Server Component"
            },
            {
                "category": "Desktop Accessories",
                "link__name": "Desktop Accessories",
                "img__src": "/laptop.jpg",
                "parent": "DESKTOP PC AND SERVER",
                "type": "head",
                "other": true,
                "subCategory": "Desktop Accessories"
            },
            {
                "category": "All Desktop Accessories",
                "link__name": "Desktop Accessories",
                "img__src": "/laptop.jpg",
                "parent": "DESKTOP PC AND SERVER",
                "type": "link",
                "other": 2,
                "subCategory": "Desktop Accessories"
            },
            {
                "category": " LED Strip",
                "link__name": " LED Strip",
                "img__src": "/laptop.jpg",
                "parent": "DESKTOP PC AND SERVER",
                "type": "link",
                "other": 4,
                "subCategory": "Desktop Accessories"
            },
            {
                "category": " Casing Accessories",
                "link__name": " Casing Accessories",
                "img__src": "/laptop.jpg",
                "parent": "DESKTOP PC AND SERVER",
                "type": "link",
                "other": 4,
                "subCategory": "Desktop Accessories"
            },
            {
                "category": " Side Panel",
                "link__name": " Side Panel",
                "img__src": "/laptop.jpg",
                "parent": "DESKTOP PC AND SERVER",
                "type": "link",
                "other": 4,
                "subCategory": "Desktop Accessories"
            },
            {
                "category": " Thermal Paste",
                "link__name": " Thermal Paste",
                "img__src": "/laptop.jpg",
                "parent": "DESKTOP PC AND SERVER",
                "type": "link",
                "other": 4,
                "subCategory": "Desktop Accessories"
            }
        ]
    },
    {
        "header": "GAMING",
        "img__src": "/laptop.jpg",
        "link__name": "GAMING",
        "links": [
 
            {
                "category": "Gaming Component",
                "link__name": "Gaming Component",
                "img__src": "/laptop.jpg",
                "parent": "GAMING",
                "type": "head",
                "other": true,
                "subCategory": "Gaming Component"
            },
            {
                "category": "All Gaming Component",
                "link__name": "Gaming Component",
                "img__src": "/laptop.jpg",
                "parent": "GAMING",
                "type": "link",
                "other": 2,
                "subCategory": "Gaming Component"
            },
            {
                "category": " Gaming Console",
                "link__name": " Gaming Console",
                "img__src": "/laptop.jpg",
                "parent": "GAMING",
                "type": "link",
                "other": 4,
                "subCategory": "Gaming Component"
            },
            {
                "category": " Gaming Controller",
                "link__name": " Gaming Controller",
                "img__src": "/laptop.jpg",
                "parent": "GAMING",
                "type": "link",
                "other": 4,
                "subCategory": "Gaming Component"
            },
            {
                "category": " Capture Card",
                "link__name": " Capture Card",
                "img__src": "/laptop.jpg",
                "parent": "GAMING",
                "type": "link",
                "other": 4,
                "subCategory": "Gaming Component"
            },
            {
                "category": " Games",
                "link__name": " Games",
                "img__src": "/laptop.jpg",
                "parent": "GAMING",
                "type": "link",
                "other": 4,
                "subCategory": "Gaming Component"
            },
            {
                "category": " Gaming Chair",
                "link__name": " Gaming Chair",
                "img__src": "/laptop.jpg",
                "parent": "GAMING",
                "type": "link",
                "other": 4,
                "subCategory": "Gaming Component"
            },
            {
                "category": " Gaming Desk",
                "link__name": " Gaming Desk",
                "img__src": "/laptop.jpg",
                "parent": "GAMING",
                "type": "link",
                "other": 4,
                "subCategory": "Gaming Component"
            },
            {
                "category": "Gaming Laptop",
                "link__name": "Gaming Laptop",
                "img__src": "/laptop.jpg",
                "parent": "GAMING",
                "type": "head",
                "other": true,
                "subCategory": "Gaming Laptop"
            },
            {
                "category": "All Gaming Laptop",
                "link__name": "Gaming Laptop",
                "img__src": "/laptop.jpg",
                "parent": "GAMING",
                "type": "link",
                "other": 2,
                "subCategory": "Gaming Laptop"
            },
            {
                "category": "Gaming Desktop PC",
                "link__name": "Gaming Desktop PC",
                "img__src": "/laptop.jpg",
                "parent": "GAMING",
                "type": "head",
                "other": true,
                "subCategory": "Gaming Desktop PC"
            },
            {
                "category": "All Gaming Desktop PC",
                "link__name": "Gaming Desktop PC",
                "img__src": "/laptop.jpg",
                "parent": "GAMING",
                "type": "link",
                "other": 2,
                "subCategory": "Gaming Desktop PC"
            },
            {
                "category": " Ryans PC",
                "link__name": " Ryans PC",
                "img__src": "/laptop.jpg",
                "parent": "GAMING",
                "type": "link",
                "other": 4,
                "subCategory": "Gaming Desktop PC"
            },
            {
                "category": "Gaming Desktop Component",
                "link__name": "Gaming Desktop Component",
                "img__src": "/laptop.jpg",
                "parent": "GAMING",
                "type": "head",
                "other": true,
                "subCategory": "Gaming Desktop Component"
            },
            {
                "category": "All Gaming Desktop Component",
                "link__name": "Gaming Desktop Component",
                "img__src": "/laptop.jpg",
                "parent": "GAMING",
                "type": "link",
                "other": 2,
                "subCategory": "Gaming Desktop Component"
            },
            {
                "category": " Motherboard",
                "link__name": " Motherboard",
                "img__src": "/laptop.jpg",
                "parent": "GAMING",
                "type": "link",
                "other": 4,
                "subCategory": "Gaming Desktop Component"
            },
            {
                "category": " Desktop Ram",
                "link__name": " Desktop Ram",
                "img__src": "/laptop.jpg",
                "parent": "GAMING",
                "type": "link",
                "other": 4,
                "subCategory": "Gaming Desktop Component"
            },
            {
                "category": " Graphics Card",
                "link__name": " Graphics Card",
                "img__src": "/laptop.jpg",
                "parent": "GAMING",
                "type": "link",
                "other": 4,
                "subCategory": "Gaming Desktop Component"
            },
            {
                "category": " Power Supply",
                "link__name": " Power Supply",
                "img__src": "/laptop.jpg",
                "parent": "GAMING",
                "type": "link",
                "other": 4,
                "subCategory": "Gaming Desktop Component"
            },
            {
                "category": " Casing",
                "link__name": " Casing",
                "img__src": "/laptop.jpg",
                "parent": "GAMING",
                "type": "link",
                "other": 4,
                "subCategory": "Gaming Desktop Component"
            },
            {
                "category": " CPU Cooler",
                "link__name": " CPU Cooler",
                "img__src": "/laptop.jpg",
                "parent": "GAMING",
                "type": "link",
                "other": 4,
                "subCategory": "Gaming Desktop Component"
            },
            {
                "category": " Keyboard",
                "link__name": " Keyboard",
                "img__src": "/laptop.jpg",
                "parent": "GAMING",
                "type": "link",
                "other": 4,
                "subCategory": "Gaming Desktop Component"
            },
            {
                "category": " Mouse",
                "link__name": " Mouse",
                "img__src": "/laptop.jpg",
                "parent": "GAMING",
                "type": "link",
                "other": 4,
                "subCategory": "Gaming Desktop Component"
            },
            {
                "category": " Mouse Pad",
                "link__name": " Mouse Pad",
                "img__src": "/laptop.jpg",
                "parent": "GAMING",
                "type": "link",
                "other": 4,
                "subCategory": "Gaming Desktop Component"
            },
            {
                "category": " LED Strip",
                "link__name": " LED Strip",
                "img__src": "/laptop.jpg",
                "parent": "GAMING",
                "type": "link",
                "other": 4,
                "subCategory": "Gaming Desktop Component"
            },
            {
                "category": "Gaming Monitor",
                "link__name": "Gaming Monitor",
                "img__src": "/laptop.jpg",
                "parent": "GAMING",
                "type": "head",
                "other": true,
                "subCategory": "Gaming Monitor"
            },
            {
                "category": "All Gaming Monitor",
                "link__name": "Gaming Monitor",
                "img__src": "/laptop.jpg",
                "parent": "GAMING",
                "type": "link",
                "other": 2,
                "subCategory": "Gaming Monitor"
            },
            {
                "category": "Sound System",
                "link__name": "Sound System",
                "img__src": "/laptop.jpg",
                "parent": "GAMING",
                "type": "head",
                "other": true,
                "subCategory": "Sound System"
            },
            {
                "category": "All Sound System",
                "link__name": "Sound System",
                "img__src": "/laptop.jpg",
                "parent": "GAMING",
                "type": "link",
                "other": 2,
                "subCategory": "Sound System"
            },
            {
                "category": " Speaker",
                "link__name": " Speaker",
                "img__src": "/laptop.jpg",
                "parent": "GAMING",
                "type": "link",
                "other": 4,
                "subCategory": "Sound System"
            },
            {
                "category": " Headphone",
                "link__name": " Headphone",
                "img__src": "/laptop.jpg",
                "parent": "GAMING",
                "type": "link",
                "other": 4,
                "subCategory": "Sound System"
            },
            {
                "category": " Microphone",
                "link__name": " Microphone",
                "img__src": "/laptop.jpg",
                "parent": "GAMING",
                "type": "link",
                "other": 4,
                "subCategory": "Sound System"
            },
            {
                "category": " Earphone",
                "link__name": " Earphone",
                "img__src": "/laptop.jpg",
                "parent": "GAMING",
                "type": "link",
                "other": 4,
                "subCategory": "Sound System"
            },
            {
                "category": "Network Router",
                "link__name": "Network Router",
                "img__src": "/laptop.jpg",
                "parent": "GAMING",
                "type": "link",
                "other": 3,
                "subCategory": "Network Router"
            }
        ]
    },
    {
        "header": "MONITOR",
        "img__src": "/laptop.jpg",
        "link__name": "MONITOR",
        "links": [
 
            {
                "category": "Monitor",
                "link__name": "All Monitor",
                "img__src": "/laptop.jpg",
                "parent": "MONITOR",
                "type": "head",
                "other": true,
                "subCategory": "All Monitor"
            },
            {
                "category": "All Monitor",
                "link__name": "All Monitor",
                "img__src": "/laptop.jpg",
                "parent": "MONITOR",
                "type": "link",
                "other": 2,
                "subCategory": "All Monitor"
            },
            {
                "category": " Asus",
                "link__name": " Asus",
                "img__src": "/laptop.jpg",
                "parent": "MONITOR",
                "type": "link",
                "other": 4,
                "subCategory": "All Monitor"
            },
            {
                "category": " Aoc",
                "link__name": " Aoc",
                "img__src": "/laptop.jpg",
                "parent": "MONITOR",
                "type": "link",
                "other": 4,
                "subCategory": "All Monitor"
            },
            {
                "category": " Acer",
                "link__name": " Acer",
                "img__src": "/laptop.jpg",
                "parent": "MONITOR",
                "type": "link",
                "other": 4,
                "subCategory": "All Monitor"
            },
            {
                "category": " Benq",
                "link__name": " Benq",
                "img__src": "/laptop.jpg",
                "parent": "MONITOR",
                "type": "link",
                "other": 4,
                "subCategory": "All Monitor"
            },
            {
                "category": " Dell",
                "link__name": " Dell",
                "img__src": "/laptop.jpg",
                "parent": "MONITOR",
                "type": "link",
                "other": 4,
                "subCategory": "All Monitor"
            },
            {
                "category": " Gigabyte",
                "link__name": " Gigabyte",
                "img__src": "/laptop.jpg",
                "parent": "MONITOR",
                "type": "link",
                "other": 4,
                "subCategory": "All Monitor"
            },
            {
                "category": " HP",
                "link__name": " HP",
                "img__src": "/laptop.jpg",
                "parent": "MONITOR",
                "type": "link",
                "other": 4,
                "subCategory": "All Monitor"
            },
            {
                "category": " Xiaomi",
                "link__name": " Xiaomi",
                "img__src": "/laptop.jpg",
                "parent": "MONITOR",
                "type": "link",
                "other": 4,
                "subCategory": "All Monitor"
            },
            {
                "category": " Gamemax",
                "link__name": " Gamemax",
                "img__src": "/laptop.jpg",
                "parent": "MONITOR",
                "type": "link",
                "other": 4,
                "subCategory": "All Monitor"
            },
            {
                "category": " LG",
                "link__name": " LG",
                "img__src": "/laptop.jpg",
                "parent": "MONITOR",
                "type": "link",
                "other": 4,
                "subCategory": "All Monitor"
            },
            {
                "category": " Lenovo",
                "link__name": " Lenovo",
                "img__src": "/laptop.jpg",
                "parent": "MONITOR",
                "type": "link",
                "other": 4,
                "subCategory": "All Monitor"
            },
            {
                "category": " MSI",
                "link__name": " MSI",
                "img__src": "/laptop.jpg",
                "parent": "MONITOR",
                "type": "link",
                "other": 4,
                "subCategory": "All Monitor"
            },
            {
                "category": " Philips",
                "link__name": " Philips",
                "img__src": "/laptop.jpg",
                "parent": "MONITOR",
                "type": "link",
                "other": 4,
                "subCategory": "All Monitor"
            },
            {
                "category": " Samsung",
                "link__name": " Samsung",
                "img__src": "/laptop.jpg",
                "parent": "MONITOR",
                "type": "link",
                "other": 4,
                "subCategory": "All Monitor"
            },
            {
                "category": " Viewsonic",
                "link__name": " Viewsonic",
                "img__src": "/laptop.jpg",
                "parent": "MONITOR",
                "type": "link",
                "other": 4,
                "subCategory": "All Monitor"
            },
            {
                "category": " Huawei",
                "link__name": " Huawei",
                "img__src": "/laptop.jpg",
                "parent": "MONITOR",
                "type": "link",
                "other": 4,
                "subCategory": "All Monitor"
            },
            {
                "category": " Fantech",
                "link__name": " Fantech",
                "img__src": "/laptop.jpg",
                "parent": "MONITOR",
                "type": "link",
                "other": 4,
                "subCategory": "All Monitor"
            },
            {
                "category": " Corsair",
                "link__name": " Corsair",
                "img__src": "/laptop.jpg",
                "parent": "MONITOR",
                "type": "link",
                "other": 4,
                "subCategory": "All Monitor"
            },
            {
                "category": " Hikvision",
                "link__name": " Hikvision",
                "img__src": "/laptop.jpg",
                "parent": "MONITOR",
                "type": "link",
                "other": 4,
                "subCategory": "All Monitor"
            },
            {
                "category": " INNOVTECH",
                "link__name": " INNOVTECH",
                "img__src": "/laptop.jpg",
                "parent": "MONITOR",
                "type": "link",
                "other": 4,
                "subCategory": "All Monitor"
            },
            {
                "category": " Razer",
                "link__name": " Razer",
                "img__src": "/laptop.jpg",
                "parent": "MONITOR",
                "type": "link",
                "other": 4,
                "subCategory": "All Monitor"
            },
            {
                "category": "Monitor Accessories",
                "link__name": "Monitor Accessories",
                "img__src": "/laptop.jpg",
                "parent": "MONITOR",
                "type": "head",
                "other": true,
                "subCategory": "Monitor Accessories"
            },
            {
                "category": "All Monitor Accessories",
                "link__name": "Monitor Accessories",
                "img__src": "/laptop.jpg",
                "parent": "MONITOR",
                "type": "link",
                "other": 2,
                "subCategory": "Monitor Accessories"
            },
            {
                "category": " Monitor Mounts and Brackets",
                "link__name": " Monitor Mounts and Brackets",
                "img__src": "/laptop.jpg",
                "parent": "MONITOR",
                "type": "link",
                "other": 4,
                "subCategory": "Monitor Accessories"
            }
        ]
    },
    {
        "header": "TABLET",
        "img__src": "/laptop.jpg",
        "link__name": "TABLET",
        "links": [
         
            {
                "category": "Regular Tablet",
                "link__name": "Regular Tablet",
                "img__src": "/laptop.jpg",
                "parent": "TABLET",
                "type": "head",
                "other": true,
                "subCategory": "Regular Tablet"
            },
            {
                "category": " All Brands",
                "link__name": " All Brands",
                "img__src": "/laptop.jpg",
                "parent": "TABLET",
                "type": "link",
                "other": 2,
                "subCategory": "Regular Tablet"
            },
            {
                "category": " Amazon",
                "link__name": " Amazon",
                "img__src": "/laptop.jpg",
                "parent": "TABLET",
                "type": "link",
                "other": 4,
                "subCategory": "Regular Tablet"
            },
            {
                "category": " Lenovo",
                "link__name": " Lenovo",
                "img__src": "/laptop.jpg",
                "parent": "TABLET",
                "type": "link",
                "other": 4,
                "subCategory": "Regular Tablet"
            },
            {
                "category": " Samsung",
                "link__name": " Samsung",
                "img__src": "/laptop.jpg",
                "parent": "TABLET",
                "type": "link",
                "other": 4,
                "subCategory": "Regular Tablet"
            },
            {
                "category": " Huawei",
                "link__name": " Huawei",
                "img__src": "/laptop.jpg",
                "parent": "TABLET",
                "type": "link",
                "other": 4,
                "subCategory": "Regular Tablet"
            },
            {
                "category": "Apple Tablet",
                "link__name": "Apple Tablet",
                "img__src": "/laptop.jpg",
                "parent": "TABLET",
                "type": "head",
                "other": true,
                "subCategory": "Apple Tablet"
            },
            {
                "category": "All Apple Tablet",
                "link__name": "Apple Tablet",
                "img__src": "/laptop.jpg",
                "parent": "TABLET",
                "type": "link",
                "other": 2,
                "subCategory": "Apple Tablet"
            },
            {
                "category": " iPad",
                "link__name": " iPad",
                "img__src": "/laptop.jpg",
                "parent": "TABLET",
                "type": "link",
                "other": 4,
                "subCategory": "Apple Tablet"
            },
            {
                "category": "E-Reader Tablet",
                "link__name": "E-Reader Tablet",
                "img__src": "/laptop.jpg",
                "parent": "TABLET",
                "type": "head",
                "other": true,
                "subCategory": "E-Reader Tablet"
            },
            {
                "category": "All E-Reader Tablet",
                "link__name": "E-Reader Tablet",
                "img__src": "/laptop.jpg",
                "parent": "TABLET",
                "type": "link",
                "other": 2,
                "subCategory": "E-Reader Tablet"
            },
            {
                "category": " Amazon",
                "link__name": " Amazon",
                "img__src": "/laptop.jpg",
                "parent": "TABLET",
                "type": "link",
                "other": 4,
                "subCategory": "E-Reader Tablet"
            },
            {
                "category": "Kids Tablet",
                "link__name": "Kids Tablet",
                "img__src": "/laptop.jpg",
                "parent": "TABLET",
                "type": "link",
                "other": 3,
                "subCategory": "Kids Tablet"
            }, 
            {
                "category": "Graphics Tablet",
                "link__name": "Graphics Tablet",
                "img__src": "/laptop.jpg",
                "parent": "TABLET",
                "type": "head",
                "other": true,
                "subCategory": "Graphics Tablet"
            }, 
            {
                "category": " All Brands",
                "link__name": " All Brands",
                "img__src": "/laptop.jpg",
                "parent": "TABLET",
                "type": "link",
                "other": 2,
                "subCategory": "Graphics Tablet"
            },
            {
                "category": " Wacom",
                "link__name": " Wacom",
                "img__src": "/laptop.jpg",
                "parent": "TABLET",
                "type": "link",
                "other": 4,
                "subCategory": "Graphics Tablet"
            },
            {
                "category": " XP-PEN",
                "link__name": " XP-PEN",
                "img__src": "/laptop.jpg",
                "parent": "TABLET",
                "type": "link",
                "other": 4,
                "subCategory": "Graphics Tablet"
            },
            {
                "category": " Xiaomi",
                "link__name": " Xiaomi",
                "img__src": "/laptop.jpg",
                "parent": "TABLET",
                "type": "link",
                "other": 4,
                "subCategory": "Graphics Tablet"
            },
            {
                "category": "Mobile and Tablet Accessories",
                "link__name": "Mobile and Tablet Accessories",
                "img__src": "/laptop.jpg",
                "parent": "TABLET",
                "type": "head",
                "other": true,
                "subCategory": "Mobile and Tablet Accessories"
            },
            {
                "category": "All Mobile and Tablet Accessories",
                "link__name": "Mobile and Tablet Accessories",
                "img__src": "/laptop.jpg",
                "parent": "TABLET",
                "type": "link",
                "other": 2,
                "subCategory": "Mobile and Tablet Accessories"
            },
            {
                "category": " Power Bank",
                "link__name": " Power Bank",
                "img__src": "/laptop.jpg",
                "parent": "TABLET",
                "type": "link",
                "other": 4,
                "subCategory": "Mobile and Tablet Accessories"
            },
            {
                "category": " Car Charger",
                "link__name": " Car Charger",
                "img__src": "/laptop.jpg",
                "parent": "TABLET",
                "type": "link",
                "other": 4,
                "subCategory": "Mobile and Tablet Accessories"
            },
            {
                "category": " Wireless Charger",
                "link__name": " Wireless Charger",
                "img__src": "/laptop.jpg",
                "parent": "TABLET",
                "type": "link",
                "other": 4,
                "subCategory": "Mobile and Tablet Accessories"
            },
            {
                "category": " Wall Charger",
                "link__name": " Wall Charger",
                "img__src": "/laptop.jpg",
                "parent": "TABLET",
                "type": "link",
                "other": 4,
                "subCategory": "Mobile and Tablet Accessories"
            },
            {
                "category": " Cable Organizer",
                "link__name": " Cable Organizer",
                "img__src": "/laptop.jpg",
                "parent": "TABLET",
                "type": "link",
                "other": 4,
                "subCategory": "Mobile and Tablet Accessories"
            },
            {
                "category": " Phone Holder",
                "link__name": " Phone Holder",
                "img__src": "/laptop.jpg",
                "parent": "TABLET",
                "type": "link",
                "other": 4,
                "subCategory": "Mobile and Tablet Accessories"
            },
            {
                "category": " Screen Cleaner",
                "link__name": " Screen Cleaner",
                "img__src": "/laptop.jpg",
                "parent": "TABLET",
                "type": "link",
                "other": 4,
                "subCategory": "Mobile and Tablet Accessories"
            }
        ]
    },
    {
        "header": "PRINTER",
        "img__src": "/laptop.jpg",
        "link__name": "PRINTER",
        "links": [
   
            {
                "category": "All Laser and INK Printer",
                "link__name": "All Laser and INK Printer",
                "img__src": "/laptop.jpg",
                "parent": "PRINTER",
                "type": "head",
                "other": true,
                "subCategory": "All Laser and INK Printer"
            },
            {
                "category": "All Laser and INK Printer",
                "link__name": "All Laser and INK Printer",
                "img__src": "/laptop.jpg",
                "parent": "PRINTER",
                "type": "link",
                "other": 2,
                "subCategory": "All Laser and INK Printer"
            },
            {
                "category": " Laser Printer",
                "link__name": " Laser Printer",
                "img__src": "/laptop.jpg",
                "parent": "PRINTER",
                "type": "link",
                "other": 4,
                "subCategory": "All Laser and INK Printer"
            },
            {
                "category": " Ink Printer",
                "link__name": " Ink Printer",
                "img__src": "/laptop.jpg",
                "parent": "PRINTER",
                "type": "link",
                "other": 4,
                "subCategory": "All Laser and INK Printer"
            },
            {
                "category": "Label Printer",
                "link__name": "Label Printer",
                "img__src": "/laptop.jpg",
                "parent": "PRINTER",
                "type": "link",
                "other": 3,
                "subCategory": "Label Printer"
            }, 
            {
                "category": "Card Printer",
                "link__name": "Card Printer",
                "img__src": "/laptop.jpg",
                "parent": "PRINTER",
                "type": "link",
                "other": 3,
                "subCategory": "Card Printer"
            }, 
            {
                "category": "Dot Matrix Printer",
                "link__name": "Dot Matrix Printer",
                "img__src": "/laptop.jpg",
                "parent": "PRINTER",
                "type": "link",
                "other": 3,
                "subCategory": "Dot Matrix Printer"
            },
            {
                "category": "POS Printer",
                "link__name": "POS Printer",
                "img__src": "/laptop.jpg",
                "parent": "PRINTER",
                "type": "link",
                "other": 3,
                "subCategory": "POS Printer"
            }, 
            {
                "category": "Large Format Printer",
                "link__name": "Large Format Printer",
                "img__src": "/laptop.jpg",
                "parent": "PRINTER",
                "type": "link",
                "other": 3,
                "subCategory": "Large Format Printer"
            }, 
            {
                "category": "Printer Paper",
                "link__name": "Printer Paper",
                "img__src": "/laptop.jpg",
                "parent": "PRINTER",
                "type": "link",
                "other": 3,
                "subCategory": "Printer Paper"
            }, 
            {
                "category": "Consumable",
                "link__name": "Consumable",
                "img__src": "/laptop.jpg",
                "parent": "PRINTER",
                "type": "head",
                "other": true,
                "subCategory": "Consumable"
            },
            {
                "category": "All Consumable",
                "link__name": "Consumable",
                "img__src": "/laptop.jpg",
                "parent": "PRINTER",
                "type": "link",
                "other": 2,
                "subCategory": "Consumable"
            },
            {
                "category": " Toner",
                "link__name": " Toner",
                "img__src": "/laptop.jpg",
                "parent": "PRINTER",
                "type": "link",
                "other": 4,
                "subCategory": "Consumable"
            },
            {
                "category": " Cartridge",
                "link__name": " Cartridge",
                "img__src": "/laptop.jpg",
                "parent": "PRINTER",
                "type": "link",
                "other": 4,
                "subCategory": "Consumable"
            },
            {
                "category": " Ribbon",
                "link__name": " Ribbon",
                "img__src": "/laptop.jpg",
                "parent": "PRINTER",
                "type": "link",
                "other": 4,
                "subCategory": "Consumable"
            },
            {
                "category": " Refill",
                "link__name": " Refill",
                "img__src": "/laptop.jpg",
                "parent": "PRINTER",
                "type": "link",
                "other": 4,
                "subCategory": "Consumable"
            },
            {
                "category": " Drum Unit",
                "link__name": " Drum Unit",
                "img__src": "/laptop.jpg",
                "parent": "PRINTER",
                "type": "link",
                "other": 4,
                "subCategory": "Consumable"
            },
            {
                "category": " Print Head",
                "link__name": " Print Head",
                "img__src": "/laptop.jpg",
                "parent": "PRINTER",
                "type": "link",
                "other": 4,
                "subCategory": "Consumable"
            },
            {
                "category": " Accessories",
                "link__name": " Accessories",
                "img__src": "/laptop.jpg",
                "parent": "PRINTER",
                "type": "link",
                "other": 4,
                "subCategory": "Consumable"
            }
        ]
    },
    {
        "header": "SCANNER",
        "img__src": "/laptop.jpg",
        "link__name": "SCANNER",
        "links": [
 
            {
                "category": "Flatbed Scanner",
                "link__name": "Flatbed Scanner",
                "img__src": "/laptop.jpg",
                "parent": "SCANNER",
                "type": "head",
                "other": true,
                "subCategory": "Flatbed Scanner"
            },
            {
                "category": "All Flatbed Scanner",
                "link__name": "Flatbed Scanner",
                "img__src": "/laptop.jpg",
                "parent": "SCANNER",
                "type": "link",
                "other": 2,
                "subCategory": "Flatbed Scanner"
            },
            {
                "category": " Canon",
                "link__name": " Canon",
                "img__src": "/laptop.jpg",
                "parent": "SCANNER",
                "type": "link",
                "other": 4,
                "subCategory": "Flatbed Scanner"
            },
            {
                "category": " Epson",
                "link__name": " Epson",
                "img__src": "/laptop.jpg",
                "parent": "SCANNER",
                "type": "link",
                "other": 4,
                "subCategory": "Flatbed Scanner"
            },
            {
                "category": " HP",
                "link__name": " HP",
                "img__src": "/laptop.jpg",
                "parent": "SCANNER",
                "type": "link",
                "other": 4,
                "subCategory": "Flatbed Scanner"
            },
            {
                "category": " Plustek",
                "link__name": " Plustek",
                "img__src": "/laptop.jpg",
                "parent": "SCANNER",
                "type": "link",
                "other": 4,
                "subCategory": "Flatbed Scanner"
            },
            {
                "category": " Avision",
                "link__name": " Avision",
                "img__src": "/laptop.jpg",
                "parent": "SCANNER",
                "type": "link",
                "other": 4,
                "subCategory": "Flatbed Scanner"
            },
            {
                "category": "Sheetfed and Flatbed Scanner",
                "link__name": "Sheetfed and Flatbed Scanner",
                "img__src": "/laptop.jpg",
                "parent": "SCANNER",
                "type": "head",
                "other": true,
                "subCategory": "Sheetfed and Flatbed Scanner"
            },
            {
                "category": "All Sheetfed and Flatbed Scanner",
                "link__name": "Sheetfed and Flatbed Scanner",
                "img__src": "/laptop.jpg",
                "parent": "SCANNER",
                "type": "link",
                "other": 2,
                "subCategory": "Sheetfed and Flatbed Scanner"
            },
            {
                "category": " Canon",
                "link__name": " Canon",
                "img__src": "/laptop.jpg",
                "parent": "SCANNER",
                "type": "link",
                "other": 4,
                "subCategory": "Sheetfed and Flatbed Scanner"
            },
            {
                "category": " Epson",
                "link__name": " Epson",
                "img__src": "/laptop.jpg",
                "parent": "SCANNER",
                "type": "link",
                "other": 4,
                "subCategory": "Sheetfed and Flatbed Scanner"
            },
            {
                "category": " HP",
                "link__name": " HP",
                "img__src": "/laptop.jpg",
                "parent": "SCANNER",
                "type": "link",
                "other": 4,
                "subCategory": "Sheetfed and Flatbed Scanner"
            },
            {
                "category": " Plustek",
                "link__name": " Plustek",
                "img__src": "/laptop.jpg",
                "parent": "SCANNER",
                "type": "link",
                "other": 4,
                "subCategory": "Sheetfed and Flatbed Scanner"
            },
            {
                "category": " Brother",
                "link__name": " Brother",
                "img__src": "/laptop.jpg",
                "parent": "SCANNER",
                "type": "link",
                "other": 4,
                "subCategory": "Sheetfed and Flatbed Scanner"
            },
            {
                "category": "Barcode Scanner",
                "link__name": "Barcode Scanner",
                "img__src": "/laptop.jpg",
                "parent": "SCANNER",
                "type": "head",
                "other": true,
                "subCategory": "Barcode Scanner"
            },
            {
                "category": "All Barcode Scanner",
                "link__name": "Barcode Scanner",
                "img__src": "/laptop.jpg",
                "parent": "SCANNER",
                "type": "link",
                "other": 2,
                "subCategory": "Barcode Scanner"
            },
            {
                "category": " Zebex",
                "link__name": " Zebex",
                "img__src": "/laptop.jpg",
                "parent": "SCANNER",
                "type": "link",
                "other": 4,
                "subCategory": "Barcode Scanner"
            },
            {
                "category": " Sewoo",
                "link__name": " Sewoo",
                "img__src": "/laptop.jpg",
                "parent": "SCANNER",
                "type": "link",
                "other": 4,
                "subCategory": "Barcode Scanner"
            },
            {
                "category": " Honeywell",
                "link__name": " Honeywell",
                "img__src": "/laptop.jpg",
                "parent": "SCANNER",
                "type": "link",
                "other": 4,
                "subCategory": "Barcode Scanner"
            },
            {
                "category": " Rongta",
                "link__name": " Rongta",
                "img__src": "/laptop.jpg",
                "parent": "SCANNER",
                "type": "link",
                "other": 4,
                "subCategory": "Barcode Scanner"
            },
            {
                "category": " Zebra",
                "link__name": " Zebra",
                "img__src": "/laptop.jpg",
                "parent": "SCANNER",
                "type": "link",
                "other": 4,
                "subCategory": "Barcode Scanner"
            },
            {
                "category": "Document and Book Scanner",
                "link__name": "Document and Book Scanner",
                "img__src": "/laptop.jpg",
                "parent": "SCANNER",
                "type": "head",
                "other": true,
                "subCategory": "Document and Book Scanner"
            },
            {
                "category": "All Document and Book Scanner",
                "link__name": "Document and Book Scanner",
                "img__src": "/laptop.jpg",
                "parent": "SCANNER",
                "type": "link",
                "other": 2,
                "subCategory": "Document and Book Scanner"
            },
            {
                "category": " CZUR",
                "link__name": " CZUR",
                "img__src": "/laptop.jpg",
                "parent": "SCANNER",
                "type": "link",
                "other": 4,
                "subCategory": "Document and Book Scanner"
            },
            {
                "category": "Portable Scanner",
                "link__name": "Portable Scanner",
                "img__src": "/laptop.jpg",
                "parent": "SCANNER",
                "type": "head",
                "other": true,
                "subCategory": "Portable Scanner"
            },
            {
                "category": "All Portable Scanner",
                "link__name": "Portable Scanner",
                "img__src": "/laptop.jpg",
                "parent": "SCANNER",
                "type": "link",
                "other": 2,
                "subCategory": "Portable Scanner"
            },
            {
                "category": " Plustek",
                "link__name": " Plustek",
                "img__src": "/laptop.jpg",
                "parent": "SCANNER",
                "type": "link",
                "other": 4,
                "subCategory": "Portable Scanner"
            },
            {
                "category": "Cheque Scanner",
                "link__name": "Cheque Scanner",
                "img__src": "/laptop.jpg",
                "parent": "SCANNER",
                "type": "head",
                "other": true,
                "subCategory": "Cheque Scanner"
            },
            {
                "category": "All Cheque Scanner",
                "link__name": "Cheque Scanner",
                "img__src": "/laptop.jpg",
                "parent": "SCANNER",
                "type": "link",
                "other": 2,
                "subCategory": "Cheque Scanner"
            },
            {
                "category": " Canon",
                "link__name": " Canon",
                "img__src": "/laptop.jpg",
                "parent": "SCANNER",
                "type": "link",
                "other": 4,
                "subCategory": "Cheque Scanner"
            }
        ]
    },
    {
        "header": "PHOTOCOPIER",
        "img__src": "/laptop.jpg",
        "link__name": "PHOTOCOPIER",
        "links": [
 
            {
                "category": "Photocopier",
                "link__name": "All Photocopier",
                "img__src": "/laptop.jpg",
                "parent": "PHOTOCOPIER",
                "type": "head",
                "other": true,
                "subCategory": "All Photocopier"
            },
            {
                "category": "All Photocopier",
                "link__name": "All Photocopier",
                "img__src": "/laptop.jpg",
                "parent": "PHOTOCOPIER",
                "type": "link",
                "other": 2,
                "subCategory": "All Photocopier"
            },
            {
                "category": " Canon",
                "link__name": " Canon",
                "img__src": "/laptop.jpg",
                "parent": "PHOTOCOPIER",
                "type": "link",
                "other": 4,
                "subCategory": "All Photocopier"
            },
            {
                "category": " HP",
                "link__name": " HP",
                "img__src": "/laptop.jpg",
                "parent": "PHOTOCOPIER",
                "type": "link",
                "other": 4,
                "subCategory": "All Photocopier"
            },
            {
                "category": " Ricoh",
                "link__name": " Ricoh",
                "img__src": "/laptop.jpg",
                "parent": "PHOTOCOPIER",
                "type": "link",
                "other": 4,
                "subCategory": "All Photocopier"
            },
            {
                "category": " Sharp",
                "link__name": " Sharp",
                "img__src": "/laptop.jpg",
                "parent": "PHOTOCOPIER",
                "type": "link",
                "other": 4,
                "subCategory": "All Photocopier"
            },
            {
                "category": " Toshiba",
                "link__name": " Toshiba",
                "img__src": "/laptop.jpg",
                "parent": "PHOTOCOPIER",
                "type": "link",
                "other": 4,
                "subCategory": "All Photocopier"
            },
            {
                "category": "Photocopier Accessories",
                "link__name": "Photocopier Accessories",
                "img__src": "/laptop.jpg",
                "parent": "PHOTOCOPIER",
                "type": "link",
                "other": 3,
                "subCategory": "Photocopier Accessories"
            }, 
        ]
    },
    {
        "header": "PROJECTOR",
        "img__src": "/laptop.jpg",
        "link__name": "PROJECTOR",
        "links": [

            {
                "category": "Projector",
                "link__name": "All Projector",
                "img__src": "/laptop.jpg",
                "parent": "PROJECTOR",
                "type": "head",
                "other": true,
                "subCategory": "All Projector"
            },
            {
                "category": "All Projector",
                "link__name": "All Projector",
                "img__src": "/laptop.jpg",
                "parent": "PROJECTOR",
                "type": "link",
                "other": 2,
                "subCategory": "All Projector"
            },
            {
                "category": " Maxell",
                "link__name": " Maxell",
                "img__src": "/laptop.jpg",
                "parent": "PROJECTOR",
                "type": "link",
                "other": 4,
                "subCategory": "All Projector"
            },
            {
                "category": " Benq",
                "link__name": " Benq",
                "img__src": "/laptop.jpg",
                "parent": "PROJECTOR",
                "type": "link",
                "other": 4,
                "subCategory": "All Projector"
            },
            {
                "category": " Optoma",
                "link__name": " Optoma",
                "img__src": "/laptop.jpg",
                "parent": "PROJECTOR",
                "type": "link",
                "other": 4,
                "subCategory": "All Projector"
            },
            {
                "category": " ViewSonic",
                "link__name": " ViewSonic",
                "img__src": "/laptop.jpg",
                "parent": "PROJECTOR",
                "type": "link",
                "other": 4,
                "subCategory": "All Projector"
            },
            {
                "category": " Micropack",
                "link__name": " Micropack",
                "img__src": "/laptop.jpg",
                "parent": "PROJECTOR",
                "type": "link",
                "other": 4,
                "subCategory": "All Projector"
            },
            {
                "category": " Asus",
                "link__name": " Asus",
                "img__src": "/laptop.jpg",
                "parent": "PROJECTOR",
                "type": "link",
                "other": 4,
                "subCategory": "All Projector"
            },
            {
                "category": " Epson",
                "link__name": " Epson",
                "img__src": "/laptop.jpg",
                "parent": "PROJECTOR",
                "type": "link",
                "other": 4,
                "subCategory": "All Projector"
            },
            {
                "category": " Vivitek",
                "link__name": " Vivitek",
                "img__src": "/laptop.jpg",
                "parent": "PROJECTOR",
                "type": "link",
                "other": 4,
                "subCategory": "All Projector"
            },
            {
                "category": " Casio",
                "link__name": " Casio",
                "img__src": "/laptop.jpg",
                "parent": "PROJECTOR",
                "type": "link",
                "other": 4,
                "subCategory": "All Projector"
            },
            {
                "category": "Projector Screen",
                "link__name": "Projector Screen",
                "img__src": "/laptop.jpg",
                "parent": "PROJECTOR",
                "type": "link",
                "other": 3,
                "subCategory": "Projector Screen"
            }, 
            {
                "category": "Digital Display",
                "link__name": "Digital Display",
                "img__src": "/laptop.jpg",
                "parent": "PROJECTOR",
                "type": "head",
                "other": true,
                "subCategory": "Digital Display"
            },
            {
                "category": "All Digital Display",
                "link__name": "Digital Display",
                "img__src": "/laptop.jpg",
                "parent": "PROJECTOR",
                "type": "link",
                "other": 2,
                "subCategory": "Digital Display"
            },
            {
                "category": " Interactive Panel",
                "link__name": " Interactive Panel",
                "img__src": "/laptop.jpg",
                "parent": "PROJECTOR",
                "type": "link",
                "other": 4,
                "subCategory": "Digital Display"
            },
            {
                "category": " Digital Signage",
                "link__name": " Digital Signage",
                "img__src": "/laptop.jpg",
                "parent": "PROJECTOR",
                "type": "link",
                "other": 4,
                "subCategory": "Digital Display"
            },
            {
                "category": "Presenter",
                "link__name": "Presenter",
                "img__src": "/laptop.jpg",
                "parent": "PROJECTOR",
                "type": "link",
                "other": 3,
                "subCategory": "Presenter"
            }, 
            {
                "category": "Ceiling Mount kit",
                "link__name": "Ceiling Mount kit",
                "img__src": "/laptop.jpg",
                "parent": "PROJECTOR",
                "type": "link",
                "other": 3,
                "subCategory": "Ceiling Mount kit"
            },
            {
                "category": "Projector Accessories",
                "link__name": "Projector Accessories",
                "img__src": "/laptop.jpg",
                "parent": "PROJECTOR",
                "type": "link",
                "other": 3,
                "subCategory": "Projector Accessories"
            } , 
        ]
    },
    {
        "header": "CAMERA",
        "img__src": "/laptop.jpg",
        "link__name": "CAMERA",
        "links": [
 
            {
                "category": "Digital SLR Camera",
                "link__name": "Digital SLR Camera",
                "img__src": "/laptop.jpg",
                "parent": "CAMERA",
                "type": "head",
                "other": true,
                "subCategory": "Digital SLR Camera"
            },
            {
                "category": "All Digital SLR Camera",
                "link__name": "Digital SLR Camera",
                "img__src": "/laptop.jpg",
                "parent": "CAMERA",
                "type": "link",
                "other": 3,
                "subCategory": "Digital SLR Camera"
            },
            {
                "category": " DSLR Camera",
                "link__name": " DSLR Camera",
                "img__src": "/laptop.jpg",
                "parent": "CAMERA",
                "type": "link",
                "other": 4,
                "subCategory": "Digital SLR Camera"
            },
            {
                "category": " Mirrorless Camera",
                "link__name": " Mirrorless Camera",
                "img__src": "/laptop.jpg",
                "parent": "CAMERA",
                "type": "link",
                "other": 4,
                "subCategory": "Digital SLR Camera"
            },
            {
                "category": " DSLR Camera Lens",
                "link__name": " DSLR Camera Lens",
                "img__src": "/laptop.jpg",
                "parent": "CAMERA",
                "type": "link",
                "other": 4,
                "subCategory": "Digital SLR Camera"
            },
            {
                "category": " DSLR Camera Accessories",
                "link__name": " DSLR Camera Accessories",
                "img__src": "/laptop.jpg",
                "parent": "CAMERA",
                "type": "link",
                "other": 4,
                "subCategory": "Digital SLR Camera"
            },
            {
                "category": "Digital Compact Camera",
                "link__name": "Digital Compact Camera",
                "img__src": "/laptop.jpg",
                "parent": "CAMERA",
                "type": "head",
                "other": true,
                "subCategory": "Digital Compact Camera"
            },
            {
                "category": "All Digital Compact Camera",
                "link__name": "Digital Compact Camera",
                "img__src": "/laptop.jpg",
                "parent": "CAMERA",
                "type": "link",
                "other": 2,
                "subCategory": "Digital Compact Camera"
            },
            {
                "category": " Compact Camera",
                "link__name": " Compact Camera",
                "img__src": "/laptop.jpg",
                "parent": "CAMERA",
                "type": "link",
                "other": 4,
                "subCategory": "Digital Compact Camera"
            },
            {
                "category": " Handy Camera",
                "link__name": " Handy Camera",
                "img__src": "/laptop.jpg",
                "parent": "CAMERA",
                "type": "link",
                "other": 4,
                "subCategory": "Digital Compact Camera"
            },
            {
                "category": " Action Camera",
                "link__name": " Action Camera",
                "img__src": "/laptop.jpg",
                "parent": "CAMERA",
                "type": "link",
                "other": 4,
                "subCategory": "Digital Compact Camera"
            },
            {
                "category": " Compact Camera Accessories",
                "link__name": " Compact Camera Accessories",
                "img__src": "/laptop.jpg",
                "parent": "CAMERA",
                "type": "link",
                "other": 4,
                "subCategory": "Digital Compact Camera"
            },
            {
                "category": "Video Camera",
                "link__name": "Video Camera",
                "img__src": "/laptop.jpg",
                "parent": "CAMERA",
                "type": "link",
                "other": 3,
                "subCategory": "Video Camera"
            }, 
            {
                "category": "Webcam",
                "link__name": "Webcam",
                "img__src": "/laptop.jpg",
                "parent": "CAMERA",
                "type": "link",
                "other": 3,
                "subCategory": "Webcam"
            },
            {
                "category": "Drone",
                "link__name": "Drone",
                "img__src": "/laptop.jpg",
                "parent": "CAMERA",
                "type": "link",
                "other": 3,
                "subCategory": "Drone"
            }, 
        ]
    },
    {
        "header": "SECURITY SYSTEM",
        "img__src": "/laptop.jpg",
        "link__name": "SECURITY SYSTEM",
        "links": [
            
            {
                "category": "CC Camera",
                "link__name": "CC Camera",
                "img__src": "/laptop.jpg",
                "parent": "SECURITY SYSTEM",
                "type": "link",
                "other": 3,
                "subCategory": "CC Camera"
            },
            {
                "category": "IP Camera",
                "link__name": "IP Camera",
                "img__src": "/laptop.jpg",
                "parent": "SECURITY SYSTEM",
                "type": "link",
                "other": 3,
                "subCategory": "IP Camera"
            },
            {
                "category": "Wireless Camera",
                "link__name": "Wireless Camera",
                "img__src": "/laptop.jpg",
                "parent": "SECURITY SYSTEM",
                "type": "link",
                "other": 3,
                "subCategory": "Wireless Camera"
            },
            {
                "category": "DVR",
                "link__name": "DVR",
                "img__src": "/laptop.jpg",
                "parent": "SECURITY SYSTEM",
                "type": "link",
                "other": 3,
                "subCategory": "DVR"
            },
            {
                "category": "NVR",
                "link__name": "NVR",
                "img__src": "/laptop.jpg",
                "parent": "SECURITY SYSTEM",
                "type": "link",
                "other": 3,
                "subCategory": "NVR"
            },
            {
                "category": "XVR",
                "link__name": "XVR",
                "img__src": "/laptop.jpg",
                "parent": "SECURITY SYSTEM",
                "type": "link",
                "other": 3,
                "subCategory": "XVR"
            },
            {
                "category": "CC/IP Camera Accessories",
                "link__name": "CC/IP Camera Accessories",
                "img__src": "/laptop.jpg",
                "parent": "SECURITY SYSTEM",
                "type": "link",
                "other": 3,
                "subCategory": "CC/IP Camera Accessories"
            }, 
            {
                "category": "Smart Lock, Door Bell and Video Door Phone",
                "link__name": "Smart Lock, Door Bell and Video Door Phone",
                "img__src": "/laptop.jpg",
                "parent": "SECURITY SYSTEM",
                "type": "link",
                "other": 3,
                "subCategory": "Smart Lock, Door Bell and Video Door Phone"
            },
            {
                "category": "Time Attendance System",
                "link__name": "Time Attendance System",
                "img__src": "/laptop.jpg",
                "parent": "SECURITY SYSTEM",
                "type": "head",
                "other": true,
                "subCategory": "Time Attendance System"
            },
            {
                "category": "All Time Attendance System",
                "link__name": "Time Attendance System",
                "img__src": "/laptop.jpg",
                "parent": "SECURITY SYSTEM",
                "type": "link",
                "other": 2,
                "subCategory": "Time Attendance System"
            },
            {
                "category": " Access Control",
                "link__name": " Access Control",
                "img__src": "/laptop.jpg",
                "parent": "SECURITY SYSTEM",
                "type": "link",
                "other": 4,
                "subCategory": "Time Attendance System"
            },
            {
                "category": " Access Control Accessories",
                "link__name": " Access Control Accessories",
                "img__src": "/laptop.jpg",
                "parent": "SECURITY SYSTEM",
                "type": "link",
                "other": 4,
                "subCategory": "Time Attendance System"
            }
        ]
    },
    {
        "header": "NETWORK",
        "img__src": "/laptop.jpg",
        "link__name": "NETWORK",
        "links": [
 
            {
                "category": "Network Router",
                "link__name": "Network Router",
                "img__src": "/laptop.jpg",
                "parent": "NETWORK",
                "type": "link",
                "other": 3,
                "subCategory": "Network Router"
            },
            {
                "category": "Access Point",
                "link__name": "Access Point",
                "img__src": "/laptop.jpg",
                "parent": "NETWORK",
                "type": "link",
                "other": 3,
                "subCategory": "Access Point"
            },
            {
                "category": "Range Extender",
                "link__name": "Range Extender",
                "img__src": "/laptop.jpg",
                "parent": "NETWORK",
                "type": "link",
                "other": 3,
                "subCategory": "Range Extender"
            },
            {
                "category": "Network Switch",
                "link__name": "Network Switch",
                "img__src": "/laptop.jpg",
                "parent": "NETWORK",
                "type": "link",
                "other": 3,
                "subCategory": "Network Switch"
            },
            {
                "category": "Lan Card",
                "link__name": "Lan Card",
                "img__src": "/laptop.jpg",
                "parent": "NETWORK",
                "type": "link",
                "other": 3,
                "subCategory": "Lan Card"
            },
            {
                "category": "Network Cable",
                "link__name": "Network Cable",
                "img__src": "/laptop.jpg",
                "parent": "NETWORK",
                "type": "link",
                "other": 3,
                "subCategory": "Network Cable"
            },
            {
                "category": "Optical Line Termination (OLT)",
                "link__name": "Optical Line Termination (OLT)",
                "img__src": "/laptop.jpg",
                "parent": "NETWORK",
                "type": "link",
                "other": 3,
                "subCategory": "Optical Line Termination (OLT)"
            },
            {
                "category": "Optical Network Unit (ONU)",
                "link__name": "Optical Network Unit (ONU)",
                "img__src": "/laptop.jpg",
                "parent": "NETWORK",
                "type": "link",
                "other": 3,
                "subCategory": "Optical Network Unit (ONU)"
            },
            {
                "category": "Network Storage",
                "link__name": "Network Storage",
                "img__src": "/laptop.jpg",
                "parent": "NETWORK",
                "type": "link",
                "other": 3,
                "subCategory": "Network Storage"
            },
            {
                "category": "Edge Modem",
                "link__name": "Edge Modem",
                "img__src": "/laptop.jpg",
                "parent": "NETWORK",
                "type": "link",
                "other": 3,
                "subCategory": "Edge Modem"
            },
            {
                "category": "Network Accessories",
                "link__name": "Network Accessories",
                "img__src": "/laptop.jpg",
                "parent": "NETWORK",
                "type": "head",
                "other": true,
                "subCategory": "Network Accessories"
            },
            {
                "category": "All Network Accessories",
                "link__name": "Network Accessories",
                "img__src": "/laptop.jpg",
                "parent": "NETWORK",
                "type": "link",
                "other": 2,
                "subCategory": "Network Accessories"
            },
            {
                "category": " Connector",
                "link__name": " Connector",
                "img__src": "/laptop.jpg",
                "parent": "NETWORK",
                "type": "link",
                "other": 4,
                "subCategory": "Network Accessories"
            },
            {
                "category": " Face Plate",
                "link__name": " Face Plate",
                "img__src": "/laptop.jpg",
                "parent": "NETWORK",
                "type": "link",
                "other": 4,
                "subCategory": "Network Accessories"
            },
            {
                "category": " Cable Lan",
                "link__name": " Cable Lan",
                "img__src": "/laptop.jpg",
                "parent": "NETWORK",
                "type": "link",
                "other": 4,
                "subCategory": "Network Accessories"
            },
            {
                "category": " Crimping Tool",
                "link__name": " Crimping Tool",
                "img__src": "/laptop.jpg",
                "parent": "NETWORK",
                "type": "link",
                "other": 4,
                "subCategory": "Network Accessories"
            },
            {
                "category": " Patch Cord",
                "link__name": " Patch Cord",
                "img__src": "/laptop.jpg",
                "parent": "NETWORK",
                "type": "link",
                "other": 4,
                "subCategory": "Network Accessories"
            },
            {
                "category": " Management Cable",
                "link__name": " Management Cable",
                "img__src": "/laptop.jpg",
                "parent": "NETWORK",
                "type": "link",
                "other": 4,
                "subCategory": "Network Accessories"
            },
            {
                "category": " Patch Panel",
                "link__name": " Patch Panel",
                "img__src": "/laptop.jpg",
                "parent": "NETWORK",
                "type": "link",
                "other": 4,
                "subCategory": "Network Accessories"
            },
            {
                "category": " Modular",
                "link__name": " Modular",
                "img__src": "/laptop.jpg",
                "parent": "NETWORK",
                "type": "link",
                "other": 4,
                "subCategory": "Network Accessories"
            }
        ]
    },
    {
        "header": "SOUND SYSTEM",
        "img__src": "/laptop.jpg",
        "link__name": "SOUND SYSTEM",
        "links": [
 
            {
                "category": "Speaker",
                "link__name": "Speaker",
                "img__src": "/laptop.jpg",
                "parent": "SOUND SYSTEM",
                "type": "head",
                "other": true,
                "subCategory": "Speaker"
            },
            {
                "category": " All Brand",
                "link__name": " All Brand",
                "img__src": "/laptop.jpg",
                "parent": "SOUND SYSTEM",
                "type": "link",
                "other": 2,
                "subCategory": "Speaker"
            },
            {
                "category": " F&D",
                "link__name": " F&D",
                "img__src": "/laptop.jpg",
                "parent": "SOUND SYSTEM",
                "type": "link",
                "other": 4,
                "subCategory": "Speaker"
            },
            {
                "category": " Xtreme",
                "link__name": " Xtreme",
                "img__src": "/laptop.jpg",
                "parent": "SOUND SYSTEM",
                "type": "link",
                "other": 4,
                "subCategory": "Speaker"
            },
            {
                "category": " Edifier",
                "link__name": " Edifier",
                "img__src": "/laptop.jpg",
                "parent": "SOUND SYSTEM",
                "type": "link",
                "other": 4,
                "subCategory": "Speaker"
            },
            {
                "category": " Havit",
                "link__name": " Havit",
                "img__src": "/laptop.jpg",
                "parent": "SOUND SYSTEM",
                "type": "link",
                "other": 4,
                "subCategory": "Speaker"
            },
            {
                "category": " Digital X",
                "link__name": " Digital X",
                "img__src": "/laptop.jpg",
                "parent": "SOUND SYSTEM",
                "type": "link",
                "other": 4,
                "subCategory": "Speaker"
            },
            {
                "category": " Golden Field",
                "link__name": " Golden Field",
                "img__src": "/laptop.jpg",
                "parent": "SOUND SYSTEM",
                "type": "link",
                "other": 4,
                "subCategory": "Speaker"
            },
            {
                "category": " Microlab",
                "link__name": " Microlab",
                "img__src": "/laptop.jpg",
                "parent": "SOUND SYSTEM",
                "type": "link",
                "other": 4,
                "subCategory": "Speaker"
            },
            {
                "category": " JBL",
                "link__name": " JBL",
                "img__src": "/laptop.jpg",
                "parent": "SOUND SYSTEM",
                "type": "link",
                "other": 4,
                "subCategory": "Speaker"
            },
            {
                "category": " Jabra",
                "link__name": " Jabra",
                "img__src": "/laptop.jpg",
                "parent": "SOUND SYSTEM",
                "type": "link",
                "other": 4,
                "subCategory": "Speaker"
            },
            {
                "category": " Altec Lansing",
                "link__name": " Altec Lansing",
                "img__src": "/laptop.jpg",
                "parent": "SOUND SYSTEM",
                "type": "link",
                "other": 4,
                "subCategory": "Speaker"
            },
            {
                "category": " Fantech",
                "link__name": " Fantech",
                "img__src": "/laptop.jpg",
                "parent": "SOUND SYSTEM",
                "type": "link",
                "other": 4,
                "subCategory": "Speaker"
            },
            {
                "category": " Grandstream",
                "link__name": " Grandstream",
                "img__src": "/laptop.jpg",
                "parent": "SOUND SYSTEM",
                "type": "link",
                "other": 4,
                "subCategory": "Speaker"
            },
            {
                "category": " Rapoo",
                "link__name": " Rapoo",
                "img__src": "/laptop.jpg",
                "parent": "SOUND SYSTEM",
                "type": "link",
                "other": 4,
                "subCategory": "Speaker"
            },
            {
                "category": " Creative",
                "link__name": " Creative",
                "img__src": "/laptop.jpg",
                "parent": "SOUND SYSTEM",
                "type": "link",
                "other": 4,
                "subCategory": "Speaker"
            },
            {
                "category": " Bose",
                "link__name": " Bose",
                "img__src": "/laptop.jpg",
                "parent": "SOUND SYSTEM",
                "type": "link",
                "other": 4,
                "subCategory": "Speaker"
            },
            {
                "category": " Silicon Power",
                "link__name": " Silicon Power",
                "img__src": "/laptop.jpg",
                "parent": "SOUND SYSTEM",
                "type": "link",
                "other": 4,
                "subCategory": "Speaker"
            },
            {
                "category": " Logitech",
                "link__name": " Logitech",
                "img__src": "/laptop.jpg",
                "parent": "SOUND SYSTEM",
                "type": "link",
                "other": 4,
                "subCategory": "Speaker"
            },
            {
                "category": " Polycom",
                "link__name": " Polycom",
                "img__src": "/laptop.jpg",
                "parent": "SOUND SYSTEM",
                "type": "link",
                "other": 4,
                "subCategory": "Speaker"
            },
            {
                "category": " Micropack",
                "link__name": " Micropack",
                "img__src": "/laptop.jpg",
                "parent": "SOUND SYSTEM",
                "type": "link",
                "other": 4,
                "subCategory": "Speaker"
            },
            {
                "category": " Google",
                "link__name": " Google",
                "img__src": "/laptop.jpg",
                "parent": "SOUND SYSTEM",
                "type": "link",
                "other": 4,
                "subCategory": "Speaker"
            },
            {
                "category": " Amazon",
                "link__name": " Amazon",
                "img__src": "/laptop.jpg",
                "parent": "SOUND SYSTEM",
                "type": "link",
                "other": 4,
                "subCategory": "Speaker"
            },
            {
                "category": " Redragon",
                "link__name": " Redragon",
                "img__src": "/laptop.jpg",
                "parent": "SOUND SYSTEM",
                "type": "link",
                "other": 4,
                "subCategory": "Speaker"
            },
            {
                "category": " Marvo",
                "link__name": " Marvo",
                "img__src": "/laptop.jpg",
                "parent": "SOUND SYSTEM",
                "type": "link",
                "other": 4,
                "subCategory": "Speaker"
            },
            {
                "category": "Home Theater Systems",
                "link__name": "Home Theater Systems",
                "img__src": "/laptop.jpg",
                "parent": "SOUND SYSTEM",
                "type": "link",
                "other": 3,
                "subCategory": "Home Theater Systems"
            }, 
            {
                "category": "PA System",
                "link__name": "PA System",
                "img__src": "/laptop.jpg",
                "parent": "SOUND SYSTEM",
                "type": "link",
                "other": 3,
                "subCategory": "PA System"
            }, 
            {
                "category": "Headphone",
                "link__name": "Headphone",
                "img__src": "/laptop.jpg",
                "parent": "SOUND SYSTEM",
                "type": "link",
                "other": 3,
                "subCategory": "Headphone"
            },
            {
                "category": "Ear Phone",
                "link__name": "Ear Phone",
                "img__src": "/laptop.jpg",
                "parent": "SOUND SYSTEM",
                "type": "link",
                "other": 3,
                "subCategory": "Ear Phone"
            },
            {
                "category": "Microphone",
                "link__name": "Microphone",
                "img__src": "/laptop.jpg",
                "parent": "SOUND SYSTEM",
                "type": "link",
                "other": 3,
                "subCategory": "Microphone"
            },
            {
                "category": "Sound Card",
                "link__name": "Sound Card",
                "img__src": "/laptop.jpg",
                "parent": "SOUND SYSTEM",
                "type": "link",
                "other": 3,
                "subCategory": "Sound Card"
            },
            {
                "category": "Voice Recorder",
                "link__name": "Voice Recorder",
                "img__src": "/laptop.jpg",
                "parent": "SOUND SYSTEM",
                "type": "link",
                "other": 3,
                "subCategory": "Voice Recorder"
            },
            {
                "category": "Radio",
                "link__name": "Radio",
                "img__src": "/laptop.jpg",
                "parent": "SOUND SYSTEM",
                "type": "link",
                "other": 3,
                "subCategory": "Radio"
            },
            {
                "category": "Musical Instrument",
                "link__name": "Musical Instrument",
                "img__src": "/laptop.jpg",
                "parent": "SOUND SYSTEM",
                "type": "link",
                "other": 3,
                "subCategory": "Musical Instrument"
            }
        ]
    },
    {
        "header": "OFFICE ITEMS",
        "img__src": "/laptop.jpg",
        "link__name": "OFFICE ITEMS",
        "links": [
 
            {
                "category": "Money Counting Machine",
                "link__name": "Money Counting Machine",
                "img__src": "/laptop.jpg",
                "parent": "OFFICE ITEMS",
                "type": "link",
                "other": 3,
                "subCategory": "Money Counting Machine"
            },
            {
                "category": "Cash Register Machine",
                "link__name": "Cash Register Machine",
                "img__src": "/laptop.jpg",
                "parent": "OFFICE ITEMS",
                "type": "link",
                "other": 3,
                "subCategory": "Cash Register Machine"
            },
            {
                "category": "Paper Shredder",
                "link__name": "Paper Shredder",
                "img__src": "/laptop.jpg",
                "parent": "OFFICE ITEMS",
                "type": "link",
                "other": 3,
                "subCategory": "Paper Shredder"
            },
            {
                "category": "Telephone Set",
                "link__name": "Telephone Set",
                "img__src": "/laptop.jpg",
                "parent": "OFFICE ITEMS",
                "type": "head",
                "other": true,
                "subCategory": "Telephone Set"
            },
            {
                "category": "All Telephone Set",
                "link__name": "Telephone Set",
                "img__src": "/laptop.jpg",
                "parent": "OFFICE ITEMS",
                "type": "link",
                "other": 2,
                "subCategory": "Telephone Set"
            },
            {
                "category": " Land Phone Set",
                "link__name": " Land Phone Set",
                "img__src": "/laptop.jpg",
                "parent": "OFFICE ITEMS",
                "type": "link",
                "other": 4,
                "subCategory": "Telephone Set"
            },
            {
                "category": " IP Phone Set",
                "link__name": " IP Phone Set",
                "img__src": "/laptop.jpg",
                "parent": "OFFICE ITEMS",
                "type": "link",
                "other": 4,
                "subCategory": "Telephone Set"
            },
            {
                "category": "Fax Machine",
                "link__name": "Fax Machine",
                "img__src": "/laptop.jpg",
                "parent": "OFFICE ITEMS",
                "type": "link",
                "other": 3,
                "subCategory": "Fax Machine"
            },
            {
                "category": "Calculator",
                "link__name": "Calculator",
                "img__src": "/laptop.jpg",
                "parent": "OFFICE ITEMS",
                "type": "link",
                "other": 3,
                "subCategory": "Calculator"
            }
        ]
    },
    {
        "header": "STORAGE",
        "img__src": "/laptop.jpg",
        "link__name": "STORAGE",
        "links": [
 
            {
                "category": "Internal HDD",
                "link__name": "Internal HDD",
                "img__src": "/laptop.jpg",
                "parent": "STORAGE",
                "type": "link",
                "other": 3,
                "subCategory": "Internal HDD"
            },
            {
                "category": "Internal SSD",
                "link__name": "Internal SSD",
                "img__src": "/laptop.jpg",
                "parent": "STORAGE",
                "type": "link",
                "other": 3,
                "subCategory": "Internal SSD"
            },
            {
                "category": "Internal Server HDD",
                "link__name": "Internal Server HDD",
                "img__src": "/laptop.jpg",
                "parent": "STORAGE",
                "type": "link",
                "other": 3,
                "subCategory": "Internal Server HDD"
            },
            {
                "category": "External HDD",
                "link__name": "External HDD",
                "img__src": "/laptop.jpg",
                "parent": "STORAGE",
                "type": "link",
                "other": 3,
                "subCategory": "External HDD"
            },
            {
                "category": "External SSD",
                "link__name": "External SSD",
                "img__src": "/laptop.jpg",
                "parent": "STORAGE",
                "type": "link",
                "other": 3,
                "subCategory": "External SSD"
            },
            {
                "category": "Pen Drive",
                "link__name": "Pen Drive",
                "img__src": "/laptop.jpg",
                "parent": "STORAGE",
                "type": "link",
                "other": 3,
                "subCategory": "Pen Drive"
            },
            {
                "category": "Memory Card",
                "link__name": "Memory Card",
                "img__src": "/laptop.jpg",
                "parent": "STORAGE",
                "type": "link",
                "other": 3,
                "subCategory": "Memory Card"
            },
            {
                "category": "HDD Case",
                "link__name": "HDD Case",
                "img__src": "/laptop.jpg",
                "parent": "STORAGE",
                "type": "link",
                "other": 3,
                "subCategory": "HDD Case"
            },
            {
                "category": "Card Reader",
                "link__name": "Card Reader",
                "img__src": "/laptop.jpg",
                "parent": "STORAGE",
                "type": "link",
                "other": 3,
                "subCategory": "Card Reader"
            }
        ]
    },
    {
        "header": "ACCESSORIES",
        "img__src": "/laptop.jpg",
        "link__name": "ACCESSORIES",
        "links": [
  
            {
                "category": "Cable",
                "link__name": "Cable",
                "img__src": "/laptop.jpg",
                "parent": "ACCESSORIES",
                "type": "head",
                "other": true,
                "subCategory": "Cable"
            },
            {
                "category": "All Cable",
                "link__name": "Cable",
                "img__src": "/laptop.jpg",
                "parent": "ACCESSORIES",
                "type": "link",
                "other": 2,
                "subCategory": "Cable"
            },
            {
                "category": " HDMI Cable",
                "link__name": " HDMI Cable",
                "img__src": "/laptop.jpg",
                "parent": "ACCESSORIES",
                "type": "link",
                "other": 4,
                "subCategory": "Cable"
            },
            {
                "category": " VGA Cable",
                "link__name": " VGA Cable",
                "img__src": "/laptop.jpg",
                "parent": "ACCESSORIES",
                "type": "link",
                "other": 4,
                "subCategory": "Cable"
            },
            {
                "category": " Lightning Cable",
                "link__name": " Lightning Cable",
                "img__src": "/laptop.jpg",
                "parent": "ACCESSORIES",
                "type": "link",
                "other": 4,
                "subCategory": "Cable"
            },
            {
                "category": " USB Cable",
                "link__name": " USB Cable",
                "img__src": "/laptop.jpg",
                "parent": "ACCESSORIES",
                "type": "link",
                "other": 4,
                "subCategory": "Cable"
            },
            {
                "category": " Audio Cable",
                "link__name": " Audio Cable",
                "img__src": "/laptop.jpg",
                "parent": "ACCESSORIES",
                "type": "link",
                "other": 4,
                "subCategory": "Cable"
            },
            {
                "category": " Sata Cable",
                "link__name": " Sata Cable",
                "img__src": "/laptop.jpg",
                "parent": "ACCESSORIES",
                "type": "link",
                "other": 4,
                "subCategory": "Cable"
            },
            {
                "category": " Display Port Cable",
                "link__name": " Display Port Cable",
                "img__src": "/laptop.jpg",
                "parent": "ACCESSORIES",
                "type": "link",
                "other": 4,
                "subCategory": "Cable"
            },
            {
                "category": "Converter",
                "link__name": "Converter",
                "img__src": "/laptop.jpg",
                "parent": "ACCESSORIES",
                "type": "head",
                "other": true,
                "subCategory": "Converter"
            },
            {
                "category": "All Converter",
                "link__name": "Converter",
                "img__src": "/laptop.jpg",
                "parent": "ACCESSORIES",
                "type": "link",
                "other": 2,
                "subCategory": "Converter"
            },
            {
                "category": " HDMI Converter",
                "link__name": " HDMI Converter",
                "img__src": "/laptop.jpg",
                "parent": "ACCESSORIES",
                "type": "link",
                "other": 4,
                "subCategory": "Converter"
            },
            {
                "category": " VGA Converter",
                "link__name": " VGA Converter",
                "img__src": "/laptop.jpg",
                "parent": "ACCESSORIES",
                "type": "link",
                "other": 4,
                "subCategory": "Converter"
            },
            {
                "category": " USB HUB",
                "link__name": " USB HUB",
                "img__src": "/laptop.jpg",
                "parent": "ACCESSORIES",
                "type": "link",
                "other": 4,
                "subCategory": "Converter"
            },
            {
                "category": " Audio Converter",
                "link__name": " Audio Converter",
                "img__src": "/laptop.jpg",
                "parent": "ACCESSORIES",
                "type": "link",
                "other": 4,
                "subCategory": "Converter"
            },
            {
                "category": " Bluetooth Adapter",
                "link__name": " Bluetooth Adapter",
                "img__src": "/laptop.jpg",
                "parent": "ACCESSORIES",
                "type": "link",
                "other": 4,
                "subCategory": "Converter"
            },
            {
                "category": " Type-C Converter",
                "link__name": " Type-C Converter",
                "img__src": "/laptop.jpg",
                "parent": "ACCESSORIES",
                "type": "link",
                "other": 4,
                "subCategory": "Converter"
            },
            {
                "category": " Lightning Converter",
                "link__name": " Lightning Converter",
                "img__src": "/laptop.jpg",
                "parent": "ACCESSORIES",
                "type": "link",
                "other": 4,
                "subCategory": "Converter"
            },
            {
                "category": " USB Converter",
                "link__name": " USB Converter",
                "img__src": "/laptop.jpg",
                "parent": "ACCESSORIES",
                "type": "link",
                "other": 4,
                "subCategory": "Converter"
            },
            {
                "category": " Display Port Converter",
                "link__name": " Display Port Converter",
                "img__src": "/laptop.jpg",
                "parent": "ACCESSORIES",
                "type": "link",
                "other": 4,
                "subCategory": "Converter"
            },
            {
                "category": " DVI Converter",
                "link__name": " DVI Converter",
                "img__src": "/laptop.jpg",
                "parent": "ACCESSORIES",
                "type": "link",
                "other": 4,
                "subCategory": "Converter"
            },
            {
                "category": "Electrical Power",
                "link__name": "Electrical Power",
                "img__src": "/laptop.jpg",
                "parent": "ACCESSORIES",
                "type": "head",
                "other": true,
                "subCategory": "Electrical Power"
            },
            {
                "category": "All Electrical Power",
                "link__name": "Electrical Power",
                "img__src": "/laptop.jpg",
                "parent": "ACCESSORIES",
                "type": "link",
                "other": 2,
                "subCategory": "Electrical Power"
            },
            {
                "category": " Power Strip",
                "link__name": " Power Strip",
                "img__src": "/laptop.jpg",
                "parent": "ACCESSORIES",
                "type": "link",
                "other": 4,
                "subCategory": "Electrical Power"
            },
            {
                "category": " Power Adapter",
                "link__name": " Power Adapter",
                "img__src": "/laptop.jpg",
                "parent": "ACCESSORIES",
                "type": "link",
                "other": 4,
                "subCategory": "Electrical Power"
            },
            {
                "category": " Blower",
                "link__name": " Blower",
                "img__src": "/laptop.jpg",
                "parent": "ACCESSORIES",
                "type": "link",
                "other": 4,
                "subCategory": "Electrical Power"
            },
            {
                "category": " Power Cable",
                "link__name": " Power Cable",
                "img__src": "/laptop.jpg",
                "parent": "ACCESSORIES",
                "type": "link",
                "other": 4,
                "subCategory": "Electrical Power"
            },
            {
                "category": "Premium Accessories",
                "link__name": "Premium Accessories",
                "img__src": "/laptop.jpg",
                "parent": "ACCESSORIES",
                "type": "head",
                "other": true,
                "subCategory": "Premium Accessories"
            },
            {
                "category": "All Premium Accessories",
                "link__name": "Premium Accessories",
                "img__src": "/laptop.jpg",
                "parent": "ACCESSORIES",
                "type": "link",
                "other": 2,
                "subCategory": "Premium Accessories"
            },
            {
                "category": " Apple Accessories",
                "link__name": " Apple Accessories",
                "img__src": "/laptop.jpg",
                "parent": "ACCESSORIES",
                "type": "link",
                "other": 4,
                "subCategory": "Premium Accessories"
            },
            {
                "category": " Microsoft Accessories",
                "link__name": " Microsoft Accessories",
                "img__src": "/laptop.jpg",
                "parent": "ACCESSORIES",
                "type": "link",
                "other": 4,
                "subCategory": "Premium Accessories"
            },
            {
                "category": " Digital Pen",
                "link__name": " Digital Pen",
                "img__src": "/laptop.jpg",
                "parent": "ACCESSORIES",
                "type": "link",
                "other": 4,
                "subCategory": "Premium Accessories"
            },
            {
                "category": " Power & Charger",
                "link__name": " Power & Charger",
                "img__src": "/laptop.jpg",
                "parent": "ACCESSORIES",
                "type": "link",
                "other": 4,
                "subCategory": "Premium Accessories"
            },
            {
                "category": "Bag",
                "link__name": "Bag",
                "img__src": "/laptop.jpg",
                "parent": "ACCESSORIES",
                "type": "link",
                "other": 3,
                "subCategory": "Bag"
            }
        ]
    },
    {
        "header": "SOFTWARE",
        "img__src": "/laptop.jpg",
        "link__name": "SOFTWARE",
        "links": [ 
 
            {
                "category": "Antivirus and Security",
                "link__name": "Antivirus and Security",
                "img__src": "/laptop.jpg",
                "parent": "SOFTWARE",
                "type": "link",
                "other": 3,
                "subCategory": "Antivirus and Security"
            },
            {
                "category": "Office Application",
                "link__name": "Office Application",
                "img__src": "/laptop.jpg",
                "parent": "SOFTWARE",
                "type": "link",
                "other": 3,
                "subCategory": "Office Application"
            },
            {
                "category": "Operating System and DB",
                "link__name": "Operating System and DB",
                "img__src": "/laptop.jpg",
                "parent": "SOFTWARE",
                "type": "link",
                "other": 3,
                "subCategory": "Operating System and DB"
            },
            {
                "category": "Graphics Design",
                "link__name": "Graphics Design",
                "img__src": "/laptop.jpg",
                "parent": "SOFTWARE",
                "type": "link",
                "other": 3,
                "subCategory": "Graphics Design"
            },
            {
                "category": "Engineering Design",
                "link__name": "Engineering Design",
                "img__src": "/laptop.jpg",
                "parent": "SOFTWARE",
                "type": "link",
                "other": 3,
                "subCategory": "Engineering Design"
            },
            {
                "category": "Bangla Typing Application",
                "link__name": "Bangla Typing Application",
                "img__src": "/laptop.jpg",
                "parent": "SOFTWARE",
                "type": "link",
                "other": 3,
                "subCategory": "Bangla Typing Application"
            }
        ]
    },
    {
        "header": "DAILY LIFE",
        "img__src": "/laptop.jpg",
        "link__name": "DAILY LIFE",
        "links": [
            {
                "category": "Smartwatch",
                "link__name": "Smartwatch",
                "img__src": "/laptop.jpg",
                "parent": "DAILY LIFE",
                "type": "head",
                "other": true,
                "subCategory": "Smartwatch"
            },
            {
                "category": "All Smartwatch",
                "link__name": "Smartwatch",
                "img__src": "/laptop.jpg",
                "parent": "DAILY LIFE",
                "type": "link",
                "other": 2,
                "subCategory": "Smartwatch"
            },
            {
                "category": " Apple",
                "link__name": " Apple",
                "img__src": "/laptop.jpg",
                "parent": "DAILY LIFE",
                "type": "link",
                "other": 4,
                "subCategory": "Smartwatch"
            },
            {
                "category": " Kieslect",
                "link__name": " Kieslect",
                "img__src": "/laptop.jpg",
                "parent": "DAILY LIFE",
                "type": "link",
                "other": 4,
                "subCategory": "Smartwatch"
            },
            {
                "category": " Havit",
                "link__name": " Havit",
                "img__src": "/laptop.jpg",
                "parent": "DAILY LIFE",
                "type": "link",
                "other": 4,
                "subCategory": "Smartwatch"
            },
            {
                "category": " Xiaomi",
                "link__name": " Xiaomi",
                "img__src": "/laptop.jpg",
                "parent": "DAILY LIFE",
                "type": "link",
                "other": 4,
                "subCategory": "Smartwatch"
            },
            {
                "category": "Sewing Machine",
                "link__name": "Sewing Machine",
                "img__src": "/laptop.jpg",
                "parent": "DAILY LIFE",
                "type": "head",
                "other": true,
                "subCategory": "Sewing Machine"
            },
            {
                "category": "All Sewing Machine",
                "link__name": "Sewing Machine",
                "img__src": "/laptop.jpg",
                "parent": "DAILY LIFE",
                "type": "link",
                "other": 2,
                "subCategory": "Sewing Machine"
            },
            {
                "category": "TV and Video Streaming",
                "link__name": "TV and Video Streaming",
                "img__src": "/laptop.jpg",
                "parent": "DAILY LIFE",
                "type": "head",
                "other": true,
                "subCategory": "TV and Video Streaming"
            },
            {
                "category": "All TV and Video Streaming",
                "link__name": "TV and Video Streaming",
                "img__src": "/laptop.jpg",
                "parent": "DAILY LIFE",
                "type": "link",
                "other": 2,
                "subCategory": "TV and Video Streaming"
            },
            {
                "category": " Smart TV",
                "link__name": " Smart TV",
                "img__src": "/laptop.jpg",
                "parent": "DAILY LIFE",
                "type": "link",
                "other": 4,
                "subCategory": "TV and Video Streaming"
            },
            {
                "category": " TV Streaming",
                "link__name": " TV Streaming",
                "img__src": "/laptop.jpg",
                "parent": "DAILY LIFE",
                "type": "link",
                "other": 4,
                "subCategory": "TV and Video Streaming"
            },
            {
                "category": " TV Card",
                "link__name": " TV Card",
                "img__src": "/laptop.jpg",
                "parent": "DAILY LIFE",
                "type": "link",
                "other": 4,
                "subCategory": "TV and Video Streaming"
            },
            {
                "category": " Game Streaming",
                "link__name": " Game Streaming",
                "img__src": "/laptop.jpg",
                "parent": "DAILY LIFE",
                "type": "link",
                "other": 4,
                "subCategory": "TV and Video Streaming"
            }
        ]
    },
    {
        "header": "POS SYSTEM",
        "img__src": "/laptop.jpg",
        "link__name": "POS SYSTEM",
        "links": [
 
            {
                "category": "POS SYSTEM",
                "link__name": "POS SYSTEM",
                "img__src": "/laptop.jpg",
                "parent": "POS SYSTEM",
                "type": "link",
                "other": 4,
                "subCategory": "POS SYSTEM"
            }
        ]
    }
]

export { navLinks };

