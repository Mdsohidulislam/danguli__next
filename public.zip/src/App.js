import CartTwoelve from "./Components/Carts/CartTwoelve/CartTwoelve";

 


const App = () => {
    return (
        <div>
            <CartTwoelve/>
        </div>
    );
};

export default App;


// const App = () => {
    
//     return (
//         <div>
            
//             <ContextProvider>
//                 <DanguliRouter/>
//             </ContextProvider>
//         </div>
//     );
// };

// export default App; 
 