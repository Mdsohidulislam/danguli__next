import { useState } from 'react'  
import AppContext from './AppContext'
import '../styles/style.globals.scss' 
import './details/details.globals.scss'
import 'bootstrap/dist/css/bootstrap.min.css';
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import './Components/ProductDetails/ProductDetails.globals.scss';
import './Components/HeaderButton/HeaderButton.globals.scss'
import '../styles/slick.scss';
import './Components/Details/details.globals.scss';
import './Components/TopLinks/TopLinks.globals.scss';
import './Components/SideNavbar/SideNavbar.globals.scss'
import './Components/Search/Search.globals.scss';
import './Components/SearchBarContainer/SearchBarContainer.globals.scss';
import './Components/TopNavbar/TopNavbar.globals.scss'
  
function MyApp({ Component, pageProps }) {
  const [name, setName] = useState('hello world')
  
  return    <AppContext.Provider value={{name, setName}}>
 
                    <Component {...pageProps} /> 
                
              </AppContext.Provider> 
}

export default MyApp
