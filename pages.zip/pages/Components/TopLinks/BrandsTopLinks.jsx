import { faAnglesRight } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { Link } from 'react-router-dom';

const BrandsTopLink = ({infos}) => { 
    let {brand}  = infos;
    return (
        <div className='category__or__product__link__container'>
        <Link to='/' className='body__header__middle__Link'>Home</Link>
        <FontAwesomeIcon className='body__header__middle__arrow' icon={faAnglesRight}/> 
        <Link to={`/allBrands`} className='body__header__middle__Link'>Brands</Link>
        <FontAwesomeIcon className='body__header__middle__arrow' icon={faAnglesRight}/> 
        <Link to={`/allBrands/${brand}`} className='body__header__middle__Link'>{brand}</Link> 
    </div>
    );
};

export default BrandsTopLink;