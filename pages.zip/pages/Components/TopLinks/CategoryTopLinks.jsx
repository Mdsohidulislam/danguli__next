import { faAnglesRight } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { Link } from 'react-router-dom';

const CategoryTopLinks = ({infos}) => { 
    let {category}  = infos;
    return (
        <div className='category__or__product__link__container'>
        <Link to='/' className='body__header__middle__Link'>Home</Link>
        <FontAwesomeIcon className='body__header__middle__arrow' icon={faAnglesRight}/> 
        <Link to={`/allCategories`} className='body__header__middle__Link'>Categories</Link>
        <FontAwesomeIcon className='body__header__middle__arrow' icon={faAnglesRight}/> 
        <Link to={`/allCategories/${category}`} className='body__header__middle__Link'>{category}</Link> 
    </div>
    );
};

export default CategoryTopLinks;