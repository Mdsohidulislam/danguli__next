import { faAnglesRight } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import React from 'react';
import { Link } from 'react-router-dom';

const FatherTopLinks = ({infos}) => { 
    let {father}  = infos;
    return (
        <div className='category__or__product__link__container'>
        <Link to='/' className='body__header__middle__Link'>Home</Link>
        <FontAwesomeIcon className='body__header__middle__arrow' icon={faAnglesRight}/> 
        <Link to={`/allProducts?father=${father}`} className='body__header__middle__Link'>{father}</Link> 
    </div>
    );
};

export default FatherTopLinks;