import { faAnglesRight } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import Link from 'next/link';
import React from 'react'; 

const ChildTopLinks = ({infos}) => { 
    let {product} = infos;
    return (
        <div className='category__or__product__link__container'>
            <button className='body__header__middle__Link'>Home</button>
            <FontAwesomeIcon className='body__header__middle__arrow' icon={faAnglesRight}/> 
            <button  className='body__header__middle__Link'>{'Computer & Accessories'}</button>
            <FontAwesomeIcon className='body__header__middle__arrow' icon={faAnglesRight}/> 
            <button  className='body__header__middle__Link'>{product.parent__father}</button>
            <FontAwesomeIcon className='body__header__middle__arrow' icon={faAnglesRight}/> 
            <button  className='body__header__middle__Link'>{product.parent}</button> 
            <FontAwesomeIcon className='body__header__middle__arrow' icon={faAnglesRight}/> 
            <button  className='body__header__middle__Link'>{product.child}</button> 
        </div>
    );
};

export default ChildTopLinks;