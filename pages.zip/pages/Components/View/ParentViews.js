import React from 'react';

const ParentViews = () => {
    return (
        <div>
            <h1>Hello Parent Views</h1>
        </div>
    );
};

export default ParentViews;