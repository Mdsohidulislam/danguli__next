import React, { useContext, useState } from 'react';
import AppContext from '../../AppContext';

const DetailsViews = () => {
    const {name} = useContext(AppContext)
    console.log(name);
    return (
        <div>
            <h1>Hello details Views</h1>
        </div>
    );
};

export default DetailsViews;