import React from 'react';

const ChildView = () => {
    return (
        <div>
            <h1>Hello Child Views</h1>
        </div>
    );
};

export default ChildView;