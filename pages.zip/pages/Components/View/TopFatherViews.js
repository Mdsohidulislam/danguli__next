import React from 'react';

const TopFatherViews = () => {
    return (
        <div>
            <h1>Hello Top Father Views</h1>
        </div>
    );
};

export default TopFatherViews;