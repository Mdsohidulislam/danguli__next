import React from 'react';

const BrandView = () => {
    return (
        <div>
            <h1>Hello Brand View</h1>
        </div>
    );
};

export default BrandView;