import React from 'react';

const fatherViews = () => {
    return (
        <div>
            <h1>Hello Father Views</h1>
        </div>
    );
};

export default fatherViews;