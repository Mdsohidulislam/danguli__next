 
import Link from 'next/link';
import { Router, useRouter } from 'next/router';
import { utilsHelper } from '../../../UTILS/utils';

const HeaderCartSame = ({infos}) => {
    let serverPort = 'http://localhost:3009'
    let newImages = infos.infos.images.length ? infos.infos.images : [];
    let newImageCollection = [];
    for(let i = 0; i < newImages.length; i ++){
        if(newImages[i].indexOf('ryanscomputers') === -1){
            newImageCollection.push(serverPort+newImages[i])
        }
    } 
    let router = useRouter();
    
    const handleHistoryClick = () => {
        router.push('/details/hello gello mello')
    }
    return (
        <div className='header__cart__cover__header__cart'>
            <div className='header__cart__container'> 
                <div className='image__container'>
                {newImageCollection.length ?  
                        <img onClick={()=>router.push(`/details/${infos.visible__url}_-_${infos.parent__father}`)} src={newImageCollection[0]} alt="" />   :   
                        <img  onClick={()=>router.push(`/details/${infos.visible__url}_-_${infos.parent__father}`)}  src='/sorry__image.jpg' alt="" /> 
                }
                </div>
                <div className='info__container'> 
                    <p className='title'  onClick={()=>router.push(`/details/${infos.visible__url}_-_${infos.parent__father}`)} >{utilsHelper.stringOperations.stringCutter(infos.infos.title)}</p> 
                    <p className='price'> {infos.infos.current__price} tk</p>
                </div> 
            </div>
        </div>
    );
};

export default HeaderCartSame;