import { Button, Collapse } from '@mui/material';
import React, { useState } from 'react';
import SideNavbar from '../Components/SideNavbar/SideNavbar';
import DetailsProductViews from './SingleProductViews';

const DetailsPage = () => {
    const [collapseOpen, setCollapseOpen] = useState(false)
    return (
        <div> 
            <SideNavbar/>
        </div>
    );
};

export default DetailsPage;