import { useRouter } from 'next/router';
import React from 'react';
import SearchBarContainer from '../Components/SearchBarContainer/SearchBarContainer';
import TopSmallNavbar from '../Components/TopNavbar/TopSmallNavbar';
import Navbar from '../Navbar/Navbar';

const ChildHome = () => {
    
    let router = useRouter();

    console.log(router.query);
    return (
        <div>  
            <Navbar/>
        </div>
    );
};

export default ChildHome;