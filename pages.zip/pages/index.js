import Head from 'next/head';
import Link from 'next/link';
import React from 'react';
import { SideBySideMagnifier } from 'react-image-magnifiers';
import Navbar from './Navbar/Navbar';

const index = () => {
  return (
    <div> 
      <Head>
        <link rel="preconnect" href="https://fonts.googleapis.com"/>
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin/>
        <link href="https://fonts.googleapis.com/css2?family=PT+Sans:ital@1&display=swap" rel="stylesheet"/>
      </Head> 
      <SideBySideMagnifier className='max____width' imageSrc='/CartImages/609_______61.05.804.11_______.png' alwaysInPlace={true} fillAvailableSpace={true}/>
    </div>
  );
};

export default index;